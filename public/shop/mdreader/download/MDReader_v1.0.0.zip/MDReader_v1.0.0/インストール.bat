@echo off
chcp 65001 >nul
echo MDReaderをインストールします。
echo （常駐やスタートアップ登録はしません。.md の「プログラムから開く」に登録します）
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0src\install.ps1"
echo.
pause
