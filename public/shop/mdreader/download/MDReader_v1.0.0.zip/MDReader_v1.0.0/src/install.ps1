﻿# インストール: アプリを %LOCALAPPDATA%\MDReader\app\ にコピーし、.md の「プログラムから開く」とスタートメニューを登録する
# 常駐・スタートアップ登録はしない。保存データ（%APPDATA%）には触れない。
# -DryRun を付けると、何もせず「やること」だけを表示する（動作確認用）。
param(
  [switch]$DryRun,
  [string]$ClassesRoot = 'HKCU:\Software\Classes',
  [string]$LocalRoot = '',
  [string]$StartMenuDir = ''
)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot                       # 展開したフォルダの src
if (-not $LocalRoot) { $LocalRoot = Join-Path $env:LOCALAPPDATA 'MDReader' }
if (-not $StartMenuDir) { $StartMenuDir = [Environment]::GetFolderPath('Programs') }
$appDir = Join-Path $LocalRoot 'app'
$appName = 'MDReader'
$progId = 'MDReader.md'
$oldProgId = 'MdViewerSoftLab.md'      # 前の名前で入れていた登録（あれば外す）
$oldAppName = 'md読み込みソフト'

function Say([string]$t) { Write-Host $t }

# 旧い案内で作られた「アプリを選択して開く」の登録（例: Applications\開く.bat）を外す。
# 外すのは、次のどちらかに当てはまるものだけ（社長・利用者の他の登録は触らない）。
#  (a) コマンドが「"…\開く.bat" …」で始まり、その .bat の隣に src\app.ps1 と、product が md-viewer の src\config.json がある（＝本ソフトの 開く.bat）
#  (b) コマンドの -File "…" が、本ソフトの app.ps1 のフルパス（$ownAppPs1）と完全に一致する
function Remove-LegacyAppRegistrations([string[]]$ownAppPs1) {
  $apps = Join-Path $ClassesRoot 'Applications'
  if (-not (Test-Path -LiteralPath $apps)) { return }
  foreach ($key in @(Get-ChildItem -LiteralPath $apps -ErrorAction SilentlyContinue)) {
    $name = $key.PSChildName
    if ($name -ieq 'MDReader.exe') { continue }
    $cmd = ''
    try { $cmd = [string](Get-ItemProperty -LiteralPath (Join-Path $key.PSPath 'shell\open\command') -ErrorAction Stop).'(default)' } catch { continue }
    $mine = $false
    $m = [regex]::Match($cmd, '^\s*"([^"]*\\開く\.bat)"')
    if ($m.Success) {
      $dir = Split-Path -Parent $m.Groups[1].Value
      $cfg = if ($dir) { Join-Path $dir 'src\config.json' } else { '' }
      if ($cfg -and (Test-Path -LiteralPath (Join-Path $dir 'src\app.ps1')) -and (Test-Path -LiteralPath $cfg)) {
        try { if ((Get-Content -LiteralPath $cfg -Raw -Encoding UTF8 | ConvertFrom-Json).product -eq 'md-viewer') { $mine = $true } } catch { }
      }
    }
    if (-not $mine) {
      $f = [regex]::Match($cmd, '-File\s+"([^"]+)"')
      if ($f.Success) { foreach ($own in $ownAppPs1) { if ($own -and [string]::Equals($f.Groups[1].Value, $own, 'OrdinalIgnoreCase')) { $mine = $true } } }
    }
    if (-not $mine) { continue }
    Remove-Item -LiteralPath $key.PSPath -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($ext in '.md', '.markdown') {
      $ol = Join-Path $ClassesRoot ($ext + '\OpenWithList')
      if (Test-Path -LiteralPath $ol) { Remove-Item -LiteralPath (Join-Path $ol $name) -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Say ('  旧い登録を外しました: ' + $name)
  }
}
# Applications\MDReader.exe が本ソフトのもの（open コマンドが "<exe>" "%1" で、exe が本ソフトの場所）か。キーが無いときは $true
function Test-OwnAppEntry([string]$exe) {
  $c = Join-Path $ClassesRoot 'Applications\MDReader.exe'
  if (-not (Test-Path -LiteralPath $c)) { return $true }
  try {
    $cmd = [string](Get-ItemProperty -LiteralPath (Join-Path $c 'shell\open\command') -ErrorAction Stop).'(default)'
    $m = [regex]::Match($cmd, '^\s*"([^"]+)"')
    return ($m.Success -and [string]::Equals($m.Groups[1].Value, $exe, 'OrdinalIgnoreCase'))
  } catch { return $false }
}
# 本ソフトの Applications\MDReader.exe と OpenWithList の登録を外す（他社の同名の登録は残す）
function Remove-AppEntry([string]$exe) {
  if (-not (Test-OwnAppEntry $exe)) { return }
  Remove-Item -Path (Join-Path $ClassesRoot 'Applications\MDReader.exe') -Recurse -Force -ErrorAction SilentlyContinue
  foreach ($ext in '.md', '.markdown') { Remove-Item -Path (Join-Path $ClassesRoot ($ext + '\OpenWithList\MDReader.exe')) -Recurse -Force -ErrorAction SilentlyContinue }
}

# 起動用の小さな MDReader.exe を、このパソコンの中で作る（.NET Framework 標準のコンパイラを使う。外部ツール・ダウンロードなし）。
# 「アプリを選択して開く」の一覧に「MDReader」と青い「M」のアイコンで出すため。exe は、隠し窓で app.ps1 を起動するだけ。
# 作れなかったときは $false を返し、従来どおり powershell.exe を直接使う。
function New-LauncherExe([string]$exePath, [string]$icoPath) {
  $src = @'
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
[assembly: AssemblyTitle("MDReader")]
[assembly: AssemblyDescription("MDReader")]
[assembly: AssemblyProduct("MDReader")]
[assembly: AssemblyVersion("1.0.0.0")]
public static class MDReaderLauncher {
  public static int Main(string[] args) {
    try {
      string app = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ps1");
      string a = "-NoProfile -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File \"" + app + "\"";
      if (args.Length > 0 && args[0].Length > 0) a += " \"" + args[0].Replace("\"", "") + "\"";
      ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", a);
      psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.WindowStyle = ProcessWindowStyle.Hidden;
      Process.Start(psi);
      return 0;
    } catch { return 1; }
  }
}
'@
  try {
    # Windows 標準の C# コンパイラ（.NET Framework）を直接呼ぶ。アイコン（/win32icon）を埋め込むため Add-Type は使わない
    $opt = '/target:winexe /optimize+'
    if ($icoPath -and (Test-Path -LiteralPath $icoPath)) { $opt += ' /win32icon:"' + $icoPath + '"' }
    if (Test-Path -LiteralPath $exePath) { Remove-Item -LiteralPath $exePath -Force }
    $prov = New-Object Microsoft.CSharp.CSharpCodeProvider
    $cp = New-Object System.CodeDom.Compiler.CompilerParameters
    $cp.GenerateExecutable = $true; $cp.GenerateInMemory = $false; $cp.OutputAssembly = $exePath; $cp.CompilerOptions = $opt
    [void]$cp.ReferencedAssemblies.Add('System.dll')
    $res = $prov.CompileAssemblyFromSource($cp, $src)
    if ($res.Errors.HasErrors) { return $false }
    return (Test-Path -LiteralPath $exePath -PathType Leaf)
  } catch { return $false }
}

# 「アプリを選択して開く」の一覧用の登録（Applications\MDReader.exe）。名前「MDReader」・アイコン・開ける種類
function Register-AppEntry([string]$exe, [string]$ico) {
  $k = Join-Path $ClassesRoot 'Applications\MDReader.exe'
  if (-not (Test-OwnAppEntry $exe)) { Say '  同じ名前（MDReader.exe）の他のソフトの登録があるため、「アプリを選択」用の登録は行いませんでした。'; return }
  New-Item -Path (Join-Path $k 'shell\open\command') -Force | Out-Null
  Set-ItemProperty -Path $k -Name 'FriendlyAppName' -Value $appName
  Set-ItemProperty -Path (Join-Path $k 'shell\open\command') -Name '(default)' -Value ('"' + $exe + '" "%1"')
  if (Test-Path -LiteralPath $ico) { New-Item -Path (Join-Path $k 'DefaultIcon') -Force | Out-Null; Set-ItemProperty -Path (Join-Path $k 'DefaultIcon') -Name '(default)' -Value $ico }
  New-Item -Path (Join-Path $k 'SupportedTypes') -Force | Out-Null
  foreach ($ext in '.md', '.markdown') {
    Set-ItemProperty -Path (Join-Path $k 'SupportedTypes') -Name $ext -Value ''
    $ow = Join-Path $ClassesRoot ($ext + '\OpenWithList\MDReader.exe')
    if (-not (Test-Path -LiteralPath $ow)) { New-Item -Path $ow -Force | Out-Null }   # 自分専用のキーだけ作る（他のアプリの登録は触らない）
  }
}
function Step([string]$t) { Write-Host ''; Write-Host ('■ ' + $t) }
function Do-Action([string]$desc, [scriptblock]$act) {
  if ($DryRun) { Say ('  （確認のみ）' + $desc); return }
  & $act
}

Say ($appName + ' をインストールします。' + $(if ($DryRun) { '（確認のみ・実際には何も変更しません）' } else { '' }))

# 1. 解除（ダウンロードしたファイルの警告印を外す）
Step '1. ファイルの準備'
Do-Action 'このフォルダの全ファイルの「ダウンロード由来」の印を外す' {
  Get-ChildItem -LiteralPath (Split-Path -Parent $here) -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
}

# 2. 動作中のアプリがないか
Step '2. 動作中のアプリの確認'
$dataDir = Join-Path $env:APPDATA 'MDReader'
$running = $false
try {
  $rj = Get-Content -LiteralPath (Join-Path $dataDir 'run.json') -Raw -ErrorAction Stop | ConvertFrom-Json
  $r = Invoke-WebRequest -Uri ("http://127.0.0.1:" + $rj.port + "/api/ping") -UseBasicParsing -TimeoutSec 2
  if ($r.StatusCode -eq 200) { $running = $true }
} catch { }
if ($running) {
  Say '  MDReaderのウィンドウが開いています。ウィンドウをすべて閉じて、少し待ってから、もう一度実行してください。'
  exit 2
}
Say '  動いていません。OKです。'

# 2b. 旧試作の常駐プロセス（あれば案内。自動では止めない）
$oldProc = @()
try {
  $oldProc = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop |
    Where-Object { $_.CommandLine -and ($_.CommandLine -match '\\[^\\"]*md読み込みソフト[^"]*\\src\\server\.ps1"\s*$') })
} catch { }
if ($oldProc.Count -gt 0) {
  Say '  旧い試作版（Windowsにログインすると裏で動くタイプ）が、まだ動いたままです。'
  Say '  最新版と一緒に動いても問題はありませんが、不要なら止めることをおすすめします。'
  if ($DryRun) {
    Say ('  （確認のみ）実際のインストールでは、止めるかどうかをここで確認します。（動いている数: ' + $oldProc.Count + '）')
  } else {
    $ans = Read-Host '  旧い試作版を止めますか？ 止める場合だけ Y を入力して Enter（それ以外は止めません）'
    if ($ans -match '^[Yy]') {
      foreach ($p in $oldProc) { try { Stop-Process -Id $p.ProcessId -Force; Say ('  止めました（番号 ' + $p.ProcessId + '）。') } catch { Say '  止められませんでした。パソコンを再起動するとなくなります。' } }
    } else {
      Say '  止めませんでした。パソコンを再起動する（サインアウトする）と、自然になくなります。'
    }
  }
}

# 3. コピー
Step '3. アプリをコピー'
$expected = [IO.Path]::GetFullPath($appDir)
if (-not $expected.EndsWith('\MDReader\app')) { Say '  コピー先が想定と違うため中止します。'; exit 3 }
Do-Action ('src を ' + $expected + ' にコピー（古い版は app.old に退避してから、成功後に削除）') {
  $old = $expected + '.old'
  if (Test-Path -LiteralPath $expected) {
    if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force }
    Rename-Item -LiteralPath $expected -NewName 'app.old'
  }
  try {
    New-Item -ItemType Directory -Path $expected -Force | Out-Null
    Copy-Item -Path (Join-Path $here '*') -Destination $expected -Recurse -Force -Exclude 'config.local.json'
    Get-ChildItem -LiteralPath $expected -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
  } catch {
    Say '  コピーに失敗しました。元の状態に戻します。'
    if (Test-Path -LiteralPath $expected) { Remove-Item -LiteralPath $expected -Recurse -Force }
    if (Test-Path -LiteralPath $old) { Rename-Item -LiteralPath $old -NewName 'app' }
    throw
  }
  if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force }
}

# 4. 「プログラムから開く」の登録
Step '4. .md の「プログラムから開く」に登録'
$exeFile = Join-Path $expected 'MDReader.exe'
$icoFile0 = Join-Path $expected 'assets\app.ico'
$script:HaveExe = $false
Do-Action '起動用の MDReader.exe をこのパソコンの中で作成（作れないときは従来の起動方法）' {
  $script:HaveExe = New-LauncherExe $exeFile $icoFile0
  if ($script:HaveExe) { Say '  MDReader.exe を作成しました。' } else { Say '  MDReader.exe を作れなかったため、従来の方法で登録します。（動作には影響しません）' }
}
$cmd = 'powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "' + (Join-Path $expected 'app.ps1') + '" "%1"'
if ($script:HaveExe) { $cmd = '"' + $exeFile + '" "%1"' }
Do-Action ('「アプリを選択して開く」用に ' + $ClassesRoot + '\Applications\MDReader.exe と OpenWithList を登録（exe を作れたときだけ。他社の同名の登録があれば行わない）。作れないときは、前回の登録を外す') { }
Do-Action ($ClassesRoot + '\' + $progId + ' を登録（.md / .markdown の OpenWithProgids には値を1つ足すだけ）') {
  $k = Join-Path $ClassesRoot $progId
  New-Item -Path (Join-Path $k 'shell\open\command') -Force | Out-Null
  Set-ItemProperty -Path $k -Name '(default)' -Value $appName
  Set-ItemProperty -Path (Join-Path $k 'shell\open\command') -Name '(default)' -Value $cmd
  $icoFile = Join-Path $expected 'assets\app.ico'
  if (Test-Path -LiteralPath $icoFile) {
    New-Item -Path (Join-Path $k 'DefaultIcon') -Force | Out-Null
    Set-ItemProperty -Path (Join-Path $k 'DefaultIcon') -Name '(default)' -Value $icoFile
  }
  foreach ($ext in '.md', '.markdown') {
    $o = Join-Path $ClassesRoot ($ext + '\OpenWithProgids')
    if (-not (Test-Path -LiteralPath $o)) { New-Item -Path $o -Force | Out-Null }   # 既にあるキーは作り直さない（作り直すと、他のソフトの登録が消える）。値を1つ足すだけ
    New-ItemProperty -Path $o -Name $progId -Value ([byte[]]@()) -PropertyType None -Force | Out-Null
  }
  if ($script:HaveExe) { Register-AppEntry $exeFile $icoFile0 }
  else { Remove-AppEntry $exeFile }   # exe が無いのに、前回の登録（存在しない exe を指す）が残らないようにする
}
Do-Action '旧い案内で作られた「アプリを選択して開く」の登録（開く.bat など）があれば、本ソフトのものだけ削除（本ソフトの 開く.bat、または本ソフトの app.ps1 のフルパスと一致するものだけ）' { Remove-LegacyAppRegistrations @((Join-Path $expected 'app.ps1'), (Join-Path (Join-Path $env:LOCALAPPDATA 'md読み込みソフト') 'app\app.ps1')) }

# 5. スタートメニュー
Step '5. スタートメニューにショートカットを作成'
Do-Action ($StartMenuDir + '\' + $appName + '.lnk を作成') {
  $ws = New-Object -ComObject WScript.Shell
  $s = $ws.CreateShortcut((Join-Path $StartMenuDir ($appName + '.lnk')))
  if ($script:HaveExe) { $s.TargetPath = $exeFile; $s.Arguments = '' }   # 以前の「引数」が残らないようにする
  else {
    $s.TargetPath = 'powershell.exe'
    $s.Arguments = '-NoProfile -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "' + (Join-Path $expected 'app.ps1') + '"'
  }
  $s.WorkingDirectory = $expected
  $s.WindowStyle = 7
  $s.Description = $appName
  $ico = Join-Path $expected 'assets\app.ico'
  if (Test-Path -LiteralPath $ico) { $s.IconLocation = $ico }
  $s.Save()
}

# 前の名前（md読み込みソフト）で登録していたものがあれば外す（このソフトが作った登録だけ）
Do-Action '前の名前の登録（.md の関連付け・スタートメニュー）があれば削除' {
  Remove-Item -Path (Join-Path $ClassesRoot $oldProgId) -Recurse -Force -ErrorAction SilentlyContinue
  foreach ($ext in '.md', '.markdown') {
    Remove-ItemProperty -Path (Join-Path $ClassesRoot ($ext + '\OpenWithProgids')) -Name $oldProgId -ErrorAction SilentlyContinue
  }
  $ol = Join-Path $StartMenuDir ($oldAppName + '.lnk'); if (Test-Path -LiteralPath $ol) { Remove-Item -LiteralPath $ol -Force }
}

# 旧試作の「Windows起動時に自動で動く」登録があれば外す（このソフトが作った古い登録だけ）
Do-Action '旧試作のスタートアップ登録（MdViewerSoftLab.lnk）があれば削除' {
  $old = Join-Path ([Environment]::GetFolderPath('Startup')) 'MdViewerSoftLab.lnk'
  if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Force }
}

Step '6. 完了'
if ($DryRun) { Say '  確認が終わりました。（何も変更していません）'; exit 0 }
Say '  インストールできました。次の手順で、.md をダブルクリックで開けるようにします。'
Say '   1. 開きたい .md ファイルを右クリックします。（Windows 11 は「その他のオプションを確認」を押します）'
Say '   2. 「プログラムから開く」→「別のプログラムを選択」を選びます。'
Say '   3. 一覧から「MDReader」を選び、「常にこのアプリを使う」を押します。'
Say '  ※一覧に出ないときは、スタートメニューの「MDReader」から開き、「ファイルを選ぶ」でも開けます。'
