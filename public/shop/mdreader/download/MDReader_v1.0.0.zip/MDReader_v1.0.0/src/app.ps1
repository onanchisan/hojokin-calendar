﻿# MDReader 入口
# 使い方: powershell -File app.ps1 [.mdのパス]
#  - すでにサーバーが動いていれば、新しいウィンドウを開いて終了
#  - 動いていなければ自分が 127.0.0.1 のサーバーになり、全ウィンドウが閉じて10秒たったら終了（常駐しない）
param([string]$Target = '')

$ErrorActionPreference = 'Continue'
$script:AppDir = $PSScriptRoot
$script:WebDir = Join-Path $PSScriptRoot 'web'
. (Join-Path $PSScriptRoot 'lib\common.ps1')
. (Join-Path $PSScriptRoot 'lib\store.ps1')
. (Join-Path $PSScriptRoot 'lib\update.ps1')
. (Join-Path $PSScriptRoot 'lib\files.ps1')
. (Join-Path $PSScriptRoot 'lib\http.ps1')

$script:Cfg = Load-Config $PSScriptRoot
$script:Port = 0
$script:Token = ''

function Show-FatalMessage([string]$msg) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show($msg, 'MDReader', 'OK', 'Warning')
  } catch { }
}

# ---- 既存サーバーの検出 ----
function Test-Ping([int]$port, [int]$expectPid) {
  try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$port/api/ping" -UseBasicParsing -TimeoutSec 2
    $j = ConvertFrom-JsonText ([string]$r.Content)
    if ((Get-Prop $j 'app' '') -eq 'md-viewer' -and ($expectPid -le 0 -or (Get-Prop $j 'pid' 0) -eq $expectPid)) { return $true }
  } catch { }
  return $false
}
function Get-RunningPort {
  $rf = Join-Path (Get-DataDir) 'run.json'
  $d = Read-JsonFile $rf -KeepBroken
  if ($d) {
    $p = [int](Get-Prop $d 'port' 0); $pd = [int](Get-Prop $d 'pid' 0)
    if ($p -gt 0 -and (Test-Ping $p $pd)) { return $p }
    try { Remove-Item -LiteralPath $rf -Force -ErrorAction SilentlyContinue } catch { }   # 古い記録
  }
  return 0
}

# ---- 表示ウィンドウ（Edge のアプリ表示） ----
# すでに動いている窓へ「このファイルをタブで開いて」と頼む。受け付けられたら $true（窓が無いときは $false）
function Send-Handoff([int]$port, [string]$target) {
  try {
    $d = Read-JsonFile (Join-Path (Get-DataDir) 'run.json') -KeepBroken
    $secret = [string](Get-Prop $d 'handoff' '')
    if (-not $secret) { return $false }
    $body = [Text.Encoding]::UTF8.GetBytes((ConvertTo-JsonText @{ path = $target }))
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$port/api/handoff" -Method Post -Headers @{ 'X-Mdv-Handoff' = $secret } -ContentType 'application/json' -Body $body -UseBasicParsing -TimeoutSec 5
    $j = ConvertFrom-JsonText ([string]$r.Content)
    return ((Get-Prop $j 'queued' $false) -eq $true)
  } catch { return $false }
}
# 既存の窓を前面に出す（見つからなくても何もしない）
function Focus-AppWindow {
  if ($script:IsDev -and $env:MDV_NOWINDOW -eq '1') { Write-AppLog 'FOCUS_SKIPPED_DEV' ''; return }
  try {
    $prof = Join-Path (Get-LocalDir) 'edge-profile'
    $ws = New-Object -ComObject WScript.Shell
    foreach ($p in @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction Stop)) {
      if ($p.CommandLine -and $p.CommandLine.Contains($prof) -and $p.CommandLine -notmatch '--type=') {
        if ($ws.AppActivate([int]$p.ProcessId)) { return }
      }
    }
    foreach ($p in @(Get-Process -Name msedge -ErrorAction SilentlyContinue)) {
      if ($p.MainWindowTitle -like '*MDReader*') { if ($ws.AppActivate([int]$p.Id)) { return } }
    }
  } catch { }
}
# 窓の開き方: 動いている窓があればそこへタブとして渡して前面へ。無ければ新しく開く
function Open-OrHandoff([int]$port, [string]$target) {
  if (Send-Handoff $port $target) { Write-AppLog 'HANDOFF_OK' ''; Focus-AppWindow; return }
  Open-AppWindow $port $target
}
function Open-AppWindow([int]$port, [string]$target) {
  if ($script:IsDev -and $env:MDV_NOWINDOW -eq '1') { Write-AppLog 'WINDOW_SKIPPED_DEV' ''; return }
  if ($target) { $url = "http://127.0.0.1:$port/app?path=" + [uri]::EscapeDataString($target) }
  else { $url = "http://127.0.0.1:$port/app" }
  $edge = Find-Edge
  if ($edge) {
    $a = "--app=$url --no-first-run --no-default-browser-check --disable-background-timer-throttling --window-size=1100,800"
    if ([bool](Get-Prop $script:Cfg 'edgeProfile' $true)) {
      $prof = Join-Path (Get-LocalDir) 'edge-profile'
      if (-not (Test-Path -LiteralPath $prof)) { New-Item -ItemType Directory -Path $prof -Force | Out-Null }
      $a += " --user-data-dir=`"$prof`""
    }
    try { Start-Process -FilePath $edge -ArgumentList $a | Out-Null; return } catch { Write-AppLog 'EDGE_START_FAIL' $_.Exception.GetType().Name }
  }
  try { Start-Process -FilePath $url | Out-Null } catch { Write-AppLog 'BROWSER_START_FAIL' '' }
}

# ---- 1. 引数 ----
$targetFull = ''
if ($Target) {
  try { $t = [IO.Path]::GetFullPath($Target) } catch { $t = '' }
  if ($t -and ($script:MdExt -contains [IO.Path]::GetExtension($t).ToLowerInvariant())) { $targetFull = $t }
}

Initialize-DataDir

# ---- 2. すでに動いているか ----
$running = Get-RunningPort
if ($running -gt 0) { Open-OrHandoff $running $targetFull; exit 0 }

# ---- 3. 同時起動の整理（ミューテックス） ----
$mutexName = 'Local\MdViewerSoftLab-v1'
if ($script:IsDev) { $mutexName += '-' + (Get-PathId (Get-DataDir)).Substring(0, 8) }
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($false, $mutexName)
try { $createdNew = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $createdNew = $true }
if (-not $createdNew) {
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 500
    $running = Get-RunningPort
    if ($running -gt 0) { Open-OrHandoff $running $targetFull; exit 0 }
  }
  Show-FatalMessage '起動できませんでした。いったんウィンドウをすべて閉じてから、もう一度お試しください。'
  Write-AppLog 'START_TIMEOUT' ''
  exit 1
}

# ---- 4. ポート決定（127.0.0.1 だけ） ----
$listener = $null
$base = 47821
if ($script:IsDev -and $env:MDV_PORT_BASE -match '^\d{4,5}$') { $base = [int]$env:MDV_PORT_BASE }
for ($p = $base; $p -lt ($base + 20); $p++) {
  $l = New-Object System.Net.HttpListener
  $l.Prefixes.Add("http://127.0.0.1:$p/")
  try { $l.Start(); $listener = $l; $script:Port = $p; break } catch { try { $l.Close() } catch { } }
}
if (-not $listener) {
  Write-AppLog 'PORT_EXHAUSTED' ''
  Show-FatalMessage '起動できませんでした。パソコンを再起動してから、もう一度お試しください。'
  try { $mutex.ReleaseMutex() } catch { }
  exit 1
}

# 既定のポートが使用中のとき、旧試作の常駐プロセスが原因かもしれないので調べて、画面で案内する（止めはしない）
$script:OldProto = $false
if ($script:Port -ne $base) {
  if ((Find-OldPrototype).Count -gt 0) { $script:OldProto = $true; Write-AppLog 'OLD_PROTOTYPE_RUNNING' '' }
}

# ---- 5. 起動の準備 ----
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
$script:Token = Get-RandomHex 32
$script:Handoff = Get-RandomHex 32
Load-Settings
$runFile = Join-Path (Get-DataDir) 'run.json'
try { Write-JsonAtomic $runFile ([ordered]@{ port = $script:Port; pid = $PID; startedAt = (Get-Iso8601Now); handoff = $script:Handoff }) } catch { Write-AppLog 'RUNJSON_FAIL' '' }
try {
  Get-ChildItem -LiteralPath ([IO.Path]::GetTempPath()) -Directory -Filter 'mdviewer-*' -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-1) } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
} catch { }
Write-AppLog 'START' ('port ' + $script:Port)

# ---- 6. ウィンドウを開く ----
Open-AppWindow $script:Port $targetFull

# ---- メインループ ----
$graceFirst = 40
if ($script:IsDev -and $env:MDV_GRACE_SEC -match '^\d+$') { $graceFirst = [int]$env:MDV_GRACE_SEC }
$everSeen = $false
$emptySince = Get-Date
$lastTick = Get-Date
$task = $listener.GetContextAsync()
try {
  while ($listener.IsListening) {
    if ($task.Wait(150)) {
      $ctx = $task.Result
      $task = $listener.GetContextAsync()
      Handle-Request $ctx
    }
    Step-PdfJobs
    Step-UpdateJob

    # 終了判定: ウィンドウ0個・PDFジョブ0件が10秒続いたら終了
    $now = Get-Date
    if (($now - $lastTick).TotalSeconds -gt 3) {
      $emptySince = $now   # ダイアログ表示などで止まっていた間は数えない
      foreach ($k in @($script:Windows.Keys)) { $script:Windows[$k] = $now }
    foreach ($k in @($script:Shells.Keys)) { $script:Shells[$k] = $now }
    }
    $lastTick = $now
    foreach ($k in @($script:Windows.Keys)) { if (($now - $script:Windows[$k]).TotalSeconds -gt 120) { $script:Windows.Remove($k) } }
    if ($script:Windows.Count -gt 0) { $everSeen = $true; $emptySince = $now }
    elseif ($script:PdfJobs.Count -gt 0) { $emptySince = $now }
    else {
      $limit = 10; if (-not $everSeen) { $limit = $graceFirst }
      if (($now - $emptySince).TotalSeconds -gt $limit) { break }
    }
  }
} finally {
  # ---- 終了処理 ----
  try { Stop-AllPdfJobs } catch { }
  try { $listener.Stop(); $listener.Close() } catch { }
  try { Remove-Item -LiteralPath $runFile -Force -ErrorAction SilentlyContinue } catch { }
  try { $mutex.ReleaseMutex() } catch { }
  Write-AppLog 'STOP' ''
}
