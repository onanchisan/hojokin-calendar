// インラインSVGアイコン（外部の画像・フォントは使わない）。<i data-ic="lock"></i> を絵に置き換える
(function () {
  'use strict';
  var P = {
    lock: '<rect x="3" y="7" width="10" height="7" rx="1.5"/><path d="M5 7V5a3 3 0 0 1 6 0v2"/>',
    folder: '<path d="M2 4.5h4l1.5 1.5H14v7H2z"/>',
    file: '<path d="M4 2h5l3 3v9H4z"/><path d="M9 2v3h3"/>',
    pen: '<path d="M3 13l1-3 7-7 2 2-7 7z"/>',
    marker: '<path d="M3 13h5M9 3l4 4-5 5-4-4z"/>',
    clock: '<circle cx="8" cy="8" r="6"/><path d="M8 4.5V8l2.5 1.5"/>',
    pdf: '<path d="M4 2h5l3 3v9H4z"/><path d="M9 2v3h3M6 10h4"/>',
    print: '<path d="M4 6V2h8v4M4 11H2V6h12v5h-2"/><rect x="4" y="9" width="8" height="5"/>',
    gear: '<circle cx="8" cy="8" r="2"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4"/>',
    more: '<circle cx="3.5" cy="8" r="1"/><circle cx="8" cy="8" r="1"/><circle cx="12.5" cy="8" r="1"/>',
    x: '<path d="M3.5 3.5l9 9M12.5 3.5l-9 9"/>',
    plus: '<path d="M8 3v10M3 8h10"/>',
    check: '<path d="M3 8.5l3.2 3L13 4.5"/>',
    warn: '<path d="M8 2l6.5 11.5h-13z"/><path d="M8 6.5v3.5M8 12v.2"/>',
    info: '<circle cx="8" cy="8" r="6"/><path d="M8 7.2V11M8 5v.2"/>',
    key: '<circle cx="5" cy="10" r="3"/><path d="M7.2 8L13 2.5M11 4.5l1.5 1.5"/>',
    trash: '<path d="M3 4.5h10M6 4.5V3h4v1.5M4.5 4.5l.7 9h5.6l.7-9"/>',
    copy: '<rect x="5.5" y="5.5" width="8" height="8" rx="1"/><path d="M10.5 5.5V3a1 1 0 0 0-1-1H3.5a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2"/>',
    list: '<path d="M5.5 4h8M5.5 8h8M5.5 12h8"/><circle cx="2.8" cy="4" r=".6"/><circle cx="2.8" cy="8" r=".6"/><circle cx="2.8" cy="12" r=".6"/>'
  };
  function sprite() {
    var s = '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>';
    Object.keys(P).forEach(function (k) { s += '<symbol id="i-' + k + '" viewBox="0 0 16 16">' + P[k] + '</symbol>'; });
    return s + '</defs></svg>';
  }
  function svg(name, cls) {
    var w = document.createElement('span');
    w.innerHTML = '<svg class="ic' + (cls ? ' ' + cls : '') + '" aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
    return w.firstChild;
  }
  function hydrate(root) {
    (root || document).querySelectorAll('i[data-ic]').forEach(function (i) {
      i.replaceWith(svg(i.getAttribute('data-ic'), i.getAttribute('data-cls') || ''));
    });
  }
  var holder = document.createElement('div');
  holder.innerHTML = sprite();
  document.body.insertBefore(holder.firstChild, document.body.firstChild);
  window.Icons = { svg: svg, hydrate: hydrate };
  hydrate();
})();
