// マーカー: 描画後のテキスト＋前後の文脈で位置を持つ。元の .md は書き換えない。
// ファイルを選んで開いたときは /api/marks に自動保存。ドラッグ＆ドロップで開いたときはメモリだけ。位置が見つからない線は消さずに一覧へ。
(function () {
  'use strict';
  var h = UI.h, btn = UI.btn;
  var BLOCK = 'p,li,h1,h2,h3,h4,h5,h6,td,th,blockquote,pre';
  var COLORS = ['yellow', 'green', 'pink', 'blue'];
  var CTX = 30;

  var root = null, path = null, localMode = false;
  var marks = [];            // {id,color,text,prefix,suffix,note,createdAt}
  var placed = {};           // id -> {start,end,exact}
  var lost = [];             // 位置不明の線
  var model = null;          // {T, blocks:[{el,start,text,nodes:[{node,off}]}]}
  var ownerArr = null;       // 文字ごとの持ち主（線の添字。-1 は線なし）
  var saveTimer = 0, firstToastShown = false, filter = 'all', panelEl = null, paletteEl = null;
  var palState = null;       // {mode:'sel'|'mark', mid, info}
  var changeCb = null;

  function nowIso() { var d = new Date(), p = function (n) { return ('0' + n).slice(-2); }; return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()); }
  function newId() { return 'm_' + Date.now().toString(36) + Math.floor(Math.random() * 46656).toString(36); }
  function canPersist() { return !!path && !localMode; }

  // ---- 表示テキストのモデル ----
  function buildModel() {
    var blocks = [], map = new Map();
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) { return n.parentElement && n.parentElement.closest('.blocked-img') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; }
    });
    var n;
    while ((n = walker.nextNode())) {
      var b = n.parentElement ? n.parentElement.closest(BLOCK) : null;
      if (!b || !root.contains(b)) {
        if (!/\S/.test(n.nodeValue)) continue;
        b = n;   // ブロックの外にある文字は、1つずつ独立したブロック扱い
      }
      var blk = map.get(b);
      if (!blk) { blk = { el: b, start: 0, text: '', nodes: [] }; map.set(b, blk); blocks.push(blk); }
      blk.nodes.push({ node: n, off: blk.text.length });
      blk.text += n.nodeValue;
    }
    var T = '';
    blocks.forEach(function (b2, i) { if (i) T += '\n'; b2.start = T.length; T += b2.text; });
    return { T: T, blocks: blocks };
  }
  function blockIndexAt(pos) {   // pos を含むブロック
    var bs = model.blocks, lo = 0, hi = bs.length - 1;
    while (lo < hi) { var mid = (lo + hi + 1) >> 1; if (bs[mid].start <= pos) lo = mid; else hi = mid - 1; }
    return lo;
  }
  function sameBlock(a, b) {   // [a,b) が1つのブロックに収まるか
    if (!model.blocks.length) return false;
    var i = blockIndexAt(a), blk = model.blocks[i];
    return b <= blk.start + blk.text.length;
  }
  function cSuffix(a, b) { var n = 0; while (n < a.length && n < b.length && a.charAt(a.length - 1 - n) === b.charAt(b.length - 1 - n)) n++; return n; }
  function cPrefix(a, b) { var n = 0; while (n < a.length && n < b.length && a.charAt(n) === b.charAt(n)) n++; return n; }

  // 1つの線の位置を探す。見つからない・曖昧なら null
  function locate(m) {
    var T = model.T, len = m.text.length, i = -1, cand = [];
    while ((i = T.indexOf(m.text, i + 1)) >= 0) {
      if (sameBlock(i, i + len)) cand.push(i);
      if (cand.length > 300) break;
    }
    if (!cand.length) return null;
    var pre = m.prefix || '', suf = m.suffix || '';
    var sc = cand.map(function (p) {
      var a = cSuffix(T.slice(Math.max(0, p - CTX), p), pre), b = cPrefix(T.slice(p + len, p + len + CTX), suf);
      return { p: p, score: a + b, full: (pre.length > 0 && a === pre.length) || (suf.length > 0 && b === suf.length) };
    });
    if (sc.length === 1) return { start: sc[0].p, end: sc[0].p + len };
    sc.sort(function (x, y) { return y.score - x.score; });
    if (sc[0].score === sc[1].score) return null;           // 同点 = 曖昧
    if (sc[0].full || sc[0].score >= 8) return { start: sc[0].p, end: sc[0].p + len };
    return null;
  }

  function unwrap() {
    root.querySelectorAll('mark.mk').forEach(function (m) {
      var p = m.parentNode;
      while (m.firstChild) p.insertBefore(m.firstChild, m);
      p.removeChild(m); p.normalize();
    });
  }

  // 全部の線を置き直す（描き直し）
  function refresh() {
    if (!root) return;
    unwrap();
    model = buildModel();
    placed = {}; lost = [];
    var owner = new Int32Array(model.T.length).fill(-1);
    marks.forEach(function (m, k) {
      var r = locate(m);
      if (!r) { lost.push(m); return; }
      placed[m.id] = r;
      owner.fill(k, r.start, r.end);
    });
    ownerArr = owner;
    // 同じ持ち主が続く範囲ごとに、文字ノードを分けて <mark> で包む
    var tasks = [];   // {node, s, e, k}
    model.blocks.forEach(function (b) {
      var i = b.start, end = b.start + b.text.length;
      while (i < end) {
        var k = owner[i];
        if (k < 0) { i++; continue; }
        var j = i; while (j < end && owner[j] === k) j++;
        b.nodes.forEach(function (nd) {
          var ns = b.start + nd.off, ne = ns + nd.node.nodeValue.length;
          var s = Math.max(i, ns), e = Math.min(j, ne);
          if (e > s) tasks.push({ node: nd.node, s: s - ns, e: e - ns, k: k });
        });
        i = j;
      }
    });
    var byNode = new Map();
    tasks.forEach(function (t) { var a = byNode.get(t.node); if (!a) { a = []; byNode.set(t.node, a); } a.push(t); });
    byNode.forEach(function (arr, node) {
      arr.sort(function (a, b) { return b.s - a.s; });
      arr.forEach(function (t) {
        var target = node;
        if (t.e < node.nodeValue.length) node.splitText(t.e);
        if (t.s > 0) target = node.splitText(t.s);
        var m = marks[t.k];
        var el = document.createElement('mark');
        el.className = 'mk mk-' + m.color;
        el.setAttribute('data-mid', m.id);
        target.parentNode.insertBefore(el, target);
        el.appendChild(target);
      });
    });
    renderPanel();
    notify();
  }
  function notify() { if (changeCb) changeCb({ unsaved: unsavedCount(), lost: lost.length, total: marks.length }); }
  function unsavedCount() { return canPersist() ? 0 : marks.length; }

  // ---- 保存 ----
  function scheduleSave() {
    if (!canPersist()) return;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(doSave, 500);
  }
  function doSave() {
    if (!canPersist()) return;
    model = buildModel();
    var T = model.T;
    var out = marks.map(function (m) {
      var r = placed[m.id];
      var pre = m.prefix, suf = m.suffix;
      if (r) { pre = T.slice(Math.max(0, r.start - CTX), r.start); suf = T.slice(r.end, r.end + CTX); }   // 文脈を最新にする
      return { id: m.id, color: m.color, text: m.text, prefix: pre, suffix: suf, note: m.note || '', createdAt: m.createdAt };
    });
    return Api.put('/api/marks', { path: path, marks: out }).then(function (r) {
      if (!r.ok && r.status !== 402) UI.toast(S.marks.saveFail, { kind: 'warn' });
    });
  }
  function changed() { refresh(); scheduleSave(); hidePalette(); }

  // ---- 選択 → 線 ----
  function selectionInfo() {
    var sel = window.getSelection();
    if (!root || !sel || !sel.rangeCount || sel.isCollapsed) return null;
    var r = sel.getRangeAt(0);
    if (!root.contains(r.commonAncestorContainer)) return null;
    model = buildModel();
    var pieces = [];
    model.blocks.forEach(function (b, bi) {
      b.nodes.forEach(function (nd) {
        if (!r.intersectsNode(nd.node)) return;
        var s = nd.node === r.startContainer ? r.startOffset : 0;
        var e = nd.node === r.endContainer ? r.endOffset : nd.node.nodeValue.length;
        if (e > s) pieces.push({ bi: bi, gs: b.start + nd.off + s, ge: b.start + nd.off + e });
      });
    });
    if (!pieces.length) return null;
    var bi0 = pieces[0].bi, gs = Infinity, ge = -1;
    for (var i = 0; i < pieces.length; i++) {
      if (pieces[i].bi !== bi0) return { error: 'multi', rect: r.getBoundingClientRect() };
      gs = Math.min(gs, pieces[i].gs); ge = Math.max(ge, pieces[i].ge);
    }
    var T = model.T;
    while (gs < ge && /\s/.test(T.charAt(gs))) gs++;
    while (ge > gs && /\s/.test(T.charAt(ge - 1))) ge--;
    if (ge <= gs) return null;
    if (ge - gs > 2000) return { error: 'long', rect: r.getBoundingClientRect() };
    return { gs: gs, ge: ge, text: T.slice(gs, ge), rect: r.getBoundingClientRect() };
  }
  function removeIdx(list) {
    var kill = {}; list.forEach(function (k) { kill[marks[k].id] = 1; });
    marks = marks.filter(function (m) { return !kill[m.id]; });
  }

  var Marks = {
    init: function (rootEl, filePath, isLocal, onChange) {
      root = rootEl; path = filePath; localMode = !!isLocal; changeCb = onChange || null; marks = [];
      buildPalette();
      root.addEventListener('click', function (e) {
        var el = e.target.closest ? e.target.closest('mark.mk') : null;
        var sel = window.getSelection();
        if (!el || (sel && !sel.isCollapsed)) return;
        showPalette(el.getBoundingClientRect(), { mode: 'mark', mid: el.getAttribute('data-mid') });
      });
      var check = function (e) {
        if (paletteEl && paletteEl.contains(e.target)) return;
        setTimeout(function () {
          if (document.body.classList.contains('mode-edit')) return;
          var info = selectionInfo();
          if (info) showPalette(info.rect, { mode: 'sel', info: info });
          else if (!palState || palState.mode !== 'mark') hidePalette();
        }, 0);
      };
      document.addEventListener('mouseup', check);
      document.addEventListener('keyup', function (e) { if (e.shiftKey || /^Arrow|Home|End/.test(e.key)) check(e); });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hidePalette(); });
      window.addEventListener('scroll', function () { if (palState && paletteEl && !paletteEl.hidden) hidePalette(); }, true);
      document.addEventListener('mousedown', function (e) {
        if (paletteEl && !paletteEl.hidden && !paletteEl.contains(e.target) && !(e.target.closest && e.target.closest('mark.mk'))) { if (palState && palState.mode === 'mark') hidePalette(); }
      });
    },
    // 保存済みの線を読む。読み終わったら描く
    load: function () {
      if (canPersist()) {
        return Api.get('/api/marks', { path: path }).then(function (r) {
          if (r.ok && !r.data.locked) {
            marks = (r.data.marks || []);
            if (r.data.recovered) UI.toast('線の保存ファイルが壊れていたため、読み込めませんでした。', { kind: 'warn' });
          }
          refresh();
        });
      }
      refresh();
      return Promise.resolve();
    },
    refresh: refresh,
    draw: function (color) {
      var info = palState && palState.mode === 'sel' ? palState.info : selectionInfo();
      if (palState && palState.mode === 'mark') return recolorMark(palState.mid, color);
      if (!info || info.error) return;
      model = buildModel();
      var gs = info.gs, ge = info.ge, T = model.T;
      var hit = ownersInOwner(ownerArr, gs, ge);
      if (hit.length && coveredBy(ownerArr, gs, ge, color)) { removeIdx(hit); changed(); return; }   // 同じ色をもう一度 → 消す
      // 新しい線に完全に含まれる古い線は置き換える
      var inside = hit.filter(function (k) { var r = placed[marks[k].id]; return r && r.start >= gs && r.end <= ge; });
      removeIdx(inside);
      marks.push({ id: newId(), color: color, text: info.text, prefix: T.slice(Math.max(0, gs - CTX), gs), suffix: T.slice(ge, ge + CTX), note: '', createdAt: nowIso()});
      if (!canPersist() && !firstToastShown) { firstToastShown = true; UI.toast(S.marks.firstToast); }
      window.getSelection().removeAllRanges();
      changed();
    },
    erase: function () {
      if (palState && palState.mode === 'mark') { removeById(palState.mid); changed(); return; }
      var info = selectionInfo();
      if (!info || info.error) return;
      var hit = ownersInOwner(ownerArr, info.gs, info.ge);
      if (!hit.length) return;
      removeIdx(hit); window.getSelection().removeAllRanges(); changed();
    },
    clearAll: function () { marks = []; changed(); },
    count: function () { return marks.length; },
    unsavedCount: unsavedCount,
    lostCount: function () { return lost.length; },
    openPanel: function (el) { panelEl = el; el.hidden = false; renderPanel(); },
    closePanel: function () { if (panelEl) panelEl.hidden = true; },
    panelOpen: function () { return panelEl && !panelEl.hidden; },
    // 印刷用ページ: 保存済みの線だけを描く
    loadForPrint: function () { return Marks.load(); }
  };

  function ownersInOwner(owner, gs, ge) {
    var ks = {}, res = [];
    if (!owner) return res;
    for (var i = gs; i < ge && i < owner.length; i++) { var k = owner[i]; if (k >= 0 && !ks[k]) { ks[k] = 1; res.push(k); } }
    return res;
  }
  function coveredBy(owner, gs, ge, color) {
    for (var i = gs; i < ge; i++) {
      if (/\s/.test(model.T.charAt(i))) continue;
      var k = owner[i]; if (k < 0 || marks[k].color !== color) return false;
    }
    return true;
  }
  function removeById(id) { marks = marks.filter(function (m) { return m.id !== id; }); }
  function recolorMark(id, color) {
    var m = marks.filter(function (x) { return x.id === id; })[0];
    if (!m) return;
    if (m.color === color) removeById(id); else m.color = color;
    changed();
  }

  // ---- パレット ----
  function buildPalette() {
    if (paletteEl) return;
    paletteEl = h('div', { id: 'markPalette', class: 'palette', role: 'toolbar', 'aria-label': 'マーカー', hidden: true });
    paletteEl.addEventListener('mousedown', function (e) { e.preventDefault(); });
    document.body.appendChild(paletteEl);
  }
  function showPalette(rect, st) {
    palState = st;
    paletteEl.textContent = '';
    var row = h('div', { class: 'row' });
    var blocked = st.mode === 'sel' && st.info.error;
    var onColor = null;
    if (st.mode === 'mark') { var mm = marks.filter(function (x) { return x.id === st.mid; })[0]; onColor = mm ? mm.color : null; }
    else if (!blocked && ownerArr) { COLORS.forEach(function (c) { var ow = ownersInOwner(ownerArr, st.info.gs, st.info.ge); if (ow.length && coveredBy(ownerArr, st.info.gs, st.info.ge, c)) onColor = c; }); }
    COLORS.forEach(function (c, i) {
      row.appendChild(h('button', { type: 'button', class: 'dot dot-' + c + (onColor === c ? ' on' : ''), disabled: blocked, 'aria-label': S.marks.drawAria(c), title: S.marks.colors[c] + '（Alt+' + (i + 1) + '）', onclick: function () { Marks.draw(c); } }));
    });
    row.appendChild(btn(S.marks.erase, 'tool small', function () { Marks.erase(); }, { id: 'mkErase', title: 'Alt+0' }));
    paletteEl.appendChild(row);
    if (blocked) paletteEl.appendChild(h('div', { class: 'pnote', text: S.marks.oneBlock }));
    else if (!canPersist()) {
      paletteEl.appendChild(h('div', { class: 'pnote', text: S.marks.localLine }));
    }
    paletteEl.hidden = false;
    var w = paletteEl.offsetWidth, ph = paletteEl.offsetHeight;
    var top = rect.top - ph - 10;
    if (top < 56) top = rect.bottom + 10;
    var left = Math.max(8, Math.min(window.innerWidth - w - 8, rect.left + rect.width / 2 - w / 2));
    paletteEl.style.top = top + 'px'; paletteEl.style.left = left + 'px';
  }
  function hidePalette() { if (paletteEl) paletteEl.hidden = true; palState = null; }

  // ---- 一覧パネル ----
  function excerpt(m) {
    var r = placed[m.id], T = model ? model.T : '';
    var frag = document.createDocumentFragment();
    if (!r) { frag.appendChild(document.createTextNode('「' + m.text.slice(0, 80) + '」')); return frag; }
    var pre = T.slice(Math.max(0, r.start - 15), r.start).replace(/\n/g, ' '), post = T.slice(r.end, r.end + 15).replace(/\n/g, ' ');
    var mid = m.text.length > 60 ? m.text.slice(0, 60) + '…' : m.text;
    frag.appendChild(document.createTextNode('…' + pre)); frag.appendChild(h('strong', { text: mid.replace(/\n/g, ' ') })); frag.appendChild(document.createTextNode(post + '…'));
    return frag;
  }
  function renderPanel() {
    if (!panelEl || panelEl.hidden) { updateLostBar(); return; }
    panelEl.textContent = '';
    panelEl.appendChild(h('div', { class: 'side-head' }, h('span', { class: 't', id: 'mkPanelHead', text: S.marks.panelTitle }),
      h('button', { type: 'button', class: 'btn icon', id: 'mkPanelClose', 'aria-label': S.closeBtn, title: S.closeBtn, onclick: Marks.closePanel }, Icons.svg('x'))));
    panelEl.appendChild(h('div', { class: 'note', style: 'padding:6px 12px 0', text: S.marks.total(marks.length) }));
    var fl = h('div', { class: 'mk-filter' });
    [['all', S.marks.filterAll]].concat(COLORS.map(function (c) { return [c, S.marks.colors[c]]; })).forEach(function (p) {
      fl.appendChild(h('button', { type: 'button', class: p[0] === filter ? 'on' : '', text: p[1], onclick: function () { filter = p[0]; renderPanel(); } }));
    });
    panelEl.appendChild(fl);
    var items = marks.filter(function (m) { return placed[m.id] && (filter === 'all' || m.color === filter); })
      .sort(function (a, b) { return placed[a.id].start - placed[b.id].start; });
    if (!marks.length) panelEl.appendChild(h('div', { id: 'mkEmpty', class: 'note', style: 'padding:12px', text: S.marks.empty }));
    items.forEach(function (m) {
      panelEl.appendChild(h('div', { class: 'mk-item', 'data-mid': m.id },
        h('div', { class: 'ex' }, h('span', { class: 'dot dot-' + m.color }), h('span', null, excerpt(m))),
        m.note ? h('div', { class: 'note', text: 'メモ: ' + m.note }) : null,
        h('div', { class: 'acts' },
          btn(S.marks.go, 'small mk-go', function () { goTo(m.id); }), btn(S.marks.copy, 'small mk-copy', function () { UI.copyText(m.text); }),
          btn(S.marks.del, 'small mk-del', function () { delWithUndo(m); }))));
    });
    if (lost.length) {
      panelEl.appendChild(h('div', { class: 'mk-lost-head', id: 'mkLost', text: '△ ' + S.marks.lostHead(lost.length) }));
      lost.forEach(function (m) {
        panelEl.appendChild(h('div', { class: 'mk-item lost', 'data-mid': m.id },
          h('div', { class: 'ex' }, h('span', { class: 'dot dot-' + m.color }), h('span', null, excerpt(m))),
          h('div', { class: 'note', text: S.marks.lostText }),
          h('div', { class: 'acts' }, btn(S.marks.copy, 'small mk-copy', function () { UI.copyText(m.text); }), btn(S.marks.del, 'small mk-del', function () { delWithUndo(m); }))));
      });
    }
    updateLostBar();
  }
  function goTo(id) {
    var el = root.querySelector('mark[data-mid="' + id + '"]');
    if (!el) return;
    el.scrollIntoView({ block: 'center' });
    var all = root.querySelectorAll('mark[data-mid="' + id + '"]');
    all.forEach(function (x) { x.classList.add('mk-flash'); });
    setTimeout(function () { all.forEach(function (x) { x.classList.remove('mk-flash'); }); }, 2000);
  }
  function delWithUndo(m) {
    var idx = marks.indexOf(m);
    removeById(m.id); changed();
    UI.toast(S.marks.deleted, { action: { label: S.marks.undo, fn: function () { marks.splice(Math.min(idx, marks.length), 0, m); changed(); } } });
  }
  function updateLostBar() {
    var bar = document.getElementById('lostBar');
    if (!bar) return;
    bar.textContent = '';
    bar.hidden = !lost.length;
    if (bar.hidden) return;
    bar.className = 'banner warn';
    bar.appendChild(Icons.svg('warn'));
    bar.appendChild(h('span', { class: 'grow', text: S.marks.lostBar(lost.length) }));
    bar.appendChild(btn(S.marks.lostBarLink, 'link', function () { var p = document.getElementById('markPanel'); if (p) Marks.openPanel(p); }));
    bar.appendChild(btn(S.closeBtn, 'link', function () { bar.hidden = true; }));
  }

  window.Marks = Marks;
})();
