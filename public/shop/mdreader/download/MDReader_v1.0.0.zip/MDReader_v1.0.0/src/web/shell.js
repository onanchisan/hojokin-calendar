// 親ページ（1つの窓）: タブ列と、タブごとの iframe（/view = 文書、/home = ホーム）を管理する。
// 文書の表示・マーカー・編集は、各タブの中の既存の画面（viewer.js ほか）が行うので、タブごとに状態（スクロール・線・編集中の内容）が別々に保たれる。
// 2つ目の起動（.md のダブルクリックなど）からの「開いてほしい .md」は、hb の返事で受け取り、新しいタブとして追加する。
(function () {
  'use strict';
  var h = UI.h;
  var MAX = 20;                         // タブの上限
  var tablist = document.getElementById('tablist');
  var framesEl = document.getElementById('frames');
  var addBtn = document.getElementById('tabAdd');
  var tabs = [], active = null, seq = 0;

  // 比較用に、パスをそろえる（/ と \、大文字小文字、.. を整理）
  function norm(p) {
    var s = String(p).replace(/[ .]+$/, '').replace(/\//g, '\\');   // 末尾の空白・ドットは無視（サーバーの正式パスと合わせる）
    var m = /^([A-Za-z]:)\\?(.*)$/.exec(s);
    if (!m) return s.toLowerCase();
    var out = [];
    m[2].split('\\').forEach(function (x) { if (!x || x === '.') return; if (x === '..') { out.pop(); return; } out.push(x); });
    return (m[1] + '\\' + out.join('\\')).toLowerCase();
  }
  function baseName(p) { return String(p).replace(/^.*[\\/]/, ''); }
  function frameWin(t) { try { return t.frame.contentWindow; } catch (e) { return null; } }
  function find(kind, key) { for (var i = 0; i < tabs.length; i++) if (tabs[i].kind === kind && tabs[i].key === key) return tabs[i]; return null; }

  function setWindowTitle() { document.title = (active && active.label ? active.label + ' - ' : '') + 'MDReader'; }

  function activate(t) {
    active = t;
    tabs.forEach(function (x) {
      var on = x === t;
      x.el.setAttribute('aria-selected', on ? 'true' : 'false');
      x.main.setAttribute('tabindex', on ? '0' : '-1');
      x.frame.classList.toggle('off', !on);
    });
    try { t.el.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) { }
    setWindowTitle();
    var w = frameWin(t); try { if (w) w.focus(); } catch (e2) { }
  }

  function addTab(kind, key, url, label, path) {
    var id = 't' + (++seq);
    var frame = h('iframe', { class: 'tabframe off', src: url, title: label });
    var lab = h('span', { class: 'tab-label', text: label });
    var dot = h('span', { class: 'tab-dot', text: '●', hidden: true, 'aria-label': '未保存' });
    var main = h('button', { type: 'button', class: 'tab-main', role: 'tab' }, lab, dot);
    var x = h('button', { type: 'button', class: 'tab-x', 'aria-label': S.tabs.close(label), title: '閉じる' }, Icons.svg('x'));
    var el = h('div', { class: 'tab', 'data-tab': id, title: path || label }, main, x);
    var t = { id: id, kind: kind, key: key, path: path || '', label: label, defLabel: label, dirty: false, el: el, main: main, lab: lab, dot: dot, x: x, frame: frame };
    main.addEventListener('click', function () { activate(t); });
    x.addEventListener('click', function (e) { e.stopPropagation(); closeTab(t); });
    el.addEventListener('auxclick', function (e) { if (e.button === 1) { e.preventDefault(); closeTab(t); } });
    enableDrag(t);
    tablist.appendChild(el);
    framesEl.appendChild(frame);
    tabs.push(t);
    return t;
  }

  // タブをマウスでつかんで左右に動かし、並び順を変える（5px 以上動かしたときだけ。ただのクリックは切り替え）
  function enableDrag(t) {
    var startX = 0, dragging = false, pid = null, justDragged = false;
    t.main.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) return;
      startX = e.clientX; dragging = false; pid = e.pointerId;
      try { t.main.setPointerCapture(pid); } catch (x) { }   // 速く動かしてタブの外に出ても、動きを受け取り続ける
    });
    t.main.addEventListener('pointermove', function (e) {
      if (pid !== e.pointerId) return;
      if (!dragging) {
        if (Math.abs(e.clientX - startX) < 5) return;
        dragging = true; t.el.classList.add('dragging');
      }
      // マウスの位置を越えた隣のタブと、越えなくなるまで入れ替える（速く動かしても追いつく）
      for (var n = 0; n < tabs.length; n++) {
        var i = tabs.indexOf(t), prev = tabs[i - 1], next = tabs[i + 1], r;
        if (prev && (r = prev.el.getBoundingClientRect()) && e.clientX < r.left + r.width / 2) { tablist.insertBefore(t.el, prev.el); tabs.splice(i, 1); tabs.splice(i - 1, 0, t); continue; }
        if (next && (r = next.el.getBoundingClientRect()) && e.clientX > r.left + r.width / 2) { tablist.insertBefore(next.el, t.el); tabs.splice(i, 1); tabs.splice(i + 1, 0, t); continue; }
        break;
      }
    });
    function end(e) {
      if (pid !== e.pointerId) return;
      pid = null;
      if (dragging) { dragging = false; justDragged = true; t.el.classList.remove('dragging'); setTimeout(function () { justDragged = false; }, 0); }
    }
    t.main.addEventListener('pointerup', end);
    t.main.addEventListener('pointercancel', end);
    t.main.addEventListener('click', function (e) { if (justDragged) { e.stopImmediatePropagation(); } }, true);
  }

  function removeTab(t) {
    var i = tabs.indexOf(t); if (i < 0) return;
    tabs.splice(i, 1);
    t.el.remove(); t.frame.remove();
    if (!tabs.length) { MDTabs.openHome(); return; }
    if (active === t) activate(tabs[Math.min(i, tabs.length - 1)]);
  }
  // 未保存の編集（またはドロップで開いて保存されない線）があるタブは、確認してから閉じる
  function closeTab(t) {
    var w = frameWin(t), needs = false;
    try { needs = !!(w && w.MDTab && w.MDTab.needsConfirm()); } catch (e) { }
    if (needs) { activate(t); try { w.MDTab.confirmClose(function () { removeTab(t); }); return; } catch (e2) { } }
    removeTab(t);
  }

  // 新しいタブを置く前の共通処理: 上限チェック。最初のホームだけのときは、ホームのタブを置き換える
  function room() {
    if (tabs.length >= MAX) { UI.toast(S.tabs.limit, { kind: 'warn' }); return false; }
    return true;
  }
  function afterAdd(t, replaceHome) {
    activate(t);
    if (replaceHome) removeTab(replaceHome);
  }
  function pristineHome() { return (tabs.length === 1 && tabs[0].kind === 'home') ? tabs[0] : null; }

  var MDTabs = {
    // .md をタブで開く（同じファイルが開いていれば、そのタブへ切り替える）
    open: function (p) {
      p = String(p || ''); if (!p) return false;
      var key = norm(p), ex = find('file', key);
      if (ex) { activate(ex); return true; }
      var ph = pristineHome();
      if (!ph && !room()) return false;
      var t = addTab('file', key, '/view?path=' + encodeURIComponent(p) + '&tab=1', baseName(p), p);
      afterAdd(t, ph);
      return true;
    },
    openHome: function () {
      var ex = find('home', 'home');
      if (ex) { activate(ex); return true; }
      if (!room()) return false;
      var t = addTab('home', 'home', '/home?tab=1', S.tabs.home, '');
      afterAdd(t, null);
      return true;
    },
    // ドラッグ＆ドロップで開いた文書（ファイルの場所が無い）。毎回新しいタブ
    openLocal: function (lk) {
      var ph = pristineHome();
      if (!ph && !room()) return false;
      var t = addTab('local', lk, '/view?local=1&lk=' + encodeURIComponent(lk) + '&tab=1', S.tabs.loading, '');
      afterAdd(t, ph);
      return true;
    },
    // どれかのタブで配色などの設定が変わったとき、窓全体（ほかのタブ）にも反映する
    broadcast: function (state, from) {
      Api.setState(state, true);
      tabs.forEach(function (t) { var w = frameWin(t); try { if (w && w !== from && w.Api) w.Api.setState(state, true); } catch (e) { } });
    },
    count: function () { return tabs.length; },
    // Ctrl+F4: 表示中のタブだけを閉じる（未保存なら確認）
    closeActive: function () { if (active) closeTab(active); }
  };
  window.MDTabs = MDTabs;

  function pickAndOpen() {
    Api.post('/api/pick', {}).then(function (r) { if (r.ok && r.data.path) MDTabs.open(r.data.path); });
  }
  addBtn.title = S.tabs.add; addBtn.setAttribute('aria-label', S.tabs.add);
  addBtn.addEventListener('click', pickAndOpen);
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'o' || e.key === 'O')) { e.preventDefault(); pickAndOpen(); }
    if (e.ctrlKey && e.key === 'F4') { e.preventDefault(); MDTabs.closeActive(); }
  });

  // 各タブの表示名（文書のタイトル）と未保存の印を、1秒ごとに写す。あわせて親ページの生存通知と、2つ目の起動からの受け渡しを受け取る
  function tick() {
    tabs.forEach(function (t) {
      var title = '';
      try { title = t.frame.contentDocument.title || ''; } catch (e) { }
      var dirty = /^● /.test(title);
      var label = title.replace(/^● /, '').replace(/ - MDReader$/, '');
      if (t.kind === 'home') label = S.tabs.home;
      else if (!label || label === 'MDReader') label = t.defLabel;
      if (label !== t.label) { t.label = label; t.lab.textContent = label; t.el.title = t.path || label; t.x.setAttribute('aria-label', S.tabs.close(label)); if (t === active) setWindowTitle(); }
      if (dirty !== t.dirty) { t.dirty = dirty; t.dot.hidden = !dirty; }
    });
    Api.post('/api/hb', { id: Api.windowId, shell: true }).then(function (r) {
      var list = (r && r.ok && r.data && r.data.open) || [];
      list.forEach(function (p) { MDTabs.open(p); });
    });
  }
  setInterval(tick, 1000);

  // 窓を閉じようとしたとき、未保存のタブがあれば確認（ブラウザの標準の確認）
  window.addEventListener('beforeunload', function (e) {
    var any = tabs.some(function (t) { var w = frameWin(t); try { return !!(w && w.MDTab && w.MDTab.needsConfirm()); } catch (x) { return false; } });
    if (any) { e.preventDefault(); e.returnValue = ''; }
  });

  Api.onDisconnect = function () {
    var nb = document.getElementById('noticeBar');
    if (!document.getElementById('netErr')) nb.appendChild(h('div', { class: 'banner err', id: 'netErr' }, Icons.svg('warn'), h('span', { class: 'grow', text: S.state.disconnected[0] + '。' + S.state.disconnected[1] })));
  };

  // 起動: ?path= があればそのファイルを、無ければホームを開く
  var first = new URLSearchParams(location.search).get('path');
  if (first) MDTabs.open(first); else MDTabs.openHome();
  Api.loadState().then(function () {
    if (Api.state && Api.state.settings.updateCheck === 'ask') Settings.firstRun(Update.init); else Update.init();
  });
})();
