// 簡易編集（左右分割）と保存フロー。保存は確認 → 外部変更の検知 → .bak → 一時ファイル → 入れ替え（サーバー側）
(function () {
  'use strict';
  var h = UI.h, btn = UI.btn;
  var V = null;             // viewer.js から渡される窓口 {doc, renderInto, afterExit, setNotice}
  var ta, prev, dirtyChip, saveBtn, stat, view, enc, active = false, baseline = '', dirty = false, prevTimer = 0, busy = false, ignoreSha = '';

  function $(id) { return document.getElementById(id); }
  function setDirty(v) {
    dirty = v;
    dirtyChip.hidden = !v;
    saveBtn.disabled = !v || busy;
    var t = document.title.replace(/^● /, '');
    document.title = v ? '● ' + t : t;
  }
  function updateStat() {
    var v = ta.value, pos = ta.selectionStart || 0, before = v.slice(0, pos).split('\n');
    stat.textContent = S.edit.stat(before.length, before[before.length - 1].length + 1, v.split('\n').length);
  }
  function schedulePreview() { clearTimeout(prevTimer); prevTimer = setTimeout(function () { V.renderInto(prev, ta.value); }, 350); }
  function flashSaved() {
    dirtyChip.hidden = false; dirtyChip.textContent = S.edit.saved;
    setTimeout(function () { dirtyChip.textContent = S.edit.dirty; if (!dirty) dirtyChip.hidden = true; }, 2000);
  }

  var Editor = {
    init: function (viewer) {
      V = viewer;
      ta = $('editor'); prev = $('preview'); dirtyChip = $('dirty'); saveBtn = $('btnSave'); stat = $('editStat'); view = $('editView'); enc = $('encInfo');
      dirtyChip.textContent = S.edit.dirty;
      ta.addEventListener('input', function () { setDirty(ta.value !== baseline); schedulePreview(); updateStat(); });
      ['keyup', 'click', 'select'].forEach(function (ev) { ta.addEventListener(ev, updateStat); });
      saveBtn.addEventListener('click', function () { Editor.save(false); });
      $('btnBackView').addEventListener('click', function () { Editor.leave(); });
      $('tabEdit').addEventListener('click', function () { view.className = 'split show-edit'; $('tabEdit').classList.add('on'); $('tabPrev').classList.remove('on'); });
      $('tabPrev').addEventListener('click', function () { view.className = 'split show-prev'; $('tabPrev').classList.add('on'); $('tabEdit').classList.remove('on'); V.renderInto(prev, ta.value); });
      window.addEventListener('beforeunload', function (e) { if (active && dirty) { e.preventDefault(); e.returnValue = ''; } });
      window.addEventListener('focus', function () { if (active) Editor.checkExternal(); });
    },
    isActive: function () { return active; },
    isDirty: function () { return active && dirty; },
    // 編集モードに入る（無料でも使える）。UTF-8以外は帯だけ
    enter: function () {
      var d = V.doc;
      if (V.local || !d.path) { UI.toast(S.noLocalFeature, { kind: 'warn' }); return; }
      if (d.enc !== 'utf8' && d.enc !== 'utf8bom') { V.setNotice('enc', 'info', S.edit.notUtf8); return; }
      active = true; ignoreSha = '';
      document.body.classList.add('mode-edit');
      $('layout').hidden = true; view.hidden = false; view.className = 'split show-edit';
      $('tabEdit').classList.add('on'); $('tabPrev').classList.remove('on');
      ta.value = d.text; baseline = ta.value;
      enc.textContent = S.edit.encInfo(d.enc, d.eol);
      setDirty(false); updateStat(); V.renderInto(prev, ta.value);
      ta.focus();
    },
    leave: function () {
      if (!active) return;
      if (!dirty) { Editor.exit(); return; }
      var d = UI.dialog({
        title: S.edit.leaveTitle, width: 440, icon: 'warn', body: h('p', { text: S.edit.leaveText(V.doc.name) }),
        foot: [btn(S.edit.discard, 'danger', function () { d.close('discard'); Editor.exit(); }),
          btn(S.edit.cancel, '', function () { d.close('cancel'); }, { id: 'lvCancel' }),
          btn(S.edit.saveBack, 'primary', function () { d.close('save'); Editor.save(true); })]
      });
      d.el.querySelector('#lvCancel').focus();
    },
    exit: function () {
      active = false; setDirty(false);
      document.body.classList.remove('mode-edit');
      view.hidden = true; $('layout').hidden = false;
      V.setNotice('ext', null);
      V.afterExit();
    },
    // 保存。確認ダイアログ（省略できない。仕様 9-3）→ サーバーへ
    save: function (thenExit) {
      if (!active || busy) return;
      if (!dirty && !thenExit) return;
      if (!dirty) { Editor.exit(); return; }
      var d = UI.dialog({
        title: S.edit.saveTitle, width: 440,
        body: [h('p', { text: S.edit.saveText(V.doc.name) }), h('p', { text: S.edit.saveBak(V.doc.name) }), h('p', { class: 'note', text: S.edit.saveBakNote })]
          .concat(V.doc.eolMixed ? [h('p', { class: 'note', text: S.edit.mixedEol(V.doc.eol === 'crlf' ? 'CRLF' : 'LF') })] : []),
        foot: [btn(S.edit.cancel, '', function () { d.close('cancel'); }, { id: 'svCancel' }),
          btn(S.edit.doSave, 'primary', function () {
            d.close('ok');
            doSave(false, thenExit);
          })]
      });
      d.el.querySelector('#svCancel').focus();
    },
    // 他のソフトで変わっていないか（ウィンドウに戻ってきたとき）
    checkExternal: function () {
      var d = V.doc;
      if (!d.path || busy) return;
      Api.get('/api/md', { path: d.path }).then(function (r) {
        if (!active || !r.ok) return;
        var sha = r.headers.get('X-Mdv-Sha256');
        if (sha && sha !== d.stamp.sha256 && sha !== ignoreSha) {
          V.setNotice('ext', 'warn', S.edit.changedBar, [
            { label: S.edit.reloadLatest, fn: function () { V.setNotice('ext', null); V.reloadDoc().then(function () { ta.value = V.doc.text; baseline = ta.value; setDirty(false); updateStat(); V.renderInto(prev, ta.value); }); } },
            { label: S.edit.keepEditing, fn: function () { ignoreSha = sha; V.setNotice('ext', null); } }
          ]);
        }
      });
    }
  };

  function failDialog(title, lines, withSaveAs) {
    var foot = [btn(S.edit.close, '', function () { d.close('x'); })];
    if (withSaveAs) foot.push(btn(S.edit.saveAs, 'primary', function () { d.close('as'); saveAs(); }));
    var d = UI.dialog({ title: title, icon: 'warn', width: 440, body: lines.map(function (t) { return h('p', { text: t }); }), foot: foot });
  }
  function doSave(force, thenExit) {
    busy = true; saveBtn.disabled = true; saveBtn.textContent = S.edit.saving;
    var text = ta.value;
    Api.post('/api/save', { path: V.doc.path, text: text, stamp: V.doc.stamp, force: !!force }).then(function (r) {
      busy = false; saveBtn.textContent = S.edit.save;
      var c = r.data && r.data.code;
      if (r.ok && r.data.ok) {
        V.doc.stamp = r.data.stamp; V.doc.text = text; baseline = text; setDirty(text !== ta.value);
        ignoreSha = '';
        if (!dirty) flashSaved();
        UI.toast(S.edit.savedToast(r.data.bak), { kind: 'ok', action: { label: S.edit.openFolder, fn: function () { Api.post('/api/reveal', { path: V.doc.path }); } } });
        if (thenExit) Editor.exit();
        return;
      }
      saveBtn.disabled = !dirty;
      if (r.status === 409) return conflictDialog(thenExit);
      if (c === 'BAK_FAILED') return failDialog(S.edit.bakFailTitle, S.edit.bakFailText, true);
      if (c === 'NOT_UTF8') return UI.toast(S.edit.notUtf8Save, { kind: 'err' });
      if (c === 'TOO_LARGE') return UI.toast(S.edit.tooLarge, { kind: 'err' });
      if (r.status === 402) return;
      failDialog(S.edit.writeFailTitle, S.edit.writeFailText, true);
    });
  }
  function conflictDialog(thenExit) {
    var d = UI.dialog({
      title: S.edit.conflictTitle, icon: 'warn', width: 440,
      body: [h('p', { text: S.edit.conflictText(V.doc.name) }), h('ul', null, S.edit.conflictList.map(function (t) { return h('li', { text: t }); }))],
      foot: [btn(S.edit.overwrite, 'danger', function () { d.close('ow'); doSave(true, thenExit); }),
        btn(S.edit.back2, '', function () { d.close('back'); }, { id: 'cfBack' }),
        btn(S.edit.saveAs, 'primary', function () { d.close('as'); saveAs(); })]
    });
    d.el.querySelector('#cfBack').focus();
  }
  function saveAs() {
    Api.post('/api/saveas', { path: V.doc.path, text: ta.value }).then(function (r) {
      if (r.ok && r.data.ok) {
        UI.toast(S.edit.savedAs(r.data.name), { kind: 'ok', sticky: true, action: { label: S.edit.openIt, fn: function () { Api.openFile(r.data.path); } } });
      } else failDialog(S.edit.writeFailTitle, S.edit.writeFailText, false);
    });
  }
  window.Editor = Editor;
})();
