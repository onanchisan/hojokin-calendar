// 設定ダイアログ、初回説明（更新確認の選択）、更新のお知らせ帯
(function () {
  'use strict';
  var h = UI.h, btn = UI.btn;

  function check(id, label, checked, onchange, note, disabled) {
    var cb = h('input', { type: 'checkbox', id: id });
    cb.checked = !!checked; cb.disabled = !!disabled;
    cb.addEventListener('change', function () { onchange(cb.checked, cb); });
    return h('div', { class: 'set-row' }, h('label', null, cb, h('span', { text: label })), note ? [].concat(note).map(function (t) { return h('div', { class: 'note', text: t }); }) : null);
  }
  
  var Settings = {
    open: function () {
      var st = Api.state, set = st.settings;
      function save(obj, errBox) {
        Api.saveSettings(obj).then(function (r) {
          if (!r.ok || r.data.saved === false) { errBox.textContent = S.settings.saveFail; errBox.className = 'note'; errBox.style.color = 'var(--danger)'; }
          else errBox.textContent = '';
        });
      }
      var err = h('div', { role: 'alert' });
      var fsRadios = ['s', 'm', 'l', 'xl'].map(function (k) {
        var r = h('input', { type: 'radio', name: 'fs', value: k }); r.checked = set.fontSize === k;
        r.addEventListener('change', function () { save({ fontSize: k }, err); });
        return h('label', null, r, ' ' + S.settings.fs[k]);
      });
      // 配色テーマ（7種、すべて無料）。見本の四角は data-theme 付きの箱で描く
      var themeRadios = S.themes.map(function (t) {
        var r = h('input', { type: 'radio', name: 'theme', value: t.id }); r.checked = (set.theme || 'standard') === t.id;
        r.addEventListener('change', function () { save({ theme: t.id }, err); });
        var sw = h('span', { class: 'sw', 'data-theme': t.id, 'aria-hidden': 'true', text: 'Aa' });
        return h('label', { class: 'theme-opt' }, r, sw, h('span', { text: t.name }));
      });
      var body = [
        h('h3', { text: S.settings.update }),
        check('setUpdate', S.settings.updateLabel, set.updateCheck === 'on', function (v) { save({ updateCheck: v ? 'on' : 'off' }, err); }, S.settings.updateNotes),
        h('h3', { text: S.settings.history }),
        check('setHistory', S.settings.historyLabel, set.keepHistory, function (v) { save({ keepHistory: v }, err); }),
        btn(S.recent.clear, 'danger small', function () { Recent.confirmClear(); }),
        h('div', { class: 'note', text: S.settings.historyNote }),
        h('h3', { text: S.settings.display }),
        h('div', { class: 'set-row' }, h('div', { text: S.settings.fontSize }), h('div', { class: 'radios', id: 'setFontSize' }, fsRadios)),
        h('div', { class: 'set-row' }, h('div', { text: S.settings.theme }), h('div', { class: 'themes', id: 'setTheme', role: 'radiogroup', 'aria-label': S.settings.theme }, themeRadios), h('div', { class: 'note', text: S.settings.themeNote })),
        check('setPdfMark', S.settings.pdfMarks, set.pdfMarks, function (v) { save({ pdfMarks: v }, err); }),
        err,
        h('h3', { text: S.about.title }),
        h('p', null, S.app + '　' + S.about.ver(st.version)),
        h('p', { class: 'note', text: S.about.text })
      ];
      return UI.dialog({ title: S.settings.title, icon: 'gear', width: 520, body: body, foot: [btn(S.closeBtn, 'primary', function () { UI.closeCurrent(); })] });
    },
    about: function () {
      var st = Api.state;
      return UI.dialog({ title: S.about.title, icon: 'info', width: 460,
        body: [h('p', null, S.app + '　' + S.about.ver(st.version)), h('p', { class: 'note', text: S.about.text }), h('p', { class: 'note', text: st.priceText })],
        foot: [btn(S.closeBtn, 'primary', function () { UI.closeCurrent(); })] });
    },
    // 初回だけ: 更新確認の説明と選択。選ぶまで閉じられない（通信もしない）
    firstRun: function (done) {
      UI.dialog({
        title: S.first.title, icon: 'info', width: 480, dismissable: false,
        body: [h('p', { text: S.first.lead }), h('ol', null, S.first.list.map(function (t) { return h('li', { text: t }); })),
          h('p', { text: S.first.send }), h('p', null, h('strong', { text: S.first.ask }))],
        foot: [
          btn(S.first.no, '', function () { Api.saveSettings({ updateCheck: 'off' }).then(finish); }),
          btn(S.first.yes, 'primary', function () { Api.saveSettings({ updateCheck: 'on' }).then(finish); })
        ],
        focus: null
      });
      // dismissable:false のダイアログは cancel で閉じないので、ここで明示的に閉じる
      function finish() {
        UI.closeCurrent('done');
        if (done) done();
      }
    }
  };

  // ---- 更新のお知らせ帯 ----
  var Update = {
    init: function () {
      var s = Api.state;
      if (!s || s.settings.updateCheck !== 'on') return;
      var tries = 0;
      function ask() {
        Api.post('/api/update/check', {}).then(function (r) {
          if (!r.ok) return;
          if (r.data.available && !r.data.later) Update.show(r.data.latest);
          else if (r.data.pending && tries++ < 4) setTimeout(ask, 3000);
        });
      }
      ask();
    },
    show: function (info) {
      var bar = document.getElementById('updateBanner');
      if (!bar) return;
      bar.textContent = '';
      bar.className = 'banner';
      bar.appendChild(Icons.svg('info'));
      bar.appendChild(h('span', { class: 'grow', text: S.update.text(info.latest) }));
      bar.appendChild(btn(S.update.open, 'small', function () {
        Api.post('/api/openurl', { which: 'update' }).then(function (r) { if (!r.ok) UI.toast(S.update.openFail, { kind: 'warn' }); });
      }, { id: 'updOpen' }));
      bar.appendChild(btn(S.update.later, 'link', function () { bar.hidden = true; Api.saveSettings({ updateLater: true }); }, { id: 'updLater' }));
      bar.appendChild(btn(S.update.never, 'link', function () { bar.hidden = true; Api.saveSettings({ updateCheck: 'off' }); UI.toast(S.update.neverToast); }, { id: 'updNever' }));
      bar.hidden = false;
    }
  };
  window.Settings = Settings;
  window.Update = Update;
})();
