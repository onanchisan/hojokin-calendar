// トップ画面: ファイルを選ぶ・ドラッグ＆ドロップ・最近のファイル・使い方
(function () {
  'use strict';
  var h = UI.h;
  var drop = document.getElementById('drop');
  var file = document.getElementById('file');
  var dropErr = document.getElementById('dropErr');

  document.getElementById('tagline').textContent = S.app + '　' + S.tagline;
  document.getElementById('dropText').textContent = S.top.drop;
  document.getElementById('orText').textContent = S.top.or;
  document.getElementById('dropNote').textContent = S.top.dropNote;
  document.getElementById('howtoHead').textContent = S.top.howtoTitle;
  S.top.howto.forEach(function (t) { document.getElementById('howto').appendChild(h('li', { text: t })); });

  function err(t) { dropErr.hidden = !t; dropErr.textContent = t || ''; }

  // ドラッグ＆ドロップで開く（ブラウザにはパスが渡らないので、表示とPDF（印刷）だけ使える）
  function openDropped(files) {
    err('');
    if (!files || !files.length) return;
    if (files.length > 1) { err(S.top.oneAtATime); return; }
    var f = files[0];
    if (!/\.(md|markdown|txt)$/i.test(f.name)) { err(S.top.badDrop); return; }
    if (f.size > 10 * 1024 * 1024) { err('10MBまでのファイルを開けます。'); return; }
    var r = new FileReader();
    r.onload = function () {
      var lk = 'mdLocal-' + Date.now().toString(36) + Math.floor(Math.random() * 46656).toString(36);
      try { sessionStorage.setItem(lk, JSON.stringify({ name: f.name, text: String(r.result) })); } catch (e) { err('ファイルが大きすぎて開けません。'); return; }
      if (Api.framed) { try { window.parent.MDTabs.openLocal(lk); return; } catch (e2) { } }
      location.href = '/view?local=1&lk=' + encodeURIComponent(lk);
    };
    r.readAsText(f, 'utf-8');
  }
  // 「ファイルを選ぶ」はサーバー側のダイアログでパスを取る（マーカー・編集・履歴も使える）
  document.getElementById('pick').addEventListener('click', function () {
    err('');
    Api.post('/api/pick', {}).then(function (r) {
      if (r.ok && r.data.path) Api.openFile(r.data.path);
      else if (!r.ok) file.click();   // ダイアログを出せない環境ではブラウザの選択画面で代用
    });
  });
  file.addEventListener('change', function () { openDropped(file.files); });
  ['dragenter', 'dragover'].forEach(function (ev) { document.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); }); });
  ['dragleave', 'drop'].forEach(function (ev) { document.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); }); });
  document.addEventListener('drop', function (e) { openDropped(e.dataTransfer.files); });

  var box = document.getElementById('recentBox');
  var clearBtn = document.getElementById('btnClearRecent');
  function renderRecent() { Recent.render(box); }
  clearBtn.addEventListener('click', function () { Recent.confirmClear(renderRecent); });
  document.getElementById('btnSettings').addEventListener('click', function () { Settings.open(); });
  document.getElementById('btnMore').addEventListener('click', function (e) {
    UI.menu(e.currentTarget, [
      { label: S.more.settings, kbd: 'Ctrl+,', fn: Settings.open },
      { label: S.more.about, fn: Settings.about }
    ], true);
  });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === ',') { e.preventDefault(); Settings.open(); }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'o' || e.key === 'O')) { e.preventDefault(); document.getElementById('pick').click(); }
  });
  Api.onDisconnect = function () {
    var nb = document.getElementById('noticeBar');
    if (!document.getElementById('netErr')) nb.appendChild(h('div', { class: 'banner err', id: 'netErr' }, Icons.svg('warn'), h('span', { class: 'grow', text: S.state.disconnected[0] + '。' + S.state.disconnected[1] })));
  };

  Api.loadState().then(function () {
    renderRecent();
    if (!Api.framed) { if (Api.state.settings.updateCheck === 'ask') Settings.firstRun(Update.init); else Update.init(); }   // タブの中では親の窓が行う
  });
})();
