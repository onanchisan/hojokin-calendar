// 最近のファイル: トップ画面の一覧、表示画面のドロップダウン、履歴消去の確認
(function () {
  'use strict';
  var h = UI.h, btn = UI.btn;

  function when(iso) {
    var d = new Date(iso); if (isNaN(d)) return '';
    var now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    if (d >= t0) return S.recent.today + ' ' + hm;
    if (d >= new Date(t0.getTime() - 86400000)) return S.recent.yesterday;
    return (d.getMonth() + 1) + '月' + d.getDate() + '日';
  }
  function openFile(p) { Api.openFile(p); }

  var Recent = {
    // トップ画面に一覧（無料ならロックカード）を描く
    render: function (box) {
      box.textContent = '';
      Api.get('/api/recent').then(function (r) {
        if (!r.ok || r.data.locked) return;
        if (!r.data.keepHistory) { box.appendChild(h('div', { class: 'recent-empty', text: S.recent.off })); return; }
        var items = r.data.items || [];
        if (!items.length) { box.appendChild(h('div', { class: 'recent-empty', text: S.recent.empty })); return; }
        var ul = h('ul', { class: 'recent', id: 'recentList', role: 'list' });
        items.forEach(function (it) {
          var rm = h('button', { type: 'button', class: 'btn icon', 'aria-label': S.recent.removeAria, title: S.recent.removeAria }, Icons.svg('x'));
          var li = h('li', { class: 'recent-item' + (it.exists ? '' : ' missing'), tabindex: '0' },
            Icons.svg('file'),
            h('div', { class: 'main' }, h('div', { class: 'nm', text: UI.baseName(it.path), title: it.path }), h('div', { class: 'dir', text: UI.dirOf(it.path) }),
              it.exists ? null : h('div', { class: 'note', text: S.recent.missingNote })),
            it.hasMarks && it.exists ? h('span', { class: 'chip', text: '✎ ' + S.recent.marks() }) : null,
            it.exists ? h('span', { class: 'when', text: when(it.openedAt) }) : h('span', { class: 'chip warn', text: S.recent.missing }), rm);
          function remove() { Api.post('/api/recent/remove', { path: it.path }).then(function () { Recent.render(box); }); }
          rm.addEventListener('click', function (e) { e.stopPropagation(); remove(); });
          li.addEventListener('click', function () { if (it.exists) openFile(it.path); });
          li.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && it.exists) openFile(it.path);
            else if (e.key === 'Delete') remove();
            else if (e.key === 'ArrowDown' && li.nextSibling) { e.preventDefault(); li.nextSibling.focus(); }
            else if (e.key === 'ArrowUp' && li.previousSibling) { e.preventDefault(); li.previousSibling.focus(); }
          });
          ul.appendChild(li);
        });
        box.appendChild(ul);
      });
    },
    // 表示画面の「最近のファイル」ボタン
    dropdown: function (anchor) {
      Api.get('/api/recent').then(function (r) {
        if (!r.ok || r.data.locked) return;
        var items = (r.data.items || []).filter(function (x) { return x.exists; }).slice(0, 10).map(function (it) {
          return { label: UI.baseName(it.path), fn: function () { openFile(it.path); } };
        });
        if (!items.length) items = [{ note: r.data.keepHistory ? S.recent.empty : S.recent.off }];
        items.push({ sep: true }); items.push({ label: S.recent.more, fn: function () { Api.goHome(); } });
        UI.menu(anchor, items);
      });
    },
    confirmClear: function (after) {
      var d = UI.dialog({
        title: S.recent.clearTitle, width: 440, body: h('p', { text: S.recent.clearText }),
        foot: [btn(S.edit.cancel, '', function () { d.close('cancel'); }, { id: 'clrCancel' }),
          btn(S.recent.clearOk, 'danger', function () { Api.post('/api/recent/clear', {}).then(function () { d.close('ok'); UI.toast(S.recent.cleared, { kind: 'ok' }); if (after) after(); }); })]
      });
      d.el.querySelector('#clrCancel').focus();
    }
  };
  window.Recent = Recent;
})();
