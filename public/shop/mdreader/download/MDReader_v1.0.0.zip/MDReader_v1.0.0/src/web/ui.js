// 画面部品の共通部分: 要素づくり、ダイアログ、通知、メニュー。文字は必ず textContent で入れる（innerHTML 不使用）
(function () {
  'use strict';

  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v == null || v === false) return;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, v);
      });
    }
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function add(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  function btn(text, cls, fn, extra) {
    var attrs = { type: 'button', class: 'btn' + (cls ? ' ' + cls : ''), text: text, onclick: fn };
    if (extra) Object.keys(extra).forEach(function (k) { attrs[k] = extra[k]; });
    return h('button', attrs);
  }
  // 状態表示（アイコン＋文字＋色）。kind: ok / warn / err / info / neutral / busy
  function msg(kind, text) {
    var ic = kind === 'busy' ? h('span', { class: 'spin' }) : Icons.svg(kind === 'ok' ? 'check' : kind === 'err' || kind === 'warn' ? 'warn' : 'info');
    return h('div', { class: 'msg ' + (kind === 'busy' ? 'neutral' : kind) }, ic, h('span', { text: text }));
  }

  // ---- ダイアログ（同時に開くのは1つ） ----
  var current = null;
  function dialog(o) {
    if (current) { try { current.close(); } catch (e) { } }
    var dlg = h('dialog', { class: 'dlg', 'aria-labelledby': 'dlgTitle' });
    if (o.width) dlg.style.width = o.width + 'px';
    var head = h('div', { class: 'dlg-head' });
    if (o.icon) head.appendChild(Icons.svg(o.icon));
    head.appendChild(h('span', { class: 't', id: 'dlgTitle', text: o.title }));
    if (o.dismissable !== false) head.appendChild(h('button', { type: 'button', class: 'btn icon', 'aria-label': '閉じる', title: '閉じる', onclick: function () { api.close('x'); } }, Icons.svg('x')));
    var body = h('div', { class: 'dlg-body' }, o.body);
    var foot = h('div', { class: 'dlg-foot' }, o.foot);
    dlg.appendChild(head); dlg.appendChild(body); dlg.appendChild(foot);
    var api = {
      el: dlg, body: body, foot: foot, closed: false, returnValue: '',
      close: function (rv) {
        if (api.closed) return; api.closed = true; api.returnValue = rv || '';
        try { dlg.close(); } catch (e) { }
        if (dlg.parentNode) dlg.parentNode.removeChild(dlg);
        if (current === api) current = null;
        if (o.onClose) o.onClose(api.returnValue);
      }
    };
    dlg.addEventListener('cancel', function (e) { e.preventDefault(); if (o.dismissable !== false) api.close('esc'); });
    dlg.addEventListener('mousedown', function (e) { if (e.target === dlg && o.dismissable !== false) api.close('backdrop'); });
    document.body.appendChild(dlg);
    dlg.showModal();
    current = api;
    var f = o.focus ? (typeof o.focus === 'string' ? dlg.querySelector(o.focus) : o.focus) : null;
    if (f) f.focus();
    return api;
  }

  // ---- 通知（トースト） ----
  var toastEl = null, toastTimer = 0;
  function toast(text, o) {
    o = o || {};
    if (!toastEl) { toastEl = h('div', { id: 'toast', class: 'toast', hidden: true }); document.body.appendChild(toastEl); }
    toastEl.className = 'toast ' + (o.kind || 'info');
    toastEl.setAttribute('role', o.kind === 'err' ? 'alert' : 'status');
    toastEl.textContent = '';
    toastEl.appendChild(Icons.svg(o.kind === 'ok' ? 'check' : o.kind === 'err' || o.kind === 'warn' ? 'warn' : 'info'));
    toastEl.appendChild(h('span', { class: 'tmsg', text: text }));
    if (o.action) toastEl.appendChild(btn(o.action.label, 'small', function () { hideToast(); o.action.fn(); }));
    toastEl.appendChild(h('button', { type: 'button', class: 'btn icon', 'aria-label': '閉じる', title: '閉じる', onclick: hideToast }, Icons.svg('x')));
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    if (o.kind !== 'err' && o.kind !== 'warn' && !o.sticky) toastTimer = setTimeout(hideToast, 6000);
  }
  function hideToast() { if (toastEl) toastEl.hidden = true; clearTimeout(toastTimer); }

  // ---- ポップアップメニュー ----
  var menuEl = null;
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
  // items: [{label, kbd, fn, note, sep}]
  function menu(anchor, items, alignRight) {
    closeMenu();
    menuEl = h('div', { class: 'menu', role: 'menu' });
    items.forEach(function (it) {
      if (it.sep) { menuEl.appendChild(h('hr')); return; }
      if (it.note) { menuEl.appendChild(h('div', { class: 'menu-note', text: it.note })); return; }
      menuEl.appendChild(h('button', { type: 'button', role: 'menuitem', onclick: function () { closeMenu(); it.fn(); } },
        h('span', { text: it.label }), it.kbd ? h('span', { class: 'kbd', text: it.kbd }) : null));
    });
    document.body.appendChild(menuEl);
    var r = anchor.getBoundingClientRect();
    var w = menuEl.offsetWidth;
    var left = alignRight ? Math.max(8, r.right - w) : Math.min(r.left, window.innerWidth - w - 8);
    menuEl.style.left = left + 'px';
    menuEl.style.top = (r.bottom + 4) + 'px';
    var first = menuEl.querySelector('button'); if (first) first.focus();
    return menuEl;
  }
  document.addEventListener('mousedown', function (e) { if (menuEl && !menuEl.contains(e.target)) closeMenu(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });

  function copyText(t) {
    function done() { toast(S.copiedMsg, { kind: 'ok' }); }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(done, fallback); } else fallback();
    function fallback() {
      var ta = h('textarea', { style: 'position:fixed;left:-999px' }); ta.value = t; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { } ta.remove();
    }
  }
  function baseName(p) { return String(p).replace(/^.*[\\/]/, ''); }
  function dirOf(p) { return String(p).replace(/[\\/][^\\/]*$/, ''); }

  function closeCurrent(rv) { if (current) current.close(rv || 'x'); }
  window.UI = { closeCurrent: closeCurrent, h: h, btn: btn, msg: msg, dialog: dialog, toast: toast, hideToast: hideToast, menu: menu, closeMenu: closeMenu, copyText: copyText, baseName: baseName, dirOf: dirOf };
})();
