// 表示画面: .md の読み込み・整形表示、PDF保存、ツールバー、各機能（マーカー・編集・最近のファイル・設定）の呼び出し
(function () {
  'use strict';
  var h = UI.h, btn = UI.btn;
  var q = new URLSearchParams(location.search);
  var path = q.get('path');
  var isLocal = q.get('local') === '1';
  var isPrint = Api.isPrint;
  var content = document.getElementById('content');
  var fname = document.getElementById('fname');
  var status = document.getElementById('status');
  var btnPdf = document.getElementById('btnPdf');
  var doc = { path: null, name: '', text: '', stamp: null, enc: 'utf8', eol: 'lf' };
  var skipUnload = false, statusTimer = 0;

  function safeDecode(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
  var opts = {
    img: function (u) {
      if (/^data:image\//i.test(u)) return u;
      if (/^[a-z][a-z0-9+.-]*:|^\/\//i.test(u) && !/^[a-z]:[\\/]/i.test(u)) return null;   // 外部画像は表示しない
      if (!doc.path) return null;
      var full = /^[a-z]:[\\/]/i.test(u) ? u : UI.dirOf(doc.path) + '\\' + safeDecode(u.split(/[?#]/)[0]);
      return '/api/asset?t=' + encodeURIComponent(Api.token) + '&path=' + encodeURIComponent(full);
    },
    link: function (u) {
      if (doc.path && !/^[a-z][a-z0-9+.-]*:|^#|^\/\//i.test(u) && /\.(md|markdown|txt)(#.*)?$/i.test(u)) {
        return '/view?path=' + encodeURIComponent(UI.dirOf(doc.path) + '\\' + safeDecode(u.split('#')[0]));
      }
      return null;
    }
  };
  // 整形して表示する。失敗しても画面が白くならないよう、文字のまま表示して案内を出す
  function renderInto(el, text) {
    var info = null;
    try {
      var html = MD.render(text, opts);
      info = MD.lastInfo;
      el.innerHTML = html;
    } catch (e) {
      el.textContent = '';
      el.appendChild(h('pre', { class: 'md-plain', text: String(text) }));
      setNotice('render', 'warn', S.render.failed);
      return;
    }
    var msgs = [];
    if (info && info.cut) msgs.push(S.render.cut);
    if (info && info.depth) msgs.push(S.render.depth);
    if (info && info.longLines) msgs.push(S.render.longLine);
    setNotice('render', 'warn', msgs.join(' '));
  }

  // リンクを押したとき、アプリの窓の中で外のページへ移動させない（外部リンクは別ウィンドウ、それ以外は無効）
  function onLinkClick(e) {
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (!a) return;
    var href = a.getAttribute('href') || '';
    if (href.charAt(0) === '#') return;
    var u = null;
    try { u = new URL(a.href, location.href); } catch (x) { }
    if (!u) { e.preventDefault(); return; }
    if (u.origin === location.origin && u.pathname === '/view') {            // アプリ内の別の .md
      if (!Api.framed) return;
      e.preventDefault();
      var lp = u.searchParams.get('path'); if (lp) Api.openFile(lp);       // タブで開く（開いていればそのタブへ）
      return;
    }
    e.preventDefault();
    if (u.origin === location.origin) return;     // アプリ自身の他のページ（/api など）は開かない
    if (u.protocol === 'http:' || u.protocol === 'https:') {
      try { window.open(u.href, '_blank', 'noopener,noreferrer'); } catch (x) { }
    } else if (u.protocol === 'mailto:') {
      try { window.open(u.href, '_blank', 'noopener,noreferrer'); } catch (x) { }
    }
  }
  document.addEventListener('click', onLinkClick, true);
  document.addEventListener('auxclick', onLinkClick, true);
  // ファイルや文字をこの窓にドロップしても、窓がそのファイルに切り替わらないようにする（編集欄の中は除く）
  ['dragover', 'drop'].forEach(function (ev) {
    document.addEventListener(ev, function (e) { if (!(e.target && e.target.tagName === 'TEXTAREA')) e.preventDefault(); });
  });
  function setStatus(t, keep) { status.textContent = t || ''; clearTimeout(statusTimer); if (t && !keep) statusTimer = setTimeout(function () { status.textContent = ''; }, 7000); }

  // 帯（警告・案内）。text が null なら外す
  function setNotice(id, kind, text, buttons) {
    var old = document.getElementById('notice-' + id); if (old) old.remove();
    if (!text) return;
    var bar = h('div', { class: 'banner ' + (kind === 'err' ? 'err' : kind === 'warn' ? 'warn' : ''), id: 'notice-' + id }, Icons.svg(kind === 'info' ? 'info' : 'warn'), h('span', { class: 'grow', text: text }));
    (buttons || []).forEach(function (b) { bar.appendChild(btn(b.label, 'small', b.fn)); });
    bar.appendChild(btn(S.closeBtn, 'link', function () { bar.remove(); }));
    document.getElementById('noticeBar').appendChild(bar);
  }

  // ---- 空・エラー表示 ----
  function showState(info, kind, buttons, detail) {
    content.textContent = '';
    var box = h('div', { class: 'state' + (kind === 'err' ? ' err' : '') }, Icons.svg(kind === 'err' ? 'warn' : 'file'), h('h2', { text: info[0] }), h('p', { text: info[1] + (detail ? '（場所: ' + detail + '）' : '') }),
      h('div', { class: 'row' }, buttons));
    content.appendChild(box);
    btnPdf.disabled = true;
  }
  function pickFile() {
    Api.post('/api/pick', {}).then(function (r) { if (r.ok && r.data.path) Api.openFile(r.data.path); });
  }
  function toTop() { if (Api.framed) { Api.goHome(); return; } guardLeave(function () { location.href = '/'; }); }

  function show() {
    fname.textContent = doc.name; fname.title = doc.path || doc.name;
    document.title = doc.name + ' - ' + S.app;
    if (!doc.text.trim()) {
      showState(S.state.empty, 'info', [btn(S.toolbar.edit, 'primary', function () { Editor.enter(); })]);
      btnPdf.disabled = false;
    } else renderInto(content, doc.text);
    Marks.refresh();
  }

  function applyDoc(d) { doc = d; show(); }

  // 読み込み（再読み込みにも使う）
  function loadDoc() {
    if (isLocal) {
      var d = null;
      try { d = JSON.parse(sessionStorage.getItem(q.get('lk') || 'mdLocal')); } catch (e) { }
      if (!d) { showState([S.state.notFound[0], S.state.localMissing], 'err', [btn(S.state.toTop, 'primary', toTop)]); return Promise.resolve(false); }
      doc = { path: null, name: d.name, text: d.text, stamp: null, enc: 'utf8', eol: 'lf' };
      return Promise.resolve(true);
    }
    if (!path) { showState(S.state.noFile, 'info', [btn(S.state.pick, 'primary', pickFile), btn(S.state.toTop, '', toTop)]); return Promise.resolve(false); }
    if (!/\.(md|markdown|txt)$/i.test(path)) { showState(S.state.badType, 'err', [btn(S.state.pick, 'primary', pickFile)]); return Promise.resolve(false); }
    return Api.get('/api/md', { path: path }).then(function (r) {
      var again = btn(S.state.reread, '', function () { location.reload(); });
      if (r.status === 0) { showState(S.state.disconnected, 'err', [btn(S.state.reload, 'primary', function () { location.reload(); })]); return false; }
      if (r.status === 404) { showState(S.state.notFound, 'err', [btn(S.state.toTop, 'primary', toTop), again], path); return false; }
      if (r.status === 413) { showState(S.state.tooLarge, 'err', [btn(S.state.toTop, 'primary', toTop)]); return false; }
      if (!r.ok) { showState(S.state.readFail, 'err', [again]); return false; }
      var hd = r.headers;
      doc = { path: path, name: UI.baseName(path), text: r.data, enc: hd.get('X-Mdv-Encoding') || 'utf8', eol: hd.get('X-Mdv-Eol') || 'lf', eolMixed: hd.get('X-Mdv-EolMixed') === '1',
        stamp: { mtime: hd.get('X-Mdv-Mtime'), size: hd.get('X-Mdv-Size'), sha256: hd.get('X-Mdv-Sha256') } };
      return true;
    });
  }

  // ---- PDF ----
  function savePdf() {
    if (isLocal || !path) { window.print(); return; }
    var withMarks = Api.state.settings.pdfMarks;
    var n = withMarks ? Marks.count() - Marks.lostCount() : 0;
    setStatus(withMarks && n ? S.pdf.makingMarks : S.pdf.making, true);
    btnPdf.disabled = true;
    fetch('/api/pdf?path=' + encodeURIComponent(path), { headers: { 'X-Mdv-Token': Api.token }, cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('pdf');
      return r.blob();
    }).then(function (b) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(b);
      a.download = UI.baseName(path).replace(/\.[^.]*$/, '') + '.pdf';
      document.body.appendChild(a); a.click(); a.remove();
      var msg = n ? S.pdf.doneMarks(n) : S.pdf.done;
      setStatus(msg);
      UI.toast(msg, { kind: 'ok' });
    }).catch(function () {
      setStatus(S.pdf.fallback);
      window.print();
    }).then(function () { btnPdf.disabled = false; });
  }

  // ---- 離れるときの確認 ----
  function guardLeave(fn) {
    function go() { skipUnload = true; fn(); }
    var msg = null;
    if (Editor.isDirty()) msg = S.edit.leaveText(doc.name);
    else if (Marks.unsavedCount() > 0) msg = S.marks.leaveUnsaved(Marks.unsavedCount());
    if (!msg) { go(); return; }
    var d = UI.dialog({
      title: Editor.isDirty() ? S.edit.leaveTitle : S.marks.leaveOk, icon: 'warn', width: 440, body: h('p', { text: msg }),
      foot: [btn(S.marks.leaveOk, 'danger', function () { d.close('go'); go(); }), btn(S.marks.leaveBack, 'primary', function () { d.close('back'); }, { id: 'lvBack' })]
    });
    d.el.querySelector('#lvBack').focus();
  }
  window.addEventListener('beforeunload', function (e) {
    if (skipUnload || Editor.isActive()) return;   // 編集中の分は editor.js が扱う
    if (Marks.unsavedCount() > 0) { e.preventDefault(); e.returnValue = ''; }
  });

  // ---- ツールバー ----
  function markerMenu() {
    var items = [];
    if (!isLocal) items.push({ label: S.marks.menuList, kbd: 'Ctrl+Shift+M', fn: togglePanel });
    var cnt = Marks.count();
    if (cnt) items.push({ label: !isLocal ? S.marks.menuClear : S.marks.menuClearLocal, fn: clearMarks });
    if (!items.length) items.push({ note: S.marks.empty });
    UI.menu(document.getElementById('btnMarker'), items, true);
  }
  function togglePanel() {
    if (isLocal) { UI.toast(S.noLocalFeature, { kind: 'warn' }); return; }
    if (Marks.panelOpen()) Marks.closePanel(); else Marks.openPanel(document.getElementById('markPanel'));
  }
  function clearMarks() {
    if (isLocal) { Marks.clearAll(); return; }
    var d = UI.dialog({ title: S.marks.menuClear, width: 440, icon: 'warn', body: h('p', { text: S.marks.clearConfirm }),
      foot: [btn(S.edit.cancel, '', function () { d.close('c'); }, { id: 'mcCancel' }), btn(S.marks.clearOk, 'danger', function () { d.close('ok'); Marks.clearAll(); })] });
    d.el.querySelector('#mcCancel').focus();
  }
  function moreMenu() {
    UI.menu(document.getElementById('btnMore'), [
      { label: S.more.reload, kbd: 'Ctrl+R', fn: function () { guardLeave(function () { location.reload(); }); } },
      { label: S.more.top, kbd: 'Alt+Home', fn: toTop },
      { sep: true },
      { label: S.more.settings, kbd: 'Ctrl+,', fn: Settings.open },
      { label: S.more.about, fn: Settings.about }
    ], true);
  }

  function bindToolbar() {
    document.getElementById('btnRecent').addEventListener('click', function (e) { Recent.dropdown(e.currentTarget); });
    document.getElementById('btnMarker').addEventListener('click', markerMenu);
    document.getElementById('btnEdit').addEventListener('click', function () { Editor.enter(); });
    btnPdf.addEventListener('click', savePdf);
    document.getElementById('btnPrint').addEventListener('click', function () { window.print(); });
    document.getElementById('btnMore').addEventListener('click', moreMenu);
    document.addEventListener('keydown', function (e) {
      var k = e.key, ctrl = e.ctrlKey || e.metaKey;
      if (ctrl && !e.shiftKey && k === ',') { e.preventDefault(); Settings.open(); }
      else if (ctrl && e.shiftKey && (k === 'S' || k === 's')) { e.preventDefault(); if (!Editor.isActive()) savePdf(); }
      else if (ctrl && e.shiftKey && (k === 'M' || k === 'm')) { e.preventDefault(); togglePanel(); }
      else if (ctrl && !e.shiftKey && (k === 'S' || k === 's')) { if (Editor.isActive()) { e.preventDefault(); Editor.save(false); } }
      else if (ctrl && !e.shiftKey && (k === 'E' || k === 'e')) { e.preventDefault(); if (Editor.isActive()) Editor.leave(); else Editor.enter(); }
      else if (ctrl && !e.shiftKey && (k === 'O' || k === 'o')) { e.preventDefault(); pickFile(); }
      else if (ctrl && !e.shiftKey && (k === 'R' || k === 'r')) { e.preventDefault(); guardLeave(function () { location.reload(); }); }
      else if (e.altKey && k === 'Home') { e.preventDefault(); toTop(); }
      else if (e.altKey && /^[0-4]$/.test(k) && !Editor.isActive()) {
        e.preventDefault();
        if (k === '0') Marks.erase(); else Marks.draw(['yellow', 'green', 'pink', 'blue'][parseInt(k, 10) - 1]);
      }
    });
  }

  // ---- 起動 ----
  var viewerApi = {
    get doc() { return doc; }, local: isLocal, renderInto: renderInto, setNotice: setNotice,
    afterExit: function () { show(); },
    reloadDoc: function () { return loadDoc().then(function (ok) { if (ok) show(); }); }
  };

  function startPrint() {
    document.body.classList.add('print-mode');
    return Api.loadState().then(function () {
      return loadDoc();
    }).then(function (ok) {
      if (!ok) return;
      fname.textContent = doc.name; document.title = doc.name;
      renderInto(content, doc.text);
      // 線は、PDFに入れる設定のときだけ入る
      if (Api.state.settings.pdfMarks) { Marks.init(content, path, false, null); return Marks.loadForPrint(); }
    });
  }

  function start() {
    Api.onDisconnect = function () { setNotice('net', 'err', S.state.disconnected[0] + '。' + S.state.disconnected[1]); };
    bindToolbar();
    Editor.init(viewerApi);
    Marks.init(content, isLocal ? null : path, isLocal, null);
    Api.loadState().then(function () {
      if (Api.state && Api.state.oldPrototype) setNotice('old', 'info', S.oldProto);
      return loadDoc();
    }).then(function (ok) {
      if (ok) {
        show();
        if (!isLocal) Api.post('/api/recent/touch', { path: path });
        Marks.load();
      }
      if (!Api.framed) {   // タブの中では親の窓が行う
        if (Api.state && Api.state.settings.updateCheck === 'ask') Settings.firstRun(Update.init);
        else Update.init();
      }
    });
  }

  // 親の窓（タブ）から使う窓口: 未保存の確認が要るか／閉じる前の確認
  window.MDTab = {
    needsConfirm: function () { return Editor.isDirty() || Marks.unsavedCount() > 0; },
    confirmClose: function (cb) { guardLeave(cb); }
  };

  if (isPrint) startPrint(); else start();
})();
