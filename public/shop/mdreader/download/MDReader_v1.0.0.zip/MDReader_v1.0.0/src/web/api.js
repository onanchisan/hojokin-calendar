// ローカルサーバーとの通信の共通部: 一時トークン付与、状態 state の保持、生存通知
(function () {
  'use strict';
  var meta = document.querySelector('meta[name="mdv-token"]');
  var token = meta ? meta.getAttribute('content') : '';
  var q = new URLSearchParams(location.search);
  var isPrint = q.get('print') === '1';
  // タブの中（親ページ shell の iframe）で開かれているか
  var framed = (window.parent !== window) && q.get('tab') === '1';
  var windowId = (function () {
    var a = new Uint8Array(8); crypto.getRandomValues(a);
    return Array.prototype.map.call(a, function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
  })();

  var Api = {
    token: token, isPrint: isPrint, framed: framed, windowId: windowId, state: null, onDisconnect: null,
    // 通信。戻り値は Promise<{status, ok, data, headers}>。通信できないときは status 0
    req: function (method, path, body) {
      var opt = { method: method, headers: { 'X-Mdv-Token': token }, cache: 'no-store' };
      if (method !== 'GET') { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body || {}); }
      return fetch(path, opt).then(function (r) {
        var ct = r.headers.get('Content-Type') || '';
        var p = ct.indexOf('application/json') >= 0 ? r.json() : r.text();
        return p.then(function (data) {
          return { status: r.status, ok: r.ok, data: data, headers: r.headers };
        });
      }, function () {
        if (Api.onDisconnect) Api.onDisconnect();
        return { status: 0, ok: false, data: { ok: false, code: 'NETWORK' }, headers: new Headers() };
      });
    },
    get: function (path, params) {
      var u = path;
      if (params) u += '?' + Object.keys(params).map(function (k) { return k + '=' + encodeURIComponent(params[k]); }).join('&');
      return Api.req('GET', u);
    },
    post: function (path, body) { return Api.req('POST', path, body); },
    put: function (path, body) { return Api.req('PUT', path, body); },
    loadState: function () {
      return Api.get('/api/state').then(function (r) {
        if (r.ok) { Api.state = r.data; applyState(); }
        return Api.state;
      });
    },
    // fromParent: 親ページからの配り直し（また親へ返さない）
    setState: function (s, fromParent) {
      Api.state = s; applyState();
      if (framed && !fromParent) { try { window.parent.MDTabs.broadcast(s, window); } catch (e) { } }   // 配色などを、ほかのタブにも反映
    },
    // .md を開く。タブの中なら親の窓に新しいタブ（同じファイルが開いていればそのタブ）、そうでなければこの窓で開く
    openFile: function (p) {
      if (framed) { try { window.parent.MDTabs.open(p); return; } catch (e) { } }
      location.href = '/view?path=' + encodeURIComponent(p);
    },
    goHome: function () {
      if (framed) { try { window.parent.MDTabs.openHome(); return; } catch (e) { } }
      location.href = '/';
    },
    saveSettings: function (obj) {
      return Api.post('/api/settings', obj).then(function (r) {
        if (r.ok && r.data.state) Api.setState(r.data.state);
        return r;
      });
    }
  };

  function applyState() {
    var s = Api.state; if (!s) return;
    document.documentElement.setAttribute('data-fs', s.settings.fontSize || 'm');
    // 配色テーマ。印刷用ページ（PDF作成）には付けない（印刷・PDFは、いつも白地に黒文字）
    if (!isPrint) document.documentElement.setAttribute('data-theme', s.settings.theme || 'standard');
    document.dispatchEvent(new CustomEvent('mdv:state'));
  }

  // 生存通知（印刷用ページは送らない）。閉じると bye
  if (!isPrint) {
    var hb = function () { Api.post('/api/hb', { id: windowId }); };
    hb();
    setInterval(hb, 15000);
    window.addEventListener('pagehide', function () {
      try { navigator.sendBeacon('/api/bye?t=' + encodeURIComponent(token) + '&id=' + windowId, new Blob(['bye'], { type: 'text/plain' })); } catch (e) { }
    });
  }
  // Ctrl+F4: タブの中で押されたら、親の窓に「表示中のタブを閉じる」を伝える
  if (framed) {
    document.addEventListener('keydown', function (e) {
      if (e.ctrlKey && e.key === 'F4') { e.preventDefault(); try { window.parent.MDTabs.closeActive(); } catch (x) { } }
    });
  }
  window.Api = Api;
})();
