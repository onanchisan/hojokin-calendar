// 画面に出す日本語の文言を、ここ1か所にまとめる
window.S = {
  app: 'MDReader',
  tagline: '読む → 線を引く → PDFにして渡す',
  tabs: {
    add: 'ファイルを選んで、新しいタブで開く', home: 'ホーム', loading: '読み込み中…',
    close: function (n) { return n + ' のタブを閉じる'; },
    limit: 'タブは20個までです。使わないタブを閉じてから、もう一度開いてください。'
  },
  render: {
    failed: 'この文書は構造が複雑すぎて、整形して表示できませんでした。文字のまま表示しています。（元のファイルは変わっていません）',
    cut: '文書がとても大きい（または複雑な）ため、途中から整形をやめて文字のまま表示しています。',
    depth: '入れ子（引用やリスト）が深すぎる部分は、整形せずに文字のまま表示しています。',
    longLine: '1行が長すぎる部分（10万文字を超える分）は、表示を省略しています。'
  },
  oldProto: '旧い試作版のソフトが、まだ裏で動いているようです。動作に問題はありませんが、パソコンを再起動する（またはサインアウトする）と、なくなります。',
  closeBtn: '閉じる',
  toolbar: { recent: '最近のファイル', marker: 'マーカー', edit: '編集', pdf: 'PDFで保存', print: '印刷', more: 'その他のメニュー' },
  more: { reload: '再読み込み', top: 'トップ画面へ戻る', settings: '設定…', about: 'このソフトについて' },
  about: { title: 'このソフトについて', ver: function (v) { return 'バージョン ' + v; }, text: 'Markdown（.md）ファイルを、きれいに読みやすく表示するソフトです。通信は、最新版のお知らせの確認だけです（設定でオフにできます）。無料でお使いいただけます。' },
  marks: {
    colors: { yellow: '黄', green: '緑', pink: 'ピンク', blue: '水色' },
    drawAria: function (c) { return S.marks.colors[c] + '色の線を引く'; },
    erase: '消す', oneBlock: '線は、ひとつの段落の中で選んでください',
    localLine: 'この開き方では線は保存されません（「ファイルを選ぶ」で開くと保存されます）',
    firstToast: 'この開き方（ドラッグ＆ドロップ）では、線は保存されません。ファイルを閉じると消えます。',
    panelTitle: 'マーカー一覧', total: function (n) { return '全部で ' + n + ' 件'; }, filterAll: 'すべて',
    empty: 'まだ線はありません。文字をドラッグで選ぶと、色を選べます。',
    go: 'この場所へ', copy: 'コピー', del: '消す', copied: 'コピーしました', deleted: '線を消しました', undo: '元に戻す',
    lostHead: function (n) { return '位置が見つからない線（' + n + '件）'; },
    lostText: '文書が書き換えられたため、この線の場所が見つかりません。',
    lostBar: function (n) { return '場所が見つからない線が' + n + '件あります。'; }, lostBarLink: '一覧で見る',
    menuList: 'マーカー一覧を開く', menuClear: 'このファイルの線をすべて消す', menuClearLocal: 'この画面の線をすべて消す',
    saveFail: '線を保存できませんでした',
    leaveUnsaved: function (n) { return '保存されない線 ' + n + '件は、閉じると消えます。閉じますか？'; }, leaveOk: '閉じる', leaveBack: '戻る',
    clearConfirm: 'このファイルの線をすべて消しますか？（元の .md は変わりません）', clearOk: 'すべて消す'
  },
  edit: {
    back: '← 閲覧に戻る', save: '保存', saving: '保存しています…', dirty: '● 未保存', saved: '✓ 保存しました', previewTitle: 'プレビュー', editTitle: '編集（Markdownの文字）',
    tabEdit: '編集', tabPreview: 'プレビュー', stat: function (l, c, t) { return l + '行目 ' + c + '列目 ／ 全 ' + t + '行'; },
    encInfo: function (enc, eol) { return (enc === 'utf8bom' ? 'UTF-8（BOMあり）' : 'UTF-8（BOMなし）') + '／改行 ' + (eol === 'crlf' ? 'CRLF' : 'LF'); },
    notUtf8: 'このファイルは UTF-8 以外の文字コード（Shift_JIS など）のため、このソフトでは編集できません。表示と PDF 保存はできます。',
    notUtf8Title: 'このファイルは編集できません（UTF-8以外）',
    localNote: 'この開き方（ドラッグ＆ドロップ）では編集できません。トップ画面の「ファイルを選ぶ」から開いてください。',
    saveTitle: 'ファイルを上書き保存しますか？',
    saveText: function (n) { return n + ' を、いまの内容で上書きします。'; },
    saveBak: function (n) { return '念のため、直前の状態を「' + n + '.bak」としてコピーしておきます。'; },
    mixedEol: function (eol) { return '※この文書は改行の種類がまざっています。保存すると、すべて ' + eol + ' にそろいます。'; },
    saveBakNote: '（.bak は、元に戻したいときのための控えです。次の保存で、新しい控えに入れ替わります。）',
    cancel: 'キャンセル', doSave: '上書き保存する',
    savedToast: function (n) { return '✓ 保存しました。直前の内容は「' + n + '」に残してあります。'; }, openFolder: 'フォルダを開く',
    leaveTitle: '保存していない変更があります', leaveText: function (n) { return '「' + n + '」の変更は、まだ保存されていません。'; },
    discard: '変更を捨てて戻る', saveBack: '保存して戻る',
    conflictTitle: 'このファイルは、他のソフトで変更されています',
    conflictText: function (n) { return '開いたあとに、「' + n + '」が書き換えられました。このまま保存すると、その変更が消えます。'; },
    conflictList: ['「別名で保存」…新しい名前で保存します。元のファイルはそのままです。（おすすめ）', '「上書きする」…いまの編集内容で置き換えます。', '「戻る」…何もせず、編集に戻ります。'],
    overwrite: '上書きする', back2: '戻る', saveAs: '別名で保存',
    changedBar: 'このファイルは、他のソフトで変更されました。', reloadLatest: '最新の内容を読み込む（編集中の内容は消えます）', keepEditing: 'このまま編集を続ける',
    bakFailTitle: 'バックアップを作れませんでした', bakFailText: ['保存を中止しました。元のファイルは変わっていません。', 'このフォルダに書き込めない可能性があります。', '別の場所に保存するには、「別名で保存」を押してください。'],
    writeFailTitle: '保存できませんでした', writeFailText: ['保存できませんでした。元のファイルは変わっていません。', 'ディスクの空きや、他のソフトで開いていないかを確認してください。'],
    savedAs: function (n) { return '別名で保存しました（' + n + '）'; }, openIt: '開く', close: '閉じる',
    tooLarge: '10MBを超えるため保存できません。', notUtf8Save: 'このファイルは UTF-8 ではないため、保存できません。',
    empty: 'このファイルは空です。'
  },
  recent: {
    title: '最近のファイル', clear: '履歴を消す', settings: '設定', remove: '一覧から消す', removeAria: 'この履歴を一覧から消す',
    missing: '見つかりません', missingNote: '移動または削除された可能性があります。',
    marks: function (n) { return '線あり'; },
    empty: '最近開いたファイルがここに出ます。まだありません。', off: '履歴は残さない設定です。（設定で変えられます）',
    clearTitle: '最近のファイルの履歴を消しますか？', clearText: '一覧が空になります。ファイルそのものや、マーカー（線）は消えません。', clearOk: '履歴を消す', cleared: '履歴を消しました',
    more: 'すべて表示', today: '今日', yesterday: '昨日'
  },
  settings: {
    title: '設定',     update: '更新のお知らせ', updateLabel: '最新版があるかどうか、起動時に確認する',
    updateNotes: ['確認は1日に1回まで。アプリ名とバージョン番号だけ送ります。', '文書の内容やファイル名は送りません。', 'オフにすると、この通信は一切しません。'],
    history: '最近のファイル', historyLabel: '最近開いたファイルを覚える', historyNote: 'ファイルの場所に個人名が入ることがあります。画面を共有するときはご注意ください。',
    display: '表示', fontSize: '文字の大きさ', fs: { s: '小', m: '標準', l: '大', xl: '特大' },
    pdfMarks: 'PDFにマーカーを入れる',
    saveFail: '保存できませんでした',
    theme: '配色テーマ', themeNote: '画面の表示だけが変わります。印刷とPDF保存は、いつも白い紙・黒い文字です（マーカーの色はそのまま入ります）。',
    docs: '同梱の説明', terms: '利用規約', privacy: 'プライバシーについて', howto: '使い方'
  },
  // 配色テーマ（id は CSS の [data-theme="…"] と、サーバー側の一覧と同じ。すべて無料）
  themes: [
    { id: 'standard', name: '標準' },
    { id: 'white', name: '白地に黒文字' },
    { id: 'sepia', name: 'セピア' },
    { id: 'charcoal', name: 'ダーク' },
    { id: 'bluegray', name: 'ブルーグレー' },
    { id: 'green', name: 'グリーン' },
    { id: 'contrast', name: 'ハイコントラスト' }
  ],
  first: {
    title: 'はじめに（通信についてのお知らせ）', lead: 'このソフトがインターネットを使うのは、次のときだけです。',
    list: ['最新版のお知らせの確認（1日1回まで・オフにできます）'],
    send: '送るのは、アプリ名とバージョン番号だけです。文書の内容・ファイル名・場所は送りません。',
    ask: '最新版のお知らせを確認しますか？（あとから設定で変えられます）', no: '確認しない', yes: '確認する（おすすめ）'
  },
  update: {
    text: function (v) { return '最新版があります（' + v + '）。'; }, open: 'ダウンロードページを開く', later: 'あとで', never: '今後表示しない',
    neverToast: '更新の確認をオフにしました。設定でいつでも戻せます。', openFail: 'ページを開けませんでした。'
  },
  pdf: {
    making: 'PDFを作っています…', makingMarks: '線入りのPDFを作っています…',
    done: 'PDFを保存しました（ダウンロードフォルダ）', doneMarks: function (n) { return 'PDFを保存しました（ダウンロードフォルダ）。線 ' + n + '件を含みます。'; },
    fallback: '自動作成に失敗したため、印刷画面を開きます（「PDFとして保存」を選んでください）'
  },
  state: {
    noFile: ['ファイルが選ばれていません', '.md ファイルを開くと、ここに表示されます。'],
    notFound: ['ファイルが見つかりません', '移動・削除された可能性があります。'],
    tooLarge: ['ファイルが大きすぎます', '10MBまでのファイルを開けます。'],
    badType: ['このファイルは開けません', '.md / .markdown / .txt のファイルを選んでください。'],
    readFail: ['ファイルを読み込めませんでした', '他のソフトで開いているか、読む権限がない可能性があります。'],
    empty: ['このファイルは空です。', '内容を書き足すと、ここに表示されます。'],
    disconnected: ['ソフトとの通信が途切れました', 'このウィンドウを閉じて、もう一度 .md ファイルをダブルクリックしてください。'],
    pick: 'ファイルを選ぶ', toTop: 'トップ画面へ戻る', reread: 'もう一度読み込む', reload: '再読み込み', details: '詳しく見る', localMissing: 'ファイルが見つかりません。トップ画面からもう一度ファイルを選んでください。'
  },
  top: {
    open: '.md ファイルを開く', drop: 'ここに .md ファイルをドラッグ＆ドロップ', or: 'または', badDrop: 'このファイルは開けません。.md / .markdown / .txt のファイルを選んでください。', oneAtATime: 'ファイルは1つずつ開いてください。',
    dropNote: '※「ファイルを選ぶ」か、エクスプローラーから開いたときだけ、PDFを1ボタンで保存できます。ドラッグ＆ドロップで開いた場合は「印刷」→「PDFとして保存」を選びます。',
    howtoTitle: '使い方',
    howto: ['エクスプローラーで .md ファイルを右クリックします。', '「プログラムから開く」→「MDReader」を選びます。（「常にこのアプリを使う」を選ぶと、ダブルクリックで開けます）', '右上の「PDFで保存」を押すと、ダウンロードフォルダにPDFができます。', '文字をドラッグで選ぶと、マーカー（線）の色が選べます。マーカーは自動で保存されます。']
  },
  noLocalFeature: 'この開き方（ドラッグ＆ドロップ）では使えません。「ファイルを選ぶ」から開いてください。',
  netError: '通信に失敗しました。もう一度お試しください。', copiedMsg: 'コピーしました'
};
