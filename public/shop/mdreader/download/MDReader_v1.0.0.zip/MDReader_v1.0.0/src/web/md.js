// 自作Markdownレンダラ（外部ライブラリなし）。HTMLは必ずエスケープする。
(function (global) {
  'use strict';

  // ---- 安全のための上限（悪意のある・極端な .md でも固まらない） ----
  var MAX_LINE = 100000;      // 1行の最大文字数。超えた分は切る
  var MAX_DEPTH = 30;         // 引用・リストの入れ子の最大の深さ。超えたら平らな文字で表示
  var BUDGET_MS = 6000;       // 表示にかけてよい時間。超えたら残りは整形せず文字のまま表示
  var cur = { cut: false, depth: false, longLines: 0, deadline: 0 };   // render ごとの状態

  function esc(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function unesc(s) {
    return s.replace(/&quot;/g, '"').replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&amp;/g, '&');
  }
  function indentOf(s) { return s.replace(/\t/g, '    ').length; }

  // ---- インライン ----
  function emph(t) {
    // 長さに上限（{0,800}）をつけて、閉じていない記号が大量にあっても処理時間が増えすぎないようにする
    t = t.replace(/\*\*\*(?=\S)([\s\S]{0,800}?\S)\*\*\*/g, '<strong><em>$1</em></strong>');
    t = t.replace(/\*\*(?=\S)([\s\S]{0,800}?\S)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/(^|[^\w])__(?=\S)([\s\S]{0,800}?\S)__(?!\w)/g, '$1<strong>$2</strong>');
    t = t.replace(/\*(?=\S)([\s\S]{0,800}?\S)\*/g, '<em>$1</em>');
    t = t.replace(/(^|[^\w])_(?=\S)([\s\S]{0,800}?\S)_(?!\w)/g, '$1<em>$2</em>');
    t = t.replace(/~~(?=\S)([\s\S]{0,800}?\S)~~/g, '<del>$1</del>');
    return t;
  }
  // URL の判定用に、ブラウザが無視する文字（制御文字・空白類）を取り除く
  function cleanUrl(u) {
    return u.replace(/[\u0000-\u0020\u007f-\u00a0\u1680\u180e\u2000-\u200f\u2028-\u202f\u205f-\u2064\u3000\ufeff]/g, '');
  }
  // 戻り値: 'ext'（http/https/mailto）／'hash'（ページ内 #）／'rel'（スキームなしの相対）／'bad'（リンクにしない）
  function urlKind(c) {
    if (!c) return 'bad';
    if (/^[a-z][a-z0-9+.-]*:/i.test(c)) return /^(https?:|mailto:)/i.test(c) ? 'ext' : 'bad';
    if (c.charAt(0) === '#') return 'hash';
    if (/^[\\/]/.test(c)) return 'bad';      // //host・/api/…・\host は外部／アプリ内部を指すので無効
    return 'rel';
  }

  // 長い文字列は2万文字ごとに区切って処理する（改行の位置で区切る。全体の処理時間が文字数に比例するようにするため）
  var CHUNK = 20000;
  function inline(s, o) {
    if (s.length > CHUNK) {
      var res = '', pos = 0;
      while (pos < s.length) {
        if (cur.cut || Date.now() > cur.deadline) { cur.cut = true; res += esc(s.slice(pos)); break; }
        var end = Math.min(s.length, pos + CHUNK);
        if (end < s.length) { var nl = s.lastIndexOf('\n', end - 1); if (nl > pos) end = nl + 1; }
        res += inline1(s.slice(pos, end), o);
        pos = end;
      }
      return res;
    }
    return inline1(s, o);
  }
  function inline1(s, o) {
    if (cur.cut) return esc(s);
    var st = [];
    function put(h) { st.push(h); return '\u0001' + (st.length - 1) + '\u0002'; }
    // コード
    s = s.replace(/(`+)([\s\S]{0,2000}?[^`])\1(?!`)/g, function (m, a, b) { return put('<code>' + esc(b.trim()) + '</code>'); });
    // バックスラッシュエスケープ
    s = s.replace(/\\([\\`*_{}\[\]()#+\-.!|~>])/g, function (m, c) { return put(esc(c)); });
    s = esc(s);
    // 画像
    s = s.replace(/!\[([^\]]{0,1000})\]\(\s*([^)\s]{1,2000})(?:\s+&quot;(.{0,500}?)&quot;)?\s*\)/g, function (m, alt, url, title) {
      alt = alt.replace(/\u0001\d+\u0002/g, '');
      var src = o && o.img ? o.img(unesc(url)) : null;
      if (!src) return put('<span class="blocked-img">[画像: ' + alt + '（表示できない画像です）]</span>');
      return put('<img src="' + esc(src) + '" alt="' + alt + '"' + (title ? ' title="' + title + '"' : '') + '>');
    });
    // リンク（http/https/mailto は別ウィンドウ。相対の .md だけアプリ内で開く。それ以外は文字だけ）
    s = s.replace(/\[([^\]]{1,1000})\]\(\s*([^)\s]{1,2000})(?:\s+&quot;(.{0,500}?)&quot;)?\s*\)/g, function (m, text, url, title) {
      var c = cleanUrl(unesc(url));
      var kind = urlKind(c), href = null, ext = false;
      if (kind === 'ext') { href = c; ext = true; }
      else if (kind === 'hash') href = c;
      else if (kind === 'rel') {
        href = o && o.link ? o.link(c) : null;
        if (typeof href !== 'string' || href.indexOf('/view?path=') !== 0) href = null;   // アプリの表示画面以外は不可
      }
      if (href == null) return text;
      return put('<a href="' + esc(href) + '"' + (ext ? ' target="_blank" rel="noopener noreferrer"' : '') + (title ? ' title="' + title + '"' : '') + '>' + emph(text) + '</a>');
    });
    // 自動リンク
    s = s.replace(/&lt;(https?:\/\/[^\s&]+(?:&amp;[^\s&]+)*)&gt;/g, function (m, u) {
      return put('<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + u + '</a>');
    });
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<>()\u0001]{1,2000}[^\s<>().,;:!?'"\u0001])/g, function (m, pre, u) {
      return pre + put('<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + u + '</a>');
    });
    s = emph(s);
    s = s.replace(/ {2,}\n|\\\n/g, '<br>\n');
    // 目印を元に戻す（入れ子は数段まで。念のため回数に上限をつけて、無限に回らないようにする）
    for (var n = 0; n < 8 && /\u0001\d+\u0002/.test(s); n++) {
      s = s.replace(/\u0001(\d+)\u0002/g, function (m, i) { return st[i] !== undefined ? st[i] : ''; });
    }
    return s.replace(/[\u0001\u0002]/g, '');
  }

  // ---- ブロック ----
  var LIST_RE = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/;
  var TABLE_SEP = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;

  function splitCells(l) {
    l = l.trim();
    if (l.charAt(0) === '|') l = l.slice(1);
    if (/[^\\]\|$/.test(l)) l = l.slice(0, -1);
    return l.split(/(?<!\\)\|/).map(function (c) { return c.trim().replace(/\\\|/g, '|'); });
  }
  function isBlockStart(line) {
    return /^\s{0,3}#{1,6}\s/.test(line) || /^\s{0,3}(```|~~~)/.test(line) ||
      /^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line) || /^\s{0,3}>/.test(line) || LIST_RE.test(line);
  }

  // 整形しないで、そのまま文字として出す（深すぎる入れ子・時間切れのとき）
  function plain(lines) { return '<pre class="md-plain">' + esc(lines.join('\n')) + '</pre>'; }

  function blocks(lines, o, depth) {
    depth = depth || 0;
    if (depth > MAX_DEPTH) { cur.depth = true; return plain(lines); }
    var out = [], i = 0, m;
    while (i < lines.length) {
      // 時間がかかりすぎたら、残りは整形せずに文字のまま出す
      if (cur.cut || Date.now() > cur.deadline) { cur.cut = true; out.push(plain(lines.slice(i))); break; }
      var line = lines[i];
      if (/^\s*$/.test(line)) { i++; continue; }

      // コードブロック
      m = /^\s{0,3}(```+|~~~+)\s*([^`\s]*)[^`]*$/.exec(line);
      if (m) {
        var fence = m[1], buf = [];
        var closeRe = new RegExp('^\\s{0,3}' + (fence.charAt(0) === '`' ? '`' : '~') + '{' + fence.length + ',}\\s*$');
        i++;
        while (i < lines.length && !closeRe.test(lines[i])) { buf.push(lines[i]); i++; }
        i++;
        out.push('<pre><code' + (m[2] ? ' class="lang-' + esc(m[2]) + '"' : '') + '>' + esc(buf.join('\n')) + '</code></pre>');
        continue;
      }
      // 見出し
      m = /^\s{0,3}(#{1,6})\s+(.*)$/.exec(line);
      if (m) {
        // 末尾の空白と閉じの # を取る（正規表現の「後ろ向き探索」は遅くなりうるので手で処理）
        var hb = m[2].trimEnd(), hk = hb.length;
        while (hk > 0 && hb.charAt(hk - 1) === '#') hk--;
        if (hk < hb.length && hk > 0 && /\s/.test(hb.charAt(hk - 1))) hb = hb.slice(0, hk).trimEnd();
        out.push('<h' + m[1].length + '>' + inline(hb, o) + '</h' + m[1].length + '>'); i++; continue;
      }
      // 水平線
      if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line)) { out.push('<hr>'); i++; continue; }
      // 引用
      if (/^\s{0,3}>/.test(line)) {
        var qb = [];
        while (i < lines.length && /^\s{0,3}>/.test(lines[i])) { qb.push(lines[i].replace(/^\s{0,3}>\s?/, '')); i++; }
        out.push('<blockquote>' + blocks(qb, o, depth + 1) + '</blockquote>');
        continue;
      }
      // 表
      if (line.indexOf('|') >= 0 && i + 1 < lines.length && lines[i + 1].indexOf('|') >= 0 && lines[i + 1].indexOf('-') >= 0 && TABLE_SEP.test(lines[i + 1])) {
        var head = splitCells(line);
        var aligns = splitCells(lines[i + 1]).map(function (c) {
          if (/^:-+:$/.test(c)) return 'center';
          if (/-:$/.test(c)) return 'right';
          if (/^:-/.test(c)) return 'left';
          return '';
        });
        i += 2;
        var rows = [];
        while (i < lines.length && lines[i].indexOf('|') >= 0 && !/^\s*$/.test(lines[i])) { rows.push(splitCells(lines[i])); i++; }
        var cell = function (tag, t, k) {
          return '<' + tag + (aligns[k] ? ' style="text-align:' + aligns[k] + '"' : '') + '>' + inline(t || '', o) + '</' + tag + '>';
        };
        var th = head.map(function (t, k) { return cell('th', t, k); }).join('');
        var tb = rows.map(function (r) {
          var cs = [];
          for (var k = 0; k < head.length; k++) cs.push(cell('td', r[k], k));
          return '<tr>' + cs.join('') + '</tr>';
        }).join('');
        out.push('<div class="table-wrap"><table><thead><tr>' + th + '</tr></thead><tbody>' + tb + '</tbody></table></div>');
        continue;
      }
      // リスト
      m = LIST_RE.exec(line);
      if (m) {
        var res = parseList(lines, i, o, depth);
        out.push(res.html); i = res.next;
        continue;
      }
      // 段落（setext見出し対応）
      var pb = [];
      while (i < lines.length && !/^\s*$/.test(lines[i])) {
        if (pb.length && (/^=+\s*$/.test(lines[i]) || /^-+\s*$/.test(lines[i]))) {
          var lv = lines[i].charAt(0) === '=' ? 1 : 2;
          out.push('<h' + lv + '>' + inline(pb.join('\n'), o) + '</h' + lv + '>');
          pb = null; i++; break;
        }
        if (pb.length && isBlockStart(lines[i])) break;
        pb.push(lines[i].replace(/^\s+/, '')); i++;
      }
      if (pb && pb.length) out.push('<p>' + inline(pb.join('\n'), o) + '</p>');
    }
    return out.join('\n');
  }

  function parseList(lines, i, o, depth) {
    var first = LIST_RE.exec(lines[i]);
    var base = indentOf(first[1]);
    var ordered = /\d/.test(first[2]);
    var start = ordered ? parseInt(first[2], 10) : 1;
    var items = [];
    while (i < lines.length) {
      var mm = LIST_RE.exec(lines[i]);
      if (!mm) {
        if (/^\s*$/.test(lines[i])) {
          var j = i + 1;
          while (j < lines.length && /^\s*$/.test(lines[j])) j++;
          if (j < lines.length) {
            var n = LIST_RE.exec(lines[j]);
            if (n && indentOf(n[1]) >= base && (indentOf(n[1]) > base || /\d/.test(n[2]) === ordered)) { i = j; continue; }
          }
          break;
        }
        if (/^\s+\S/.test(lines[i]) && items.length && indentOf(lines[i].match(/^\s*/)[0]) > base) {
          items[items.length - 1].body.push(lines[i].trim()); i++; continue;
        }
        break;
      }
      var ind = indentOf(mm[1]);
      if (ind < base) break;
      if (ind === base && /\d/.test(mm[2]) !== ordered) break; // 箇条書き⇔番号付きが切り替わったら別のリスト
      if (ind > base && items.length) {
        var sub = [];
        while (i < lines.length) {
          var t = LIST_RE.exec(lines[i]);
          if ((t && indentOf(t[1]) > base) || (!t && /^\s+\S/.test(lines[i]) && indentOf(lines[i].match(/^\s*/)[0]) > base)) { sub.push(lines[i]); i++; }
          else if (/^\s*$/.test(lines[i]) && i + 1 < lines.length && LIST_RE.test(lines[i + 1]) && indentOf(LIST_RE.exec(lines[i + 1])[1]) > base) { sub.push(lines[i]); i++; }
          else break;
        }
        items[items.length - 1].children = items[items.length - 1].children.concat(sub);
        continue;
      }
      items.push({ text: mm[3], body: [], children: [] });
      i++;
    }
    var tag = ordered ? 'ol' : 'ul';
    var html = '<' + tag + (ordered && start !== 1 ? ' start="' + start + '"' : '') + '>' + items.map(function (it) {
      var text = it.text, cls = '', box = '';
      var tm = /^\[( |x|X)\]\s+(.*)$/.exec(text);
      if (tm) { cls = ' class="task"'; box = '<input type="checkbox" disabled' + (tm[1] !== ' ' ? ' checked' : '') + '> '; text = tm[2]; }
      var inner = inline([text].concat(it.body).join('\n'), o);
      if (it.children.length) inner += '\n' + blocks(it.children, o, depth + 1);
      return '<li' + cls + '>' + box + inner + '</li>';
    }).join('\n') + '</' + tag + '>';
    return { html: html, next: i };
  }

  function render(text, o) {
    text = String(text).replace(/^\ufeff/, '').replace(/\r\n?/g, '\n');
    // 制御文字（タブ・改行以外）は表示に意味がなく、内部の目印とぶつかるので先に取り除く
    text = text.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');
    cur = { cut: false, depth: false, longLines: 0, deadline: Date.now() + BUDGET_MS };
    var pre = '';
    var fm = /^---\n([\s\S]*?)\n---\n?/.exec(text);
    if (fm) { pre = '<pre class="frontmatter"><code>' + esc(fm[1]) + '</code></pre>'; text = text.slice(fm[0].length); }
    var lines = text.split('\n');
    for (var k = 0; k < lines.length; k++) {
      if (lines[k].length > MAX_LINE) { lines[k] = lines[k].slice(0, MAX_LINE); cur.longLines++; }
    }
    var html = pre + blocks(lines, o || {}, 0);
    // 実行結果の注意点（画面側が案内を出す）
    global.MD.lastInfo = { cut: cur.cut, depth: cur.depth, longLines: cur.longLines };
    return html;
  }

  global.MD = { render: render, lastInfo: { cut: false, depth: false, longLines: 0 }, limits: { MAX_LINE: MAX_LINE, MAX_DEPTH: MAX_DEPTH, BUDGET_MS: BUDGET_MS } };
})(window);
