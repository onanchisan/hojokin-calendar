﻿# .md の読み込み（文字コード判定・スタンプ）、編集の保存・別名保存、画像、PDF作成ジョブ

$script:PdfJobs = New-Object System.Collections.ArrayList
$script:PendingCleanup = New-Object System.Collections.ArrayList   # 削除に失敗した一時フォルダ（あとで再試行）

# バイト列を文字列にする。戻り値: text / enc(utf8|utf8bom|utf16|cp932) / eol(crlf|lf)
function ConvertFrom-MdBytes([byte[]]$b) {
  $strict = New-Object System.Text.UTF8Encoding($false, $true)
  $enc = 'utf8'; $text = ''
  if ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) {
    try { $text = $strict.GetString($b, 3, $b.Length - 3); $enc = 'utf8bom' }
    catch { $text = [Text.Encoding]::GetEncoding(932).GetString($b, 3, $b.Length - 3); $enc = 'cp932' }
  }
  elseif ($b.Length -ge 2 -and $b[0] -eq 0xFF -and $b[1] -eq 0xFE) { $text = [Text.Encoding]::Unicode.GetString($b, 2, $b.Length - 2); $enc = 'utf16' }
  elseif ($b.Length -ge 2 -and $b[0] -eq 0xFE -and $b[1] -eq 0xFF) { $text = [Text.Encoding]::BigEndianUnicode.GetString($b, 2, $b.Length - 2); $enc = 'utf16' }
  else {
    try { $text = $strict.GetString($b) }
    catch { $text = [Text.Encoding]::GetEncoding(932).GetString($b); $enc = 'cp932' }
  }
  $crlf = ([regex]::Matches($text, "`r`n")).Count
  $lf = ([regex]::Matches($text, "(?<!`r)`n")).Count
  $eol = 'lf'; if ($crlf -gt $lf) { $eol = 'crlf' }
  return @{ text = $text; enc = $enc; eol = $eol; mixed = [bool]($crlf -gt 0 -and $lf -gt 0) }
}

# 読み込み。10MB超は error='TOO_LARGE'
function Read-MdFile([string]$full) {
  $fi = Get-Item -LiteralPath $full
  if ($fi.Length -gt 10MB) { return @{ error = 'TOO_LARGE' } }
  $bytes = [IO.File]::ReadAllBytes($full)
  $r = ConvertFrom-MdBytes $bytes
  $r.mtime = [string]$fi.LastWriteTimeUtc.Ticks
  $r.size = [string]$bytes.Length
  $r.sha = Get-Sha256Hex $bytes
  return $r
}

function ConvertTo-FileBytes([string]$text, [string]$enc, [string]$eol) {
  $t = $text.Replace("`r`n", "`n").Replace("`r", "`n")
  if ($eol -eq 'crlf') { $t = $t.Replace("`n", "`r`n") }
  $body = $script:Utf8NoBom.GetBytes($t)
  $ms = New-Object IO.MemoryStream
  if ($enc -eq 'utf8bom') { $ms.Write([byte[]]@(0xEF, 0xBB, 0xBF), 0, 3) }
  $ms.Write($body, 0, $body.Length)
  $out = $ms.ToArray(); $ms.Dispose()
  return ,$out
}

# 編集の保存（4-3）。番号順に実行し、どこで失敗しても元ファイルには触れない。戻り値: @{code; body}
function Save-MdFile([string]$full, [string]$text, $stamp, [bool]$force) {
  if ($script:Utf8NoBom.GetByteCount($text) -gt 10MB) { return @{ code = 413; body = @{ ok = $false; code = 'TOO_LARGE' } } }
  $fi = Get-Item -LiteralPath $full
  if ($fi.Length -gt 10MB) { return @{ code = 413; body = @{ ok = $false; code = 'TOO_LARGE' } } }
  $bytes = [IO.File]::ReadAllBytes($full)
  $cur = ConvertFrom-MdBytes $bytes
  if ($cur.enc -ne 'utf8' -and $cur.enc -ne 'utf8bom') { return @{ code = 415; body = @{ ok = $false; code = 'NOT_UTF8' } } }
  $curSha = Get-Sha256Hex $bytes
  $curStamp = @{ mtime = [string]$fi.LastWriteTimeUtc.Ticks; size = [string]$bytes.Length; sha256 = $curSha }
  if (-not $force) {
    if ($null -eq $stamp -or [string](Get-Prop $stamp 'sha256' '') -ne $curSha -or [string](Get-Prop $stamp 'size' '') -ne $curStamp.size -or [string](Get-Prop $stamp 'mtime' '') -ne $curStamp.mtime) {
      return @{ code = 409; body = @{ ok = $false; code = 'CHANGED'; stamp = $curStamp } }
    }
  }
  $newBytes = ConvertTo-FileBytes $text $cur.enc $cur.eol
  $bak = $full + '.bak'
  try { [IO.File]::Copy($full, $bak, $true) }
  catch { Write-AppLog 'BAK_FAILED' $_.Exception.GetType().Name; return @{ code = 423; body = @{ ok = $false; code = 'BAK_FAILED' } } }
  $dir = Split-Path -Parent $full
  $tmp = Join-Path $dir ('.' + [IO.Path]::GetFileName($full) + '.' + (Get-RandomHex 4) + '.mdvtmp')
  try {
    [IO.File]::WriteAllBytes($tmp, $newBytes)
    [IO.File]::Replace($tmp, $full, [NullString]::Value)
  } catch {
    try { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force } } catch { }
    Write-AppLog 'WRITE_FAILED' $_.Exception.GetType().Name
    return @{ code = 500; body = @{ ok = $false; code = 'WRITE_FAILED' } }
  }
  $fi2 = Get-Item -LiteralPath $full
  $ns = @{ mtime = [string]$fi2.LastWriteTimeUtc.Ticks; size = [string]$newBytes.Length; sha256 = (Get-Sha256Hex $newBytes) }
  return @{ code = 200; body = @{ ok = $true; stamp = $ns; bak = [IO.Path]::GetFileName($bak) } }
}

# 別名保存: <名前>.edited.md を新規作成だけ（既存は絶対に上書きしない）
function Save-MdFileAs([string]$full, [string]$text) {
  if ($script:Utf8NoBom.GetByteCount($text) -gt 10MB) { return @{ code = 413; body = @{ ok = $false; code = 'TOO_LARGE' } } }
  $bytes = [IO.File]::ReadAllBytes($full)
  $cur = ConvertFrom-MdBytes $bytes
  $enc = $cur.enc; if ($enc -ne 'utf8bom') { $enc = 'utf8' }
  $newBytes = ConvertTo-FileBytes $text $enc $cur.eol
  $dir = Split-Path -Parent $full
  $base = [IO.Path]::GetFileNameWithoutExtension($full)
  for ($n = 1; $n -le 99; $n++) {
    $name = if ($n -eq 1) { $base + '.edited.md' } else { $base + '.edited-' + $n + '.md' }
    $dest = Join-Path $dir $name
    if (Test-Path -LiteralPath $dest) { continue }
    try {
      $fs = New-Object IO.FileStream($dest, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
      try { $fs.Write($newBytes, 0, $newBytes.Length) } finally { $fs.Close() }
      return @{ code = 200; body = @{ ok = $true; path = [string]$dest; name = [string]$name } }
    } catch [System.IO.IOException] {
      if (Test-Path -LiteralPath $dest) { continue }   # 同時に作られた → 次の番号へ
      Write-AppLog 'SAVEAS_FAILED' 'IO'
      return @{ code = 500; body = @{ ok = $false; code = 'WRITE_FAILED' } }
    } catch {
      Write-AppLog 'SAVEAS_FAILED' $_.Exception.GetType().Name
      return @{ code = 500; body = @{ ok = $false; code = 'WRITE_FAILED' } }
    }
  }
  return @{ code = 500; body = @{ ok = $false; code = 'WRITE_FAILED' } }
}

# ---- Edge / Chrome ----
function Find-Edge {
  $c = New-Object System.Collections.ArrayList
  foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
    if ($base) { [void]$c.Add((Join-Path $base 'Microsoft\Edge\Application\msedge.exe')) }
  }
  try {
    $reg = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe' -ErrorAction Stop).'(default)'
    if ($reg) { [void]$c.Add($reg) }
  } catch { }
  foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if ($base) { [void]$c.Add((Join-Path $base 'Google\Chrome\Application\chrome.exe')) }
  }
  foreach ($x in $c) { if ($x -and (Test-Path -LiteralPath $x)) { return $x } }
  return $null
}

# PDF作成ジョブ: Edge をヘッドレスで起動して印刷用ページをPDFにする。完了はメインループで拾う
function Start-PdfJob($ctx, [string]$full) {
  $edge = Find-Edge
  if (-not $edge) { return $false }
  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('mdviewer-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  $pdf = Join-Path $tmp 'out.pdf'
  $url = "http://127.0.0.1:$($script:Port)/view?print=1&path=" + [uri]::EscapeDataString($full)
  $a = "--headless --disable-gpu --no-pdf-header-footer --user-data-dir=`"$(Join-Path $tmp 'profile')`" --virtual-time-budget=8000 --print-to-pdf=`"$pdf`" `"$url`""
  $proc = Start-Process -FilePath $edge -ArgumentList $a -PassThru -WindowStyle Hidden
  [void]$script:PdfJobs.Add(@{ ctx = $ctx; proc = $proc; pdf = $pdf; tmp = $tmp; name = [IO.Path]::GetFileNameWithoutExtension($full); start = Get-Date })
  return $true
}
function Remove-TempDirLater([string]$dir) {
  try { Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue } catch { }
  if (Test-Path -LiteralPath $dir) { [void]$script:PendingCleanup.Add($dir) }
}
function Step-PdfJobs {
  for ($i = $script:PendingCleanup.Count - 1; $i -ge 0; $i--) {
    $d = $script:PendingCleanup[$i]
    try { Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue } catch { }
    if (-not (Test-Path -LiteralPath $d)) { $script:PendingCleanup.RemoveAt($i) }
  }
  for ($i = $script:PdfJobs.Count - 1; $i -ge 0; $i--) {
    $j = $script:PdfJobs[$i]
    $exited = $j.proc.HasExited
    if ($exited -or ((Get-Date) - $j.start).TotalSeconds -gt 60) {
      if (-not $exited) { try { $j.proc.Kill() } catch { } }
      if ((Test-Path -LiteralPath $j.pdf) -and ((Get-Item -LiteralPath $j.pdf).Length -gt 0)) {
        $b = [IO.File]::ReadAllBytes($j.pdf)
        $disp = "attachment; filename*=UTF-8''" + [uri]::EscapeDataString($j.name + '.pdf')
        Send-Resp $j.ctx (New-Resp 200 'application/pdf' $b @{ 'Content-Disposition' = $disp })
      } else {
        Send-Resp $j.ctx (New-JsonResp 500 @{ ok = $false; code = 'PDF_FAILED' })
      }
      Remove-TempDirLater $j.tmp
      $script:PdfJobs.RemoveAt($i)
    }
  }
}
function Stop-AllPdfJobs {
  foreach ($j in $script:PdfJobs) {
    try { if (-not $j.proc.HasExited) { $j.proc.Kill() } } catch { }
    Remove-TempDirLater $j.tmp
  }
  $script:PdfJobs.Clear()
  Start-Sleep -Milliseconds 500
  foreach ($d in @($script:PendingCleanup)) { try { Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue } catch { } }
}
