﻿# HTTP処理: ルーティング、トークン／Origin／Host 検査、応答送信、API ハンドラ
# 127.0.0.1 だけで待ち受ける。/api/*（ping以外）は起動ごとの一時トークン必須。
# すべての機能が無料（有料登録・キー確認はない）。書き込みを伴うAPIは、トークン・Origin・Content-Type・パス検査で守る。

$script:Windows = @{}
$script:Shells = @{}                                          # タブの親ページ（窓）の生存時刻
$script:OpenQueue = New-Object System.Collections.ArrayList   # 2つ目の起動から渡された「開いてほしい .md」
$script:Handoff = ''                                          # 2つ目の起動が使う合言葉（run.json に書く。画面には出さない）
$script:Mime = @{
  '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'
  '.css' = 'text/css; charset=utf-8'; '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.jpeg' = 'image/jpeg'
  '.gif' = 'image/gif'; '.svg' = 'image/svg+xml'; '.webp' = 'image/webp'; '.bmp' = 'image/bmp'
}
$script:Csp = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-src 'self'; frame-ancestors 'self'"
# 配信してよい画面ファイル（これ以外は404）
$script:StaticFiles = @('md.js', 'strings.js', 'icons.js', 'ui.js', 'api.js', 'shell.js', 'marks.js', 'editor.js', 'settings.js', 'recent.js', 'viewer.js', 'index.js', 'style.css', 'favicon.svg')

function New-Resp([int]$code, [string]$type, [byte[]]$bytes, [hashtable]$headers) {
  if ($null -eq $headers) { $headers = @{} }
  return @{ Code = $code; Type = $type; Bytes = $bytes; Headers = $headers }
}
function New-JsonResp([int]$code, $obj, [hashtable]$headers) {
  return (New-Resp $code 'application/json; charset=utf-8' ($script:Utf8NoBom.GetBytes((ConvertTo-JsonText $obj))) $headers)
}
function New-TextResp([int]$code, [string]$text) {
  return (New-Resp $code 'text/plain; charset=utf-8' ($script:Utf8NoBom.GetBytes($text)) $null)
}
function Send-Resp($ctx, $resp) {
  try {
    $r = $ctx.Response
    $r.StatusCode = $resp.Code
    $r.ContentType = $resp.Type
    $r.Headers.Add('X-Content-Type-Options', 'nosniff')
    $r.Headers.Add('Cache-Control', 'no-store')
    $r.Headers.Add('Referrer-Policy', 'no-referrer')
    if ($resp.Type -like 'text/html*') { $r.Headers.Add('Content-Security-Policy', $script:Csp) }
    foreach ($k in $resp.Headers.Keys) { $r.Headers.Add($k, [string]$resp.Headers[$k]) }
    $r.ContentLength64 = $resp.Bytes.Length
    $r.OutputStream.Write($resp.Bytes, 0, $resp.Bytes.Length)
    $r.OutputStream.Close()
  } catch { try { $ctx.Response.Abort() } catch { } }
}

# クエリを UTF-8 として取り出す（HttpListener の QueryString は ANSI 扱いのため自前）
function Get-Q($req, [string]$name) {
  $q = $req.Url.Query
  if (-not $q) { return $null }
  foreach ($pair in $q.TrimStart('?').Split('&')) {
    $kv = $pair.Split('=', 2)
    if ($kv[0] -eq $name -and $kv.Count -eq 2) {
      try { return [uri]::UnescapeDataString($kv[1].Replace('+', '%20')) } catch { return $null }
    }
  }
  return $null
}
function Read-JsonBody($req, [int]$max = 1MB) {
  if ($req.ContentLength64 -gt $max) { throw 'TOO_LARGE' }
  # 本文を少しずつ読む。2秒間まったく届かない、または全体で15秒かかったら打ち切る
  # （途中で止まった送信にサーバー全体が巻き込まれないため。NG-9）
  $ms = New-Object IO.MemoryStream
  $buf = New-Object byte[] 65536
  $stream = $req.InputStream
  $began = Get-Date
  try {
    while ($true) {
      $rt = $stream.ReadAsync($buf, 0, $buf.Length)
      if (-not $rt.Wait(2000)) { throw 'BODY_TIMEOUT' }
      $n = $rt.Result
      if ($n -le 0) { break }
      $ms.Write($buf, 0, $n)
      if ($ms.Length -gt ($max * 4)) { throw 'TOO_LARGE' }
      if (((Get-Date) - $began).TotalSeconds -gt 15) { throw 'BODY_TIMEOUT' }
    }
    $t = $script:Utf8NoBom.GetString($ms.ToArray())
  } finally { $ms.Dispose() }
  if ($t.Length -gt $max) { throw 'TOO_LARGE' }
  try { $o = ConvertFrom-JsonText $t } catch { throw 'BAD_JSON' }
  if ($o -isnot [System.Collections.IDictionary]) { throw 'BAD_JSON' }
  return $o
}
function New-Err([int]$code, [string]$c) { return (New-JsonResp $code @{ ok = $false; code = $c } $null) }

# 画面HTMLにトークンと版を差し込んで返す
function Get-HtmlResp([string]$file) {
  $t = [IO.File]::ReadAllText((Join-Path $script:WebDir $file), $script:Utf8NoBom)
  $t = $t.Replace('{{TOKEN}}', $script:Token).Replace('{{VERSION}}', [string]$script:Cfg.version)
  return (New-Resp 200 $script:Mime['.html'] ($script:Utf8NoBom.GetBytes($t)) $null)
}

# 状態（画面へ渡す）
function Get-StateObj {
  $latest = Get-UpdateAvailable
  $set = $script:Settings
  return [ordered]@{
    version = [string]$script:Cfg.version
    settings = [ordered]@{
      updateCheck = [string]$set['updateCheck']; keepHistory = [bool]$set['keepHistory']; fontSize = [string]$set['fontSize']
      pdfMarks = [bool]$set['pdfMarks']; theme = (Get-EffectiveTheme)
      updateLaterUntil = $set['updateLaterUntil']; updateLaterVersion = $set['updateLaterVersion']
    }
    latestKnown = $latest
    oldPrototype = [bool]$script:OldProto
  }
}

# 既定ブラウザで開く（開発用に MDV_NOOPEN=1 のときは開かず記録だけ）
function Open-External([string]$url) {
  if ($script:IsDev -and $env:MDV_NOOPEN -eq '1') { Write-AppLog 'OPENURL_SKIPPED_DEV' ''; return $true }
  try { Start-Process -FilePath $url | Out-Null; return $true } catch { return $false }
}

# ---- ハンドラ ----
function Handle-Settings($req) {
  $body = Read-JsonBody $req
  $saved = Update-SettingsFromClient $body
  return (New-JsonResp 200 @{ ok = $true; saved = $saved; state = (Get-StateObj) } $null)
}
function Handle-Heartbeat($req) {
  $body = Read-JsonBody $req 4KB
  $id = [string](Get-Prop $body 'id' '')
  if ($id -notmatch '^[0-9a-f]{16}$') { return (New-Err 400 'BAD_REQUEST') }
  $now = Get-Date
  $script:Windows[$id] = $now
  # タブの親ページ（shell）からの通知のときは、「開いてほしい .md」の受け渡しもここで返す
  $open = @()
  if ((Get-Prop $body 'shell' $false) -eq $true) {
    $script:Shells[$id] = $now
    while ($script:OpenQueue.Count -gt 0) { $open += [string]$script:OpenQueue[0]; $script:OpenQueue.RemoveAt(0) }
  }
  return (New-JsonResp 200 @{ ok = $true; open = @($open) } $null)
}
# 生きているタブ親ページの数（8秒以内に通知があったもの）
function Get-LiveShellCount {
  $n = 0; $now = Get-Date
  foreach ($k in @($script:Shells.Keys)) { if (($now - $script:Shells[$k]).TotalSeconds -lt 8) { $n++ } else { $script:Shells.Remove($k) } }
  return $n
}
# 2つ目の起動（.md のダブルクリック・開く.bat）から、すでに動いている窓へ「このファイルをタブで開いて」と頼む。
# 合言葉（run.json）が合うときだけ受け付ける。ブラウザ経由（Origin あり）は拒否。
function Handle-Handoff($req) {
  $body = Read-JsonBody $req 8KB
  $p = [string](Get-Prop $body 'path' '')
  $full = ''
  if ($p) {
    $full = Get-SafePath $p $script:MdExt
    if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  }
  if ((Get-LiveShellCount) -lt 1) { return (New-JsonResp 200 @{ ok = $true; queued = $false } $null) }   # 窓が無い → 呼んだ側が新しく開く
  if ($full) {
    if ($script:OpenQueue.Count -ge 50) { return (New-Err 429 'BUSY') }
    [void]$script:OpenQueue.Add($full)
  }
  return (New-JsonResp 200 @{ ok = $true; queued = $true } $null)
}
function Handle-Bye($req) {
  $id = Get-Q $req 'id'
  if ($id -match '^[0-9a-f]{16}$') { $script:Windows.Remove($id); $script:Shells.Remove($id) }
  return (New-JsonResp 200 @{ ok = $true } $null)
}
function Handle-Md($req) {
  $full = Get-SafePath (Get-Q $req 'path') $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  try { $r = Read-MdFile $full } catch { return (New-Err 500 'READ_FAILED') }
  if ($r.error) { return (New-Err 413 'TOO_LARGE') }
  $h = @{ 'X-Mdv-Encoding' = $r.enc; 'X-Mdv-Eol' = $r.eol; 'X-Mdv-Mtime' = $r.mtime; 'X-Mdv-Size' = $r.size; 'X-Mdv-Sha256' = $r.sha; 'X-Mdv-EolMixed' = $(if ($r.mixed) { '1' } else { '0' }) }
  return (New-Resp 200 'text/plain; charset=utf-8' ($script:Utf8NoBom.GetBytes($r.text)) $h)
}
function Handle-Asset($req) {
  $full = Get-SafePath (Get-Q $req 'path') $script:ImgExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  $ext = [IO.Path]::GetExtension($full).ToLowerInvariant()
  if ((Get-Item -LiteralPath $full).Length -gt 30MB) { return (New-Err 413 'TOO_LARGE') }
  return (New-Resp 200 $script:Mime[$ext] ([IO.File]::ReadAllBytes($full)) $null)
}
function Handle-Pdf($ctx, $req) {
  $full = Get-SafePath (Get-Q $req 'path') $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  if (-not (Start-PdfJob $ctx $full)) { return (New-Err 500 'PDF_UNAVAILABLE') }
  return $null   # 完了時に Step-PdfJobs が返す
}
function Handle-MarksGet($req) {
  $full = Get-SafePath (Get-Q $req 'path') $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  $m = Read-MarksFor $full
  return (New-JsonResp 200 @{ ok = $true; locked = $false; marks = @($m.marks); recovered = [bool]$m.recovered } $null)
}
function Handle-MarksPut($req) {
  $body = Read-JsonBody $req 4MB
  $full = Get-SafePath ([string](Get-Prop $body 'path' '')) $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  $e = Save-MarksFor $full (Get-Prop $body 'marks' $null)
  if ($e) { $c = 400; if ($e -eq 'SAVE_FAILED') { $c = 500 }; return (New-Err $c $e) }
  return (New-JsonResp 200 @{ ok = $true } $null)
}
function Handle-Save($req) {
  $body = Read-JsonBody $req 30MB
  $full = Get-SafePath ([string](Get-Prop $body 'path' '')) $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  $text = Get-Prop $body 'text' $null
  if ($text -isnot [string]) { return (New-Err 400 'BAD_REQUEST') }
  $r = Save-MdFile $full $text (Get-Prop $body 'stamp' $null) ((Get-Prop $body 'force' $false) -eq $true)
  return (New-JsonResp $r.code $r.body $null)
}
function Handle-SaveAs($req) {
  $body = Read-JsonBody $req 30MB
  $full = Get-SafePath ([string](Get-Prop $body 'path' '')) $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  $text = Get-Prop $body 'text' $null
  if ($text -isnot [string]) { return (New-Err 400 'BAD_REQUEST') }
  $r = Save-MdFileAs $full $text
  return (New-JsonResp $r.code $r.body $null)
}
function Handle-RecentGet($req) {
  return (New-JsonResp 200 @{ ok = $true; locked = $false; items = @(Get-RecentView); keepHistory = [bool]$script:Settings['keepHistory'] } $null)
}
function Handle-RecentTouch($req) {
  $body = Read-JsonBody $req 8KB
  $full = Get-SafePath ([string](Get-Prop $body 'path' '')) $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  if (-not [bool]$script:Settings['keepHistory']) { return (New-JsonResp 200 @{ ok = $true; recorded = $false } $null) }
  [void](Add-Recent $full)
  return (New-JsonResp 200 @{ ok = $true; recorded = $true } $null)
}
function Handle-RecentRemove($req) {
  $body = Read-JsonBody $req 8KB
  [void](Remove-Recent ([string](Get-Prop $body 'path' '')))
  return (New-JsonResp 200 @{ ok = $true } $null)
}
function Handle-RecentClear($req) {
  [void](Save-Recent (New-Object System.Collections.ArrayList))
  return (New-JsonResp 200 @{ ok = $true } $null)
}
function Handle-Pick($req) {
  if ($script:IsDev -and $env:MDV_PICK_RESULT) { return (New-JsonResp 200 @{ ok = $true; path = $env:MDV_PICK_RESULT } $null) }
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $owner = New-Object System.Windows.Forms.Form
    $owner.TopMost = $true; $owner.ShowInTaskbar = $false; $owner.Opacity = 0
    $owner.StartPosition = 'CenterScreen'; $owner.Size = New-Object System.Drawing.Size(1, 1)
    $owner.Show()
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'MDReader: ファイルを選ぶ'
    $dlg.Filter = 'Markdown / テキスト (*.md;*.markdown;*.txt)|*.md;*.markdown;*.txt|すべてのファイル (*.*)|*.*'
    $path = $null
    if ($dlg.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $path = $dlg.FileName }
    $owner.Close(); $owner.Dispose(); $dlg.Dispose()
    return (New-JsonResp 200 @{ ok = $true; path = $path } $null)
  } catch { Write-AppLog 'PICK_FAILED' $_.Exception.GetType().Name; return (New-Err 500 'PICK_FAILED') }
}
function Handle-UpdateCheck($req) {
  $started = Start-UpdateCheck
  $pending = [bool]($started -or $script:UpdateJob)
  $av = Get-UpdateAvailable
  $later = $false
  if ($av -and $script:Settings['updateLaterUntil'] -and [string]$script:Settings['updateLaterVersion'] -eq $av.latest) {
    try { if ((Get-Date) -lt [datetime]::Parse([string]$script:Settings['updateLaterUntil'])) { $later = $true } } catch { }
  }
  return (New-JsonResp 200 @{ ok = $true; pending = $pending; available = [bool]$av; latest = $av; later = $later } $null)
}
function Handle-OpenUrl($req) {
  $body = Read-JsonBody $req 4KB
  $which = [string](Get-Prop $body 'which' '')
  $url = ''
  if ($which -eq 'update') {
    $av = Get-UpdateAvailable
    if ($av) { $url = [string]$av.url }
  }
  if (-not $url -or -not (Test-UpdateUrlOk $url)) { return (New-Err 400 'NO_URL') }
  if (-not (Open-External $url)) { return (New-Err 500 'OPEN_FAILED') }
  return (New-JsonResp 200 @{ ok = $true } $null)
}
function Handle-Reveal($req) {
  $body = Read-JsonBody $req 8KB
  $full = Get-SafePath ([string](Get-Prop $body 'path' '')) $script:MdExt
  if (-not $full) { return (New-Err 404 'NOT_FOUND') }
  if ($script:IsDev -and $env:MDV_NOOPEN -eq '1') { return (New-JsonResp 200 @{ ok = $true } $null) }
  try { Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $full + '"') | Out-Null } catch { return (New-Err 500 'OPEN_FAILED') }
  return (New-JsonResp 200 @{ ok = $true } $null)
}

# ---- ルーティング ----
# 戻り値: 応答。PDFのように後で返すものは $null
function Invoke-Route($ctx) {
  $req = $ctx.Request
  $method = $req.HttpMethod
  $path = $req.Url.AbsolutePath
  if ($method -ne 'GET' -and $method -ne 'POST' -and $method -ne 'PUT') { return (New-TextResp 405 'method not allowed') }
  # Host は完全一致（DNSリバインディング対策）
  $host0 = $req.Headers['Host']
  if ($host0 -ne ('127.0.0.1:' + $script:Port)) { return (New-TextResp 403 'forbidden') }
  $origin = $req.Headers['Origin']
  $selfOrigin = 'http://127.0.0.1:' + $script:Port
  if ($origin -and $origin -ne $selfOrigin) { return (New-TextResp 403 'forbidden') }

  $isApi = $path.StartsWith('/api/')
  # 2つ目の起動からの受け渡し: 合言葉（run.json）が必要。ブラウザ（Origin が付く）からは受け付けない
  if ($path -eq '/api/handoff') {
    if ($method -ne 'POST' -or $origin) { return (New-Err 403 'BAD_ORIGIN') }
    if (-not ([string]$req.ContentType -match '^application/json\s*(;|$)')) { return (New-Err 415 'BAD_CONTENT_TYPE') }
    if (-not $script:Handoff -or -not (Test-ConstEq ([string]$req.Headers['X-Mdv-Handoff']) $script:Handoff)) { return (New-Err 403 'BAD_TOKEN') }
    return (Handle-Handoff $req)
  }
  if ($isApi -and $path -ne '/api/ping') {
    $tok = $req.Headers['X-Mdv-Token']
    if (-not $tok) { $tok = Get-Q $req 't' }
    if (-not (Test-ConstEq ([string]$tok) $script:Token)) { return (New-Err 403 'BAD_TOKEN') }
  }
  if ($method -ne 'GET') {
    if ($origin -ne $selfOrigin) { return (New-Err 403 'BAD_ORIGIN') }
    $ct = [string]$req.ContentType
    $okCt = $ct -match '^application/json\s*(;|$)'
    if ($path -eq '/api/bye' -and $ct -match '^text/plain\s*(;|$)') { $okCt = $true }
    if (-not $okCt) { return (New-Err 415 'BAD_CONTENT_TYPE') }
  }

  # 画面ファイル
  if ($method -eq 'GET' -and -not $isApi) {
    if ($path -eq '/' -or $path -eq '/index.html' -or $path -eq '/app') { return (Get-HtmlResp 'shell.html') }
    if ($path -eq '/home') { return (Get-HtmlResp 'index.html') }
    if ($path -eq '/view') { return (Get-HtmlResp 'viewer.html') }
    $name = $path.TrimStart('/')
    if ($script:StaticFiles -contains $name) {
      $f = Join-Path $script:WebDir $name
      if (Test-Path -LiteralPath $f -PathType Leaf) {
        return (New-Resp 200 $script:Mime[[IO.Path]::GetExtension($f)] ([IO.File]::ReadAllBytes($f)) $null)
      }
    }
    return (New-TextResp 404 'not found')
  }

  switch ("$method $path") {
    'GET /api/ping'     { return (New-JsonResp 200 @{ app = 'md-viewer'; version = [string]$script:Cfg.version; pid = $PID } $null) }
    'GET /api/state'    { return (New-JsonResp 200 (Get-StateObj) $null) }
    'POST /api/settings' { return (Handle-Settings $req) }
    'POST /api/hb'      { return (Handle-Heartbeat $req) }
    'POST /api/bye'     { return (Handle-Bye $req) }
    'GET /api/md'       { return (Handle-Md $req) }
    'GET /api/asset'    { return (Handle-Asset $req) }
    'GET /api/pdf'      { return (Handle-Pdf $ctx $req) }
    'GET /api/marks'    { return (Handle-MarksGet $req) }
    'PUT /api/marks'    { return (Handle-MarksPut $req) }
    'POST /api/save'    { return (Handle-Save $req) }
    'POST /api/saveas'  { return (Handle-SaveAs $req) }
    'GET /api/recent'   { return (Handle-RecentGet $req) }
    'POST /api/recent/touch'  { return (Handle-RecentTouch $req) }
    'POST /api/recent/remove' { return (Handle-RecentRemove $req) }
    'POST /api/recent/clear'  { return (Handle-RecentClear $req) }
    'POST /api/pick'    { return (Handle-Pick $req) }
    'POST /api/update/check' { return (Handle-UpdateCheck $req) }
    'POST /api/openurl' { return (Handle-OpenUrl $req) }
    'POST /api/reveal'  { return (Handle-Reveal $req) }
    default { return (New-Err 404 'NOT_FOUND') }
  }
}

# 1リクエストを処理して返す。例外は握りつぶさず 500 とエラー種別だけをログへ
function Handle-Request($ctx) {
  $resp = $null
  try { $resp = Invoke-Route $ctx }
  catch {
    $m = [string]$_.Exception.Message
    if ($m -eq 'TOO_LARGE') { $resp = New-Err 413 'TOO_LARGE' }
    elseif ($m -eq 'BAD_JSON') { $resp = New-Err 400 'BAD_REQUEST' }
    elseif ($m -eq 'BODY_TIMEOUT') { Write-AppLog 'BODY_TIMEOUT' ''; $resp = New-Err 408 'TIMEOUT' }
    else {
      $detail = ''; if ($script:IsDev) { $detail = ' ' + $m + ' @' + $_.InvocationInfo.ScriptLineNumber }   # 詳細は開発用のときだけ
      Write-AppLog 'ERR500' ($_.Exception.GetType().Name + $detail); $resp = New-Err 500 'INTERNAL'
    }
  }
  if ($resp) { Send-Resp $ctx $resp }
}
