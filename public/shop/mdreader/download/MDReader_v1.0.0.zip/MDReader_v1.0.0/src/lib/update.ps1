﻿# 更新確認（version.json の取得と比較）
# このソフトが行う通信は、この更新確認だけ。files.ps1 の関数を呼ばない（パスに触れない）。
# 送るのは User-Agent「MDReader/版」だけ。クエリ文字列なし。

$script:UpdateJob = $null

function Test-UpdateUrlOk([string]$u) {
  # 開く先は onanchi.com / www.onanchi.com の https だけ（version.json 偽装対策）
  try { $x = [Uri]$u } catch { return $false }
  return ($x.Scheme -eq 'https' -and ($x.Host -ceq 'onanchi.com' -or $x.Host -ceq 'www.onanchi.com'))
}

# 24時間以上たち、かつオンのときだけ通信を始める。始めたら $true
function Start-UpdateCheck {
  if ($script:UpdateJob) { return $false }
  if ([string]$script:Settings['updateCheck'] -ne 'on') { return $false }
  $url = [string]$script:Cfg.versionUrl
  if (-not (Test-ApiUrl $url)) { return $false }
  $last = $script:Settings['lastUpdateCheck']
  if ($last) {
    try { if (((Get-Date) - [datetime]::Parse([string]$last)).TotalHours -lt 24) { return $false } } catch { }
  }
  # 試みた時刻を成功・失敗にかかわらず記録（失敗時に起動のたび再試行しない）
  $script:Settings['lastUpdateCheck'] = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
  [void](Save-Settings)
  try {
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add('User-Agent', 'MDReader/' + $script:Cfg.version)
    $task = $wc.DownloadStringTaskAsync([Uri]$url)
    $script:UpdateJob = @{ wc = $wc; task = $task; start = Get-Date }
    return $true
  } catch { Write-AppLog 'UPDATE_START_FAIL' $_.Exception.GetType().Name; return $false }
}

# メインループから呼ぶ。完了していたら結果を取り込む。8秒で打ち切り
function Step-UpdateJob {
  $j = $script:UpdateJob
  if (-not $j) { return }
  $done = $j.task.IsCompleted
  if (-not $done -and ((Get-Date) - $j.start).TotalSeconds -gt 8) {
    try { $j.wc.CancelAsync() } catch { }
    $script:UpdateJob = $null; Write-AppLog 'UPDATE_TIMEOUT' ''
    return
  }
  if (-not $done) { return }
  $script:UpdateJob = $null
  try {
    if ($j.task.IsFaulted -or $j.task.IsCanceled) { Write-AppLog 'UPDATE_FAIL' ''; return }
    $d = ConvertFrom-JsonText ([string]$j.task.Result)
    $latest = [string](Get-Prop $d 'latest' '')
    $url = [string](Get-Prop $d 'url' '')
    if ($latest -notmatch '^\d+\.\d+\.\d+$') { return }
    if (-not (Test-UpdateUrlOk $url)) { $url = '' }
    $script:Settings['latestKnown'] = [ordered]@{ latest = $latest; released = [string](Get-Prop $d 'released' ''); url = $url }
    [void](Save-Settings)
  } catch { Write-AppLog 'UPDATE_PARSE_FAIL' '' }
  finally { try { $j.wc.Dispose() } catch { } }
}

# 保存済みの latestKnown が現在より新しければ返す（無ければ $null）
function Get-UpdateAvailable {
  $k = $script:Settings['latestKnown']
  if (-not $k) { return $null }
  try {
    if ([version][string]$k['latest'] -gt [version][string]$script:Cfg.version) {
      return [ordered]@{ latest = [string]$k['latest']; released = [string](Get-Prop $k 'released' ''); url = [string](Get-Prop $k 'url' '') }
    }
  } catch { }
  return $null
}
