﻿# 共通部品: パス、ログ、JSON読み書き、SHA-256、安全なパス判定
# このファイルは UTF-8（BOM付き）。dot-source で app.ps1 から読み込む。

$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Web.Extensions
$script:Js = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$script:Js.MaxJsonLength = 64MB
$script:Js.RecursionLimit = 64

$script:MdExt  = @('.md', '.markdown', '.txt')
$script:ImgExt = @('.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.bmp')
$script:IsDev  = ($env:MDV_DEV -eq '1')

function Get-DataDir {
  # 保存データの場所。開発用の上書きは MDV_DEV=1 のときだけ有効
  if ($script:IsDev -and $env:MDV_DATA_DIR) { return $env:MDV_DATA_DIR }
  return (Join-Path $env:APPDATA 'MDReader')
}
function Get-LocalDir {
  if ($script:IsDev -and $env:MDV_LOCAL_DIR) { return $env:MDV_LOCAL_DIR }
  return (Join-Path $env:LOCALAPPDATA 'MDReader')
}
function Initialize-DataDir {
  $d = Get-DataDir
  foreach ($x in @($d, (Join-Path $d 'marks'), (Join-Path $d 'logs'))) {
    if (-not (Test-Path -LiteralPath $x)) { New-Item -ItemType Directory -Path $x -Force | Out-Null }
  }
}

# ---- ログ（日時・イベント名・コードだけ。キー・パス・本文は書かない） ----
function Write-AppLog([string]$event, [string]$code = '') {
  try {
    $dir = Join-Path (Get-DataDir) 'logs'
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $f = Join-Path $dir 'app.log'
    if ((Test-Path -LiteralPath $f) -and ((Get-Item -LiteralPath $f).Length -gt 200KB)) {
      Move-Item -LiteralPath $f -Destination ($f + '.old') -Force
    }
    $line = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + ' ' + $event + ' ' + $code
    [IO.File]::AppendAllText($f, $line + "`r`n", $script:Utf8NoBom)
    if ($script:IsDev -and $env:MDV_LOG_CONSOLE -eq '1') { Write-Host $line }
  } catch { }
}

# ---- JSON ----
function ConvertFrom-JsonText([string]$t) { return $script:Js.DeserializeObject($t) }
function ConvertTo-JsonText($o) { return $script:Js.Serialize($o) }

# 辞書から安全に値を取る（無ければ既定値）
function Get-Prop($d, [string]$k, $def = $null) {
  # 配列が1要素に潰れないよう、先頭に , を付けて返す
  if ($null -eq $d) { return ,$def }
  if ($d -is [System.Collections.IDictionary]) {
    if ($d.Keys -contains $k) { $v = $d[$k]; if ($null -ne $v) { return ,$v } }
  }
  return ,$def
}

# 一時ファイルに書いてから入れ替える（途中で壊れない）
function Write-JsonAtomic([string]$path, $obj) {
  $dir = Split-Path -Parent $path
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $tmp = $path + '.tmp'
  [IO.File]::WriteAllText($tmp, (ConvertTo-JsonText $obj), $script:Utf8NoBom)
  if (Test-Path -LiteralPath $path) { [IO.File]::Replace($tmp, $path, [NullString]::Value) }
  else { [IO.File]::Move($tmp, $path) }
}

# 読めなければ $null。壊れていたら ".broken-日時" に改名して残す（-KeepBroken のときは触らない）
function Read-JsonFile([string]$path, [switch]$KeepBroken) {
  $script:LastReadBroken = $false
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
  try {
    $t = [IO.File]::ReadAllText($path, $script:Utf8NoBom)
    if ([string]::IsNullOrWhiteSpace($t)) { throw 'empty' }
    $o = ConvertFrom-JsonText $t
    if ($o -isnot [System.Collections.IDictionary]) { throw 'notobject' }
    return $o
  } catch {
    $script:LastReadBroken = $true
    Write-AppLog 'JSON_BROKEN' ([IO.Path]::GetFileName($path))
    if (-not $KeepBroken) {
      try { Move-Item -LiteralPath $path -Destination ($path + '.broken-' + (Get-Date).ToString('yyyyMMddHHmmss')) -Force } catch { }
    }
    return $null
  }
}

# ---- ハッシュ ----
function Get-Sha256Hex([byte[]]$bytes) {
  $s = [System.Security.Cryptography.SHA256]::Create()
  try { return (-join ($s.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })) }
  finally { $s.Dispose() }
}
function Get-PathId([string]$fullPath) {
  # 元ファイルのフルパス（小文字化）→ UTF-8 → SHA-256 → 先頭32桁
  $b = $script:Utf8NoBom.GetBytes($fullPath.ToLowerInvariant())
  return (Get-Sha256Hex $b).Substring(0, 32)
}
function Get-RandomHex([int]$bytes) {
  $r = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  $b = New-Object byte[] $bytes
  $r.GetBytes($b); $r.Dispose()
  return (-join ($b | ForEach-Object { $_.ToString('x2') }))
}
function Test-ConstEq([string]$a, [string]$b) {
  if ($null -eq $a -or $null -eq $b) { return $false }
  if ($a.Length -ne $b.Length) { return $false }
  $d = 0
  for ($i = 0; $i -lt $a.Length; $i++) { $d = $d -bor ([int][char]$a[$i] -bxor [int][char]$b[$i]) }
  return ($d -eq 0)
}

# ---- 安全なパス判定 ----
# ドライブ文字のパスだけ許可。UNC・\\?\・代替データストリーム・デバイス名・拡張子違いは拒否
# 短い名前（8.3形式、例: メモA~1.MD）を正式な長い名前にそろえる（同じファイルが別のパスに見えないように）
$script:LongPathApi = $null
function Get-LongPath([string]$p) {
  if ($p.IndexOf('~') -lt 0) { return $p }
  try {
    if (-not $script:LongPathApi) {
      $script:LongPathApi = Add-Type -Name 'LongPathApi' -Namespace 'MDR' -PassThru -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)] public static extern uint GetLongPathNameW(string s, System.Text.StringBuilder b, uint n);'
    }
    $sb = New-Object System.Text.StringBuilder 2048
    $n = $script:LongPathApi::GetLongPathNameW($p, $sb, 2048)
    if ($n -gt 0 -and $n -lt 2048) { return $sb.ToString() }
  } catch { }
  return $p
}
function Get-SafePath([string]$p, $exts) {
  if (-not $p -or $p.Length -gt 1000) { return $null }
  if ($p -notmatch '^[A-Za-z]:[\\/]') { return $null }
  if ($p.IndexOf(':', 2) -ge 0) { return $null }
  if ($p -match '[*?<>|"]') { return $null }
  try { $full = [System.IO.Path]::GetFullPath($p) } catch { return $null }
  if ($full -notmatch '^[A-Za-z]:\\') { return $null }
  if ($full.IndexOf(':', 2) -ge 0) { return $null }
  foreach ($seg in $full.Substring(3).Split('\')) {
    if ($seg -match '^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(\..*)?$') { return $null }
  }
  $ext = [System.IO.Path]::GetExtension($full).ToLowerInvariant()
  if ($exts -notcontains $ext) { return $null }
  if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { return $null }
  return (Get-LongPath $full)
}

function Get-Iso8601Now { return (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz') }

# 旧試作（Windows起動時に隠れて動いていた server.ps1）が動いたままか調べる。
# 目印は「コマンドラインの最後が ...\md読み込みソフト...\src\server.ps1" で終わる powershell」だけ（他のものは対象にしない）
function Find-OldPrototype {
  try {
    return @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop |
      Where-Object { $_.CommandLine -and ($_.CommandLine -match '\\[^\\"]*md読み込みソフト[^"]*\\src\\server\.ps1"\s*$') })
  } catch { return @() }
}

# ---- 設定ファイル（config.json / config.local.json） ----
# 通信先URLは https://onanchi.com/ だけ。開発用（MDV_DEV=1）のときだけ 127.0.0.1 の http も許可
function Test-ApiUrl([string]$u) {
  if (-not $u) { return $false }
  if ($u -match '^https://(www\.)?onanchi\.com/') { return $true }
  if ($script:IsDev -and $u -match '^http://(127\.0\.0\.1|localhost):\d{2,5}/') { return $true }
  return $false
}
function Load-Config([string]$appDir) {
  $c = Read-JsonFile (Join-Path $appDir 'config.json') -KeepBroken
  if (-not $c) { $c = @{ product = 'md-viewer'; productName = 'MDReader'; version = '1.0.0' } }
  $local = Read-JsonFile (Join-Path $appDir 'config.local.json') -KeepBroken
  if ($local) { foreach ($k in @('versionUrl')) { if ($local.Keys -contains $k) { $c[$k] = $local[$k] } } }
  if ($script:IsDev -and $env:MDV_API_BASE -match '^http://(127\.0\.0\.1|localhost):\d{2,5}$') {
    $c['versionUrl'] = $env:MDV_API_BASE + '/md-viewer/version.json'
  }
  foreach ($k in @('versionUrl')) { if (-not (Test-ApiUrl ([string](Get-Prop $c $k '')))) { $c[$k] = '' } }
  return $c
}
