﻿# 保存まわり: settings.json / recent.json / marks\*.json
# どれも専用フォルダだけに書く。元の .md には触れない。壊れていたら ".broken-日時" に残して既定値で続行。

$script:Settings = $null
$script:MarkColors = @('yellow', 'green', 'pink', 'blue')
# 配色テーマ（7種、すべて無料）。名前は大文字小文字を区別して照合する
$script:Themes = @('standard', 'white', 'sepia', 'charcoal', 'bluegray', 'green', 'contrast')

function New-DefaultSettings {
  return [ordered]@{
    schema = 1; updateCheck = 'ask'; lastUpdateCheck = $null; latestKnown = $null
    keepHistory = $true; fontSize = 'm'; pdfMarks = $true; theme = 'standard'
    updateLaterUntil = $null; updateLaterVersion = $null
  }
}
function Load-Settings {
  $s = New-DefaultSettings
  $f = Read-JsonFile (Join-Path (Get-DataDir) 'settings.json')
  if ($f) {
    foreach ($k in @($s.Keys)) { if ($f.Keys -contains $k) { $s[$k] = $f[$k] } }
    if (@('ask', 'on', 'off') -notcontains [string]$s['updateCheck']) { $s['updateCheck'] = 'ask' }
    if (@('s', 'm', 'l', 'xl') -notcontains [string]$s['fontSize']) { $s['fontSize'] = 'm' }
    if ($script:Themes -cnotcontains [string]$s['theme']) { $s['theme'] = 'standard' }
  }
  $script:Settings = $s
}
function Save-Settings {
  try { Write-JsonAtomic (Join-Path (Get-DataDir) 'settings.json') $script:Settings; return $true }
  catch { Write-AppLog 'SETTINGS_SAVE_FAIL' $_.Exception.GetType().Name; return $false }
}
# いま使う配色テーマ（知らない名前なら標準）
function Get-EffectiveTheme {
  $t = [string]$script:Settings['theme']
  if ($script:Themes -ccontains $t) { return $t }
  return 'standard'
}
# 画面から変更してよい項目だけ受け付ける
function Update-SettingsFromClient($body) {
  foreach ($k in @($body.Keys)) {
    $v = $body[$k]
    switch ($k) {
      'updateCheck'     { if (@('on', 'off') -contains [string]$v) { $script:Settings['updateCheck'] = [string]$v } }
      'keepHistory'     { if ($v -is [bool]) { $script:Settings['keepHistory'] = $v } }
      'pdfMarks'        { if ($v -is [bool]) { $script:Settings['pdfMarks'] = $v } }
      'theme'           {
        $tv = [string]$v
        if ($script:Themes -ccontains $tv) { $script:Settings['theme'] = $tv }
      }
      'fontSize'        { if (@('s', 'm', 'l', 'xl') -contains [string]$v) { $script:Settings['fontSize'] = [string]$v } }
      'updateLater'     {
        if ($v -eq $true) {
          $script:Settings['updateLaterUntil'] = (Get-Date).AddHours(24).ToString('yyyy-MM-ddTHH:mm:ss')
          $script:Settings['updateLaterVersion'] = [string](Get-Prop $script:Settings['latestKnown'] 'latest' '')
        }
      }
    }
  }
  return (Save-Settings)
}

# ---- マーカー ----
function Get-MarksFile([string]$full) { return (Join-Path (Join-Path (Get-DataDir) 'marks') ((Get-PathId $full) + '.json')) }

function Read-MarksFor([string]$full) {
  $f = Get-MarksFile $full
  $d = Read-JsonFile $f
  $res = @{ marks = @(); recovered = $false }
  if ($script:LastReadBroken) { $res.recovered = $true; return $res }
  if ($d) { $m = Get-Prop $d 'marks' @(); if ($m -is [System.Array]) { $res.marks = $m } }
  return $res
}

# 1件を検証して、保存してよい形にして返す。だめなら $null
function ConvertTo-ValidMark($m) {
  if ($m -isnot [System.Collections.IDictionary]) { return $null }
  $id = [string](Get-Prop $m 'id' ''); $color = [string](Get-Prop $m 'color' '')
  $text = [string](Get-Prop $m 'text' ''); $prefix = [string](Get-Prop $m 'prefix' ''); $suffix = [string](Get-Prop $m 'suffix' '')
  $note = [string](Get-Prop $m 'note' ''); $created = [string](Get-Prop $m 'createdAt' '')
  if ($id -notmatch '^[A-Za-z0-9_\-]{1,40}$') { return $null }
  if ($script:MarkColors -notcontains $color) { return $null }
  if ($text.Length -lt 1 -or $text.Length -gt 2000) { return $null }
  if ($prefix.Length -gt 30 -or $suffix.Length -gt 30 -or $note.Length -gt 500 -or $created.Length -gt 40) { return $null }
  return [ordered]@{ id = $id; color = $color; text = $text; prefix = $prefix; suffix = $suffix; note = $note; createdAt = $created }
}
function Save-MarksFor([string]$full, $marks) {
  if ($marks -isnot [System.Array]) { return 'BAD_REQUEST' }
  if ($marks.Count -gt 2000) { return 'BAD_REQUEST' }
  $ok = New-Object System.Collections.ArrayList
  foreach ($m in $marks) {
    $v = ConvertTo-ValidMark $m
    if ($null -eq $v) { return 'BAD_REQUEST' }
    [void]$ok.Add($v)
  }
  $doc = [ordered]@{ schema = 1; path = $full; updatedAt = (Get-Iso8601Now); marks = $ok.ToArray() }
  try { Write-JsonAtomic (Get-MarksFile $full) $doc } catch { Write-AppLog 'MARKS_SAVE_FAIL' $_.Exception.GetType().Name; return 'SAVE_FAILED' }
  return $null
}

# ---- 最近のファイル ----
function Read-Recent {
  $d = Read-JsonFile (Join-Path (Get-DataDir) 'recent.json')
  $items = New-Object System.Collections.ArrayList
  if ($d) {
    $arr = Get-Prop $d 'items' @()
    if ($arr -is [System.Array]) {
      foreach ($it in $arr) {
        if ($it -is [System.Collections.IDictionary] -and (Get-Prop $it 'path' '')) {
          [void]$items.Add([ordered]@{ path = [string]$it['path']; openedAt = [string](Get-Prop $it 'openedAt' '') })
        }
      }
    }
  }
  return ,$items
}
function Save-Recent($items) {
  try { Write-JsonAtomic (Join-Path (Get-DataDir) 'recent.json') ([ordered]@{ schema = 1; items = $items.ToArray() }); return $true }
  catch { Write-AppLog 'RECENT_SAVE_FAIL' $_.Exception.GetType().Name; return $false }
}
function Add-Recent([string]$full) {
  $items = Read-Recent
  for ($i = $items.Count - 1; $i -ge 0; $i--) { if ([string]::Equals($items[$i]['path'], $full, 'OrdinalIgnoreCase')) { $items.RemoveAt($i) } }
  $items.Insert(0, [ordered]@{ path = $full; openedAt = (Get-Iso8601Now) })
  while ($items.Count -gt 30) { $items.RemoveAt($items.Count - 1) }
  return (Save-Recent $items)
}
function Remove-Recent([string]$p) {
  $items = Read-Recent
  for ($i = $items.Count - 1; $i -ge 0; $i--) { if ([string]::Equals($items[$i]['path'], $p, 'OrdinalIgnoreCase')) { $items.RemoveAt($i) } }
  return (Save-Recent $items)
}
function Get-RecentView {
  $out = New-Object System.Collections.ArrayList
  foreach ($it in (Read-Recent)) {
    $p = $it['path']
    $exists = $false; $has = $false
    try { $exists = [bool](Test-Path -LiteralPath $p -PathType Leaf) } catch { }
    try { if ($p -match '^[A-Za-z]:\\') { $has = [bool](Test-Path -LiteralPath (Get-MarksFile $p)) } } catch { }
    [void]$out.Add([ordered]@{ path = $p; openedAt = $it['openedAt']; exists = $exists; hasMarks = $has })
  }
  return $out.ToArray()
}
