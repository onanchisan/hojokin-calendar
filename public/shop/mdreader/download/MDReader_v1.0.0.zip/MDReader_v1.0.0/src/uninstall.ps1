﻿# アンインストール: 登録を外し、アプリ本体を削除する。保存データ（設定・マーカー・履歴）は標準で残す。
# 利用者の .md / .bak には触れない。-DryRun で「やること」だけ表示。
param(
  [switch]$DryRun,
  [ValidateSet('ask', 'keep', 'delete')][string]$Data = 'ask',
  [string]$ClassesRoot = 'HKCU:\Software\Classes',
  [string]$LocalRoot = '',
  [string]$StartMenuDir = ''
)
$ErrorActionPreference = 'Continue'
if (-not $LocalRoot) { $LocalRoot = Join-Path $env:LOCALAPPDATA 'MDReader' }
if (-not $StartMenuDir) { $StartMenuDir = [Environment]::GetFolderPath('Programs') }
$appName = 'MDReader'
$progId = 'MDReader.md'
$oldProgId = 'MdViewerSoftLab.md'      # 前の名前の登録（あれば一緒に外す）
$oldAppName = 'md読み込みソフト'
function Say([string]$t) { Write-Host $t }

# 旧い案内で作られた「アプリを選択して開く」の登録（例: Applications\開く.bat）を外す。
# 外すのは、次のどちらかに当てはまるものだけ（社長・利用者の他の登録は触らない）。
#  (a) コマンドが「"…\開く.bat" …」で始まり、その .bat の隣に src\app.ps1 と、product が md-viewer の src\config.json がある（＝本ソフトの 開く.bat）
#  (b) コマンドの -File "…" が、本ソフトの app.ps1 のフルパス（$ownAppPs1）と完全に一致する
function Remove-LegacyAppRegistrations([string[]]$ownAppPs1) {
  $apps = Join-Path $ClassesRoot 'Applications'
  if (-not (Test-Path -LiteralPath $apps)) { return }
  foreach ($key in @(Get-ChildItem -LiteralPath $apps -ErrorAction SilentlyContinue)) {
    $name = $key.PSChildName
    if ($name -ieq 'MDReader.exe') { continue }
    $cmd = ''
    try { $cmd = [string](Get-ItemProperty -LiteralPath (Join-Path $key.PSPath 'shell\open\command') -ErrorAction Stop).'(default)' } catch { continue }
    $mine = $false
    $m = [regex]::Match($cmd, '^\s*"([^"]*\\開く\.bat)"')
    if ($m.Success) {
      $dir = Split-Path -Parent $m.Groups[1].Value
      $cfg = if ($dir) { Join-Path $dir 'src\config.json' } else { '' }
      if ($cfg -and (Test-Path -LiteralPath (Join-Path $dir 'src\app.ps1')) -and (Test-Path -LiteralPath $cfg)) {
        try { if ((Get-Content -LiteralPath $cfg -Raw -Encoding UTF8 | ConvertFrom-Json).product -eq 'md-viewer') { $mine = $true } } catch { }
      }
    }
    if (-not $mine) {
      $f = [regex]::Match($cmd, '-File\s+"([^"]+)"')
      if ($f.Success) { foreach ($own in $ownAppPs1) { if ($own -and [string]::Equals($f.Groups[1].Value, $own, 'OrdinalIgnoreCase')) { $mine = $true } } }
    }
    if (-not $mine) { continue }
    Remove-Item -LiteralPath $key.PSPath -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($ext in '.md', '.markdown') {
      $ol = Join-Path $ClassesRoot ($ext + '\OpenWithList')
      if (Test-Path -LiteralPath $ol) { Remove-Item -LiteralPath (Join-Path $ol $name) -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Say ('  旧い登録を外しました: ' + $name)
  }
}
# Applications\MDReader.exe が本ソフトのもの（open コマンドが "<exe>" "%1" で、exe が本ソフトの場所）か。キーが無いときは $true
function Test-OwnAppEntry([string]$exe) {
  $c = Join-Path $ClassesRoot 'Applications\MDReader.exe'
  if (-not (Test-Path -LiteralPath $c)) { return $true }
  try {
    $cmd = [string](Get-ItemProperty -LiteralPath (Join-Path $c 'shell\open\command') -ErrorAction Stop).'(default)'
    $m = [regex]::Match($cmd, '^\s*"([^"]+)"')
    return ($m.Success -and [string]::Equals($m.Groups[1].Value, $exe, 'OrdinalIgnoreCase'))
  } catch { return $false }
}
# 本ソフトの Applications\MDReader.exe と OpenWithList の登録を外す（他社の同名の登録は残す）
function Remove-AppEntry([string]$exe) {
  if (-not (Test-OwnAppEntry $exe)) { return }
  Remove-Item -Path (Join-Path $ClassesRoot 'Applications\MDReader.exe') -Recurse -Force -ErrorAction SilentlyContinue
  foreach ($ext in '.md', '.markdown') { Remove-Item -Path (Join-Path $ClassesRoot ($ext + '\OpenWithList\MDReader.exe')) -Recurse -Force -ErrorAction SilentlyContinue }
}
function Step([string]$t) { Write-Host ''; Write-Host ('■ ' + $t) }
function Do-Action([string]$desc, [scriptblock]$act) { if ($DryRun) { Say ('  （確認のみ）' + $desc); return }; & $act }

Say ($appName + ' を解除します。' + $(if ($DryRun) { '（確認のみ・実際には何も変更しません）' } else { '' }))

Step '1. 動作中のアプリの確認'
$appDir = [IO.Path]::GetFullPath((Join-Path $LocalRoot 'app'))
Do-Action 'このソフトの powershell（app.ps1）が残っていれば停止' {
  $mine = Join-Path $appDir 'app.ps1'
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($mine) } |
    ForEach-Object { Say '  動作中のアプリを停止します。'; Stop-Process -Id $_.ProcessId -Force }
}

Step '2. 登録を外す'
Do-Action ($ClassesRoot + '\' + $progId + ' と .md/.markdown の登録を削除') {
  Remove-Item -Path (Join-Path $ClassesRoot $progId) -Recurse -Force -ErrorAction SilentlyContinue
  foreach ($ext in '.md', '.markdown') {
    Remove-ItemProperty -Path (Join-Path $ClassesRoot ($ext + '\OpenWithProgids')) -Name $progId -ErrorAction SilentlyContinue
  }
}
Do-Action ('「アプリを選択して開く」の登録（' + $ClassesRoot + '\Applications\MDReader.exe と OpenWithList）を削除（本ソフトの exe を指すものだけ）') {
  Remove-AppEntry (Join-Path (Join-Path $LocalRoot 'app') 'MDReader.exe')
}
Do-Action '旧い案内で作られた「アプリを選択して開く」の登録（開く.bat など）があれば、本ソフトのものだけ削除' { Remove-LegacyAppRegistrations @((Join-Path (Join-Path $LocalRoot 'app') 'app.ps1'), (Join-Path (Join-Path $env:LOCALAPPDATA 'md読み込みソフト') 'app\app.ps1')) }
Do-Action 'スタートメニューのショートカットを削除' {
  $l = Join-Path $StartMenuDir ($appName + '.lnk'); if (Test-Path -LiteralPath $l) { Remove-Item -LiteralPath $l -Force }
}
Do-Action '前の名前（md読み込みソフト）の登録があれば削除' {
  Remove-Item -Path (Join-Path $ClassesRoot $oldProgId) -Recurse -Force -ErrorAction SilentlyContinue
  foreach ($ext in '.md', '.markdown') {
    Remove-ItemProperty -Path (Join-Path $ClassesRoot ($ext + '\OpenWithProgids')) -Name $oldProgId -ErrorAction SilentlyContinue
  }
  $ol = Join-Path $StartMenuDir ($oldAppName + '.lnk'); if (Test-Path -LiteralPath $ol) { Remove-Item -LiteralPath $ol -Force }
}
Do-Action '旧試作のスタートアップ登録（MdViewerSoftLab.lnk）があれば削除' {
  $o = Join-Path ([Environment]::GetFolderPath('Startup')) 'MdViewerSoftLab.lnk'; if (Test-Path -LiteralPath $o) { Remove-Item -LiteralPath $o -Force }
}

Step '3. アプリ本体を削除'
foreach ($name in 'app', 'app.old', 'edge-profile') {
  $p = [IO.Path]::GetFullPath((Join-Path $LocalRoot $name))
  # 想定どおりの場所（...\MDReader\app など）のときだけ削除する
  if ($p.EndsWith('\MDReader\' + $name) -and (Test-Path -LiteralPath $p)) {
    Do-Action ($p + ' を削除') { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue }
  }
}
$localTop = [IO.Path]::GetFullPath($LocalRoot)
if (-not $DryRun -and $localTop.EndsWith('\MDReader') -and (Test-Path -LiteralPath $localTop)) {
  if (-not (Get-ChildItem -LiteralPath $localTop -Force -ErrorAction SilentlyContinue)) { Remove-Item -LiteralPath $localTop -Force -ErrorAction SilentlyContinue }
}

Step '4. 保存データ（設定・マーカー・最近のファイル）'
$dataDir = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'MDReader'))
$choice = $Data
if ($choice -eq 'ask' -and (Test-Path -LiteralPath $dataDir)) {
  Say '  保存データも消しますか？（消すと、設定・マーカーの線・最近のファイルがなくなります）'
  $a = Read-Host '  標準は「残す」です。消す場合だけ Y を入力して Enter（それ以外は残します）'
  if ($a -match '^[Yy]') { $choice = 'delete' } else { $choice = 'keep' }
} elseif ($choice -eq 'ask') { $choice = 'keep' }
if ($choice -eq 'delete') {
  # パスが期待どおりのときだけ削除する
  if ($dataDir.EndsWith('\AppData\Roaming\MDReader') -and (Test-Path -LiteralPath $dataDir)) {
    Do-Action ($dataDir + ' を削除') { Remove-Item -LiteralPath $dataDir -Recurse -Force }
    Say '  保存データを削除しました。'
  } else { Say '  保存データの場所が想定と違うため、削除しませんでした。' }
} else {
  Say '  保存データは残しました。（入れ直したときに、設定やマーカーがそのまま使えます）'
}
Say '  ※あなたの .md ファイルや、できあがった PDF・.bak には何もしていません。'
Step '5. 完了'
if ($DryRun) { Say '  確認が終わりました。（何も変更していません）' } else { Say '  解除できました。' }
