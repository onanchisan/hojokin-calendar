@echo off
chcp 65001 >nul
rem インストールしなくても使えます。.md をこのファイルにドラッグ＆ドロップしても開けます。
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -File | Unblock-File -ErrorAction SilentlyContinue"
start "" /min powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "%~dp0src\app.ps1" "%~1"
