@echo off
chcp 65001 >nul
echo MDReaderの登録を解除します。
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0src\uninstall.ps1"
echo.
pause
